

# 🛠️ Schema Toolkit — Full Web App

A complete Next.js app that takes your SQL Server files and **auto-generates** Prisma models, ERD diagrams, documentation, UAT test cases, and flow charts.

---

## Project Structure

```
schema-toolkit/
├── package.json
├── tailwind.config.ts
├── tsconfig.json
├── next.config.js
├── prisma/
│   └── schema.prisma
├── public/
├── src/
│   ├── app/
│   │   ├── layout.tsx
│   │   ├── page.tsx
│   │   ├── globals.css
│   │   ├── upload/page.tsx
│   │   ├── erd/page.tsx
│   │   ├── prisma-gen/page.tsx
│   │   ├── documentation/page.tsx
│   │   ├── uat/page.tsx
│   │   ├── flows/page.tsx
│   │   ├── api/
│   │   │   ├── parse-sql/route.ts
│   │   │   ├── generate-prisma/route.ts
│   │   │   ├── generate-erd/route.ts
│   │   │   ├── generate-docs/route.ts
│   │   │   ├── generate-uat/route.ts
│   │   │   ├── generate-flows/route.ts
│   │   │   ├── projects/route.ts
│   │   │   └── projects/[id]/route.ts
│   ├── lib/
│   │   ├── sql-parser.ts
│   │   ├── prisma-generator.ts
│   │   ├── erd-generator.ts
│   │   ├── doc-generator.ts
│   │   ├── uat-generator.ts
│   │   ├── flow-generator.ts
│   │   ├── db.ts
│   │   └── types.ts
│   └── components/
│       ├── Sidebar.tsx
│       ├── SqlUploader.tsx
│       ├── CodeBlock.tsx
│       ├── MermaidRenderer.tsx
│       ├── ExportButton.tsx
│       ├── TableList.tsx
│       └── StatsCard.tsx
```

---

## 1. Setup & Installation

```bash
npx create-next-app@latest schema-toolkit --typescript --tailwind --app --src-dir
cd schema-toolkit
```

```bash
npm install prisma @prisma/client mermaid react-markdown
npm install @types/node -D
npm install lucide-react
npm install file-saver @types/file-saver
npm install jszip
```

---

## 2. Prisma Schema (Tool's Own Database)

```prisma
// prisma/schema.prisma

generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "sqlite"
  url      = "file:./toolkit.db"
}

model Project {
  id          String   @id @default(uuid())
  name        String
  description String?
  rawSql      String
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
  tables      ParsedTable[]
}

model ParsedTable {
  id        String   @id @default(uuid())
  projectId String
  tableName String
  schemaName String  @default("dbo")
  project   Project  @relation(fields: [projectId], references: [id], onDelete: Cascade)
  columns   ParsedColumn[]
  foreignKeys ParsedForeignKey[]
}

model ParsedColumn {
  id           String  @id @default(uuid())
  tableId      String
  columnName   String
  dataType     String
  maxLength    String?
  isNullable   Boolean @default(true)
  isPrimaryKey Boolean @default(false)
  isIdentity   Boolean @default(false)
  defaultValue String?
  table        ParsedTable @relation(fields: [tableId], references: [id], onDelete: Cascade)
}

model ParsedForeignKey {
  id               String @id @default(uuid())
  tableId          String
  constraintName   String?
  columnName       String
  referencesTable  String
  referencesColumn String
  table            ParsedTable @relation(fields: [tableId], references: [id], onDelete: Cascade)
}
```

```bash
npx prisma migrate dev --name init
npx prisma generate
```

---

## 3. Core Types

```typescript
// src/lib/types.ts

export interface ColumnDef {
  name: string
  dataType: string
  maxLength?: string
  isNullable: boolean
  isPrimaryKey: boolean
  isIdentity: boolean
  defaultValue?: string
}

export interface ForeignKeyDef {
  constraintName?: string
  columnName: string
  referencesTable: string
  referencesColumn: string
}

export interface TableDef {
  schemaName: string
  tableName: string
  columns: ColumnDef[]
  foreignKeys: ForeignKeyDef[]
}

export interface ParseResult {
  tables: TableDef[]
  errors: string[]
  warnings: string[]
}
```

---

## 4. SQL Server Parser (Core Engine)

```typescript
// src/lib/sql-parser.ts

import { TableDef, ColumnDef, ForeignKeyDef, ParseResult } from './types'

export function parseSqlServer(sql: string): ParseResult {
  const tables: TableDef[] = []
  const errors: string[] = []
  const warnings: string[] = []

  // Remove single-line comments
  let cleaned = sql.replace(/--.*$/gm, '')
  // Remove multi-line comments
  cleaned = cleaned.replace(/\/\*[\s\S]*?\*\//g, '')

  // ─── PARSE CREATE TABLE STATEMENTS ───
  const createTableRegex =
    /CREATE\s+TABLE\s+(?:\[?(\w+)\]?\.)?\[?(\w+)\]?\s*\(([\s\S]*?)\)\s*;?/gi
  let match: RegExpExecArray | null

  while ((match = createTableRegex.exec(cleaned)) !== null) {
    try {
      const schemaName = match[1] || 'dbo'
      const tableName = match[2]
      const body = match[3]

      const { columns, foreignKeys, primaryKeys } = parseTableBody(body)

      // Mark primary key columns
      primaryKeys.forEach(pk => {
        const col = columns.find(
          c => c.name.toLowerCase() === pk.toLowerCase()
        )
        if (col) col.isPrimaryKey = true
      })

      tables.push({ schemaName, tableName, columns, foreignKeys })
    } catch (e: any) {
      errors.push(`Error parsing table: ${match[2]} — ${e.message}`)
    }
  }

  // ─── PARSE ALTER TABLE … ADD CONSTRAINT FK ───
  const alterFkRegex =
    /ALTER\s+TABLE\s+(?:\[?\w+\]?\.)?\[?(\w+)\]?\s+.*?ADD\s+CONSTRAINT\s+\[?(\w+)\]?\s+FOREIGN\s+KEY\s*\(\s*\[?(\w+)\]?\s*\)\s*REFERENCES\s+(?:\[?\w+\]?\.)?\[?(\w+)\]?\s*\(\s*\[?(\w+)\]?\s*\)/gi

  while ((match = alterFkRegex.exec(cleaned)) !== null) {
    const tableName = match[1]
    const constraintName = match[2]
    const columnName = match[3]
    const refTable = match[4]
    const refColumn = match[5]

    const table = tables.find(
      t => t.tableName.toLowerCase() === tableName.toLowerCase()
    )
    if (table) {
      const exists = table.foreignKeys.some(
        fk => fk.columnName.toLowerCase() === columnName.toLowerCase()
           && fk.referencesTable.toLowerCase() === refTable.toLowerCase()
      )
      if (!exists) {
        table.foreignKeys.push({
          constraintName,
          columnName,
          referencesTable: refTable,
          referencesColumn: refColumn,
        })
      }
    } else {
      warnings.push(`ALTER TABLE FK: table "${tableName}" not found`)
    }
  }

  return { tables, errors, warnings }
}

// ─── helpers ───────────────────────────────────────────

function parseTableBody(body: string) {
  const columns: ColumnDef[] = []
  const foreignKeys: ForeignKeyDef[] = []
  const primaryKeys: string[] = []

  // Split on commas that are NOT inside parentheses
  const parts = splitTopLevel(body)

  for (const raw of parts) {
    const part = raw.trim()
    if (!part) continue

    const upper = part.toUpperCase()

    // ── CONSTRAINT … PRIMARY KEY ──
    if (upper.includes('PRIMARY KEY')) {
      const pkMatch = part.match(/PRIMARY\s+KEY\s*(?:CLUSTERED|NONCLUSTERED)?\s*\(([^)]+)\)/i)
      if (pkMatch) {
        pkMatch[1].split(',').forEach(c => {
          primaryKeys.push(c.replace(/[\[\]\s]/g, ''))
        })
      }
      continue
    }

    // ── CONSTRAINT … FOREIGN KEY ──
    if (upper.includes('FOREIGN KEY')) {
      const fkMatch = part.match(
        /(?:CONSTRAINT\s+\[?(\w+)\]?\s+)?FOREIGN\s+KEY\s*\(\s*\[?(\w+)\]?\s*\)\s*REFERENCES\s+(?:\[?\w+\]?\.)?\[?(\w+)\]?\s*\(\s*\[?(\w+)\]?\s*\)/i
      )
      if (fkMatch) {
        foreignKeys.push({
          constraintName: fkMatch[1],
          columnName: fkMatch[2],
          referencesTable: fkMatch[3],
          referencesColumn: fkMatch[4],
        })
      }
      continue
    }

    // ── Skip CHECK / UNIQUE / INDEX ──
    if (
      upper.startsWith('CONSTRAINT') ||
      upper.startsWith('CHECK') ||
      upper.startsWith('UNIQUE') ||
      upper.startsWith('INDEX')
    ) {
      continue
    }

    // ── COLUMN DEFINITION ──
    const col = parseColumn(part)
    if (col) columns.push(col)
  }

  return { columns, foreignKeys, primaryKeys }
}

function parseColumn(part: string): ColumnDef | null {
  // Pattern: [ColumnName] DATATYPE(size) [IDENTITY] [NOT NULL | NULL] [DEFAULT ...]
  const colRegex =
    /^\[?(\w+)\]?\s+([\w]+)(?:\s*\(([^)]*)\))?(.*)$/i

  const m = part.match(colRegex)
  if (!m) return null

  const name = m[1]
  const dataType = m[2].toUpperCase()
  const maxLength = m[3] || undefined
  const rest = m[4]?.toUpperCase() || ''

  // Skip SQL keywords that look like column names
  const reserved = ['CONSTRAINT','PRIMARY','FOREIGN','CHECK','UNIQUE','INDEX','GO']
  if (reserved.includes(name.toUpperCase())) return null

  const isNullable = !rest.includes('NOT NULL')
  const isPrimaryKey = rest.includes('PRIMARY KEY')
  const isIdentity = rest.includes('IDENTITY')

  let defaultValue: string | undefined
  const defMatch = part.match(/DEFAULT\s+(.+?)(?:\s*,?\s*$)/i)
  if (defMatch) defaultValue = defMatch[1].trim()

  return { name, dataType, maxLength, isNullable, isPrimaryKey, isIdentity, defaultValue }
}

function splitTopLevel(str: string): string[] {
  const results: string[] = []
  let depth = 0
  let current = ''
  for (const ch of str) {
    if (ch === '(') depth++
    if (ch === ')') depth--
    if (ch === ',' && depth === 0) {
      results.push(current)
      current = ''
    } else {
      current += ch
    }
  }
  if (current.trim()) results.push(current)
  return results
}
```

---

## 5. Prisma Schema Generator

```typescript
// src/lib/prisma-generator.ts

import { TableDef } from './types'

const TYPE_MAP: Record<string, string> = {
  UNIQUEIDENTIFIER: 'String',
  NVARCHAR:         'String',
  VARCHAR:          'String',
  NCHAR:            'String',
  CHAR:             'String',
  TEXT:             'String',
  NTEXT:            'String',
  INT:              'Int',
  BIGINT:           'BigInt',
  SMALLINT:         'Int',
  TINYINT:          'Int',
  BIT:              'Boolean',
  DECIMAL:          'Decimal',
  NUMERIC:          'Decimal',
  FLOAT:            'Float',
  REAL:             'Float',
  MONEY:            'Decimal',
  SMALLMONEY:       'Decimal',
  DATETIME:         'DateTime',
  DATETIME2:        'DateTime',
  SMALLDATETIME:    'DateTime',
  DATE:             'DateTime',
  TIME:             'DateTime',
  DATETIMEOFFSET:   'DateTime',
  IMAGE:            'Bytes',
  VARBINARY:        'Bytes',
  BINARY:           'Bytes',
  XML:              'String',
}

export function generatePrismaSchema(
  tables: TableDef[],
  provider: 'sqlite' | 'postgresql' | 'mysql' | 'sqlserver' = 'sqlite'
): string {
  const lines: string[] = []

  // Header
  lines.push(`// ─── Auto-generated by Schema Toolkit ───`)
  lines.push(`// Generated: ${new Date().toISOString()}`)
  lines.push(`// Tables: ${tables.length}`)
  lines.push('')
  lines.push(`generator client {`)
  lines.push(`  provider = "prisma-client-js"`)
  lines.push(`}`)
  lines.push('')
  lines.push(`datasource db {`)
  lines.push(`  provider = "${provider}"`)

  if (provider === 'sqlite') {
    lines.push(`  url      = "file:./dev.db"`)
  } else {
    lines.push(`  url      = env("DATABASE_URL")`)
  }
  lines.push(`}`)
  lines.push('')

  // Build a lookup: tableName → modelName
  const modelMap = new Map<string, string>()
  tables.forEach(t => {
    modelMap.set(t.tableName.toLowerCase(), toPascalSingular(t.tableName))
  })

  // Generate each model
  for (const table of tables) {
    const modelName = modelMap.get(table.tableName.toLowerCase())!
    lines.push(`model ${modelName} {`)

    // Columns
    for (const col of table.columns) {
      const fieldName = toCamelCase(col.name)
      let prismaType = TYPE_MAP[col.dataType] || 'String'

      const attrs: string[] = []

      if (col.isPrimaryKey) {
        attrs.push('@id')
        if (col.dataType === 'UNIQUEIDENTIFIER') {
          attrs.push('@default(uuid())')
        } else if (col.isIdentity) {
          attrs.push('@default(autoincrement())')
        }
      }

      if (col.isNullable && !col.isPrimaryKey) {
        prismaType += '?'
      }

      if (col.defaultValue && !col.isPrimaryKey) {
        const def = convertDefault(col.defaultValue, col.dataType)
        if (def) attrs.push(`@default(${def})`)
      }

      // Map field to original column name if different
      if (fieldName !== col.name) {
        attrs.push(`@map("${col.name}")`)
      }

      const attrStr = attrs.length ? '  ' + attrs.join(' ') : ''
      lines.push(`  ${padRight(fieldName, 24)} ${padRight(prismaType, 12)}${attrStr}`)
    }

    // Relation fields (from foreign keys)
    if (table.foreignKeys.length > 0) {
      lines.push('')
      lines.push(`  // ── Relations ──`)
    }

    for (const fk of table.foreignKeys) {
      const refModelName = modelMap.get(fk.referencesTable.toLowerCase())
      if (!refModelName) continue

      const fieldName = toCamelCase(fk.referencesTable)
      const fkField = toCamelCase(fk.columnName)

      // Check if column is nullable
      const col = table.columns.find(
        c => c.name.toLowerCase() === fk.columnName.toLowerCase()
      )
      const optional = col?.isNullable ? '?' : ''

      lines.push(
        `  ${padRight(fieldName, 24)} ${refModelName}${optional}  @relation(fields: [${fkField}], references: [${toCamelCase(fk.referencesColumn)}])`
      )
    }

    // Reverse relations (has-many)
    const reverseRels = findReverseRelations(table, tables)
    for (const rev of reverseRels) {
      const revModel = modelMap.get(rev.toLowerCase())
      if (revModel) {
        const fieldName = toCamelCase(rev) + 's'
        lines.push(`  ${padRight(fieldName, 24)} ${revModel}[]`)
      }
    }

    // Map to original table name
    lines.push('')
    lines.push(`  @@map("${table.tableName}")`)
    lines.push(`}`)
    lines.push('')
  }

  return lines.join('\n')
}

// ─── Helpers ─────────────────────────────────────────

function findReverseRelations(current: TableDef, all: TableDef[]): string[] {
  const result: string[] = []
  for (const t of all) {
    if (t.tableName === current.tableName) continue
    for (const fk of t.foreignKeys) {
      if (fk.referencesTable.toLowerCase() === current.tableName.toLowerCase()) {
        result.push(t.tableName)
      }
    }
  }
  return [...new Set(result)]
}

function toPascalSingular(name: string): string {
  // Remove trailing 's' for simple plural → singular
  let singular = name
  if (singular.endsWith('ies')) {
    singular = singular.slice(0, -3) + 'y'
  } else if (singular.endsWith('ses') || singular.endsWith('xes')) {
    singular = singular.slice(0, -2)
  } else if (singular.endsWith('s') && !singular.endsWith('ss') && !singular.endsWith('us')) {
    singular = singular.slice(0, -1)
  }
  return singular.charAt(0).toUpperCase() + singular.slice(1)
}

function toCamelCase(name: string): string {
  return name.charAt(0).toLowerCase() + name.slice(1)
}

function padRight(str: string, len: number): string {
  return str + ' '.repeat(Math.max(0, len - str.length))
}

function convertDefault(val: string, dataType: string): string | null {
  const v = val.replace(/[()]/g, '').trim()
  if (v.toLowerCase() === 'getdate' || v.toLowerCase() === 'getutcdate') return 'now()'
  if (v.toLowerCase() === 'newid' || v.toLowerCase() === 'newsequentialid') return 'uuid()'
  if (v === '1' && dataType === 'BIT') return 'true'
  if (v === '0' && dataType === 'BIT') return 'false'
  if (/^\d+$/.test(v)) return v
  if (/^\d+\.\d+$/.test(v)) return v
  return null
}
```

---

## 6. ERD Generator (Mermaid.js)

```typescript
// src/lib/erd-generator.ts

import { TableDef } from './types'

export function generateErd(tables: TableDef[]): string {
  const lines: string[] = []
  lines.push('erDiagram')

  // Table definitions
  for (const table of tables) {
    lines.push(`  ${table.tableName} {`)
    for (const col of table.columns) {
      const type = col.dataType.toLowerCase()
      const pk = col.isPrimaryKey ? 'PK' : ''
      const fk = table.foreignKeys.some(
        f => f.columnName.toLowerCase() === col.name.toLowerCase()
      ) ? 'FK' : ''
      const marker = pk || fk
      lines.push(`    ${type} ${col.name} ${marker}`)
    }
    lines.push(`  }`)
  }

  lines.push('')

  // Relationships
  for (const table of tables) {
    for (const fk of table.foreignKeys) {
      const refTable = tables.find(
        t => t.tableName.toLowerCase() === fk.referencesTable.toLowerCase()
      )
      if (refTable) {
        const col = table.columns.find(
          c => c.name.toLowerCase() === fk.columnName.toLowerCase()
        )
        const cardinality = col?.isNullable ? '|o' : '||'
        lines.push(
          `  ${fk.referencesTable} ${cardinality}--o{ ${table.tableName} : "${fk.columnName}"`
        )
      }
    }
  }

  return lines.join('\n')
}

export function generateErdByModule(
  tables: TableDef[],
  groupSize: number = 10
): { name: string; erd: string }[] {
  const groups: { name: string; erd: string }[] = []

  for (let i = 0; i < tables.length; i += groupSize) {
    const chunk = tables.slice(i, i + groupSize)
    const name = `Group ${Math.floor(i / groupSize) + 1}: ${chunk.map(t => t.tableName).join(', ')}`
    groups.push({
      name,
      erd: generateErd(chunk),
    })
  }

  return groups
}
```

---

## 7. Documentation Generator

```typescript
// src/lib/doc-generator.ts

import { TableDef } from './types'

export function generateDocumentation(tables: TableDef[], projectName: string = 'Project'): string {
  const lines: string[] = []
  const now = new Date().toISOString().split('T')[0]

  lines.push(`# ${projectName} — Database Documentation`)
  lines.push('')
  lines.push(`> Auto-generated on ${now}`)
  lines.push(`> Total Tables: ${tables.length}`)
  lines.push(`> Total Columns: ${tables.reduce((a, t) => a + t.columns.length, 0)}`)
  lines.push(`> Total Relationships: ${tables.reduce((a, t) => a + t.foreignKeys.length, 0)}`)
  lines.push('')
  lines.push('---')
  lines.push('')

  // Table of Contents
  lines.push('## Table of Contents')
  lines.push('')
  tables.forEach((t, i) => {
    lines.push(`${i + 1}. [${t.tableName}](#${t.tableName.toLowerCase()})`)
  })
  lines.push('')
  lines.push('---')
  lines.push('')

  // Each table
  for (const table of tables) {
    lines.push(`## ${table.tableName}`)
    lines.push('')
    lines.push(`**Schema:** ${table.schemaName}`)
    lines.push(`**Columns:** ${table.columns.length}`)
    lines.push(`**Foreign Keys:** ${table.foreignKeys.length}`)
    lines.push('')

    // Column table
    lines.push('| # | Column | Data Type | Nullable | PK | FK | Default |')
    lines.push('|---|--------|-----------|----------|----|----|---------|')

    table.columns.forEach((col, i) => {
      const fk = table.foreignKeys.find(
        f => f.columnName.toLowerCase() === col.name.toLowerCase()
      )
      const fkStr = fk ? `→ ${fk.referencesTable}.${fk.referencesColumn}` : ''
      const typeStr = col.maxLength ? `${col.dataType}(${col.maxLength})` : col.dataType
      lines.push(
        `| ${i + 1} | ${col.name} | ${typeStr} | ${col.isNullable ? '✅' : '❌'} | ${col.isPrimaryKey ? '🔑' : ''} | ${fkStr} | ${col.defaultValue || ''} |`
      )
    })
    lines.push('')

    // Foreign Keys detail
    if (table.foreignKeys.length > 0) {
      lines.push('### Relationships')
      lines.push('')
      for (const fk of table.foreignKeys) {
        lines.push(`- **${fk.columnName}** → \`${fk.referencesTable}.${fk.referencesColumn}\`${fk.constraintName ? ` (${fk.constraintName})` : ''}`)
      }
      lines.push('')
    }

    lines.push('---')
    lines.push('')
  }

  // Summary
  lines.push('## Summary Statistics')
  lines.push('')
  lines.push('| Metric | Count |')
  lines.push('|--------|-------|')
  lines.push(`| Total Tables | ${tables.length} |`)
  lines.push(`| Total Columns | ${tables.reduce((a, t) => a + t.columns.length, 0)} |`)
  lines.push(`| Total Primary Keys | ${tables.reduce((a, t) => a + t.columns.filter(c => c.isPrimaryKey).length, 0)} |`)
  lines.push(`| Total Foreign Keys | ${tables.reduce((a, t) => a + t.foreignKeys.length, 0)} |`)
  lines.push(`| Nullable Columns | ${tables.reduce((a, t) => a + t.columns.filter(c => c.isNullable).length, 0)} |`)
  lines.push(`| Identity Columns | ${tables.reduce((a, t) => a + t.columns.filter(c => c.isIdentity).length, 0)} |`)

  return lines.join('\n')
}
```

---

## 8. UAT Generator

```typescript
// src/lib/uat-generator.ts

import { TableDef } from './types'

export interface UATTestCase {
  id: string
  module: string
  testCase: string
  description: string
  preconditions: string
  steps: string[]
  expectedResult: string
  priority: 'High' | 'Medium' | 'Low'
  status: 'Not Started'
}

export function generateUATCases(tables: TableDef[]): UATTestCase[] {
  const cases: UATTestCase[] = []
  let counter = 1

  for (const table of tables) {
    const name = table.tableName
    const requiredCols = table.columns.filter(c => !c.isNullable && !c.isPrimaryKey)
    const pkCol = table.columns.find(c => c.isPrimaryKey)

    // ─── CREATE ───
    cases.push({
      id: `TC-${String(counter++).padStart(3, '0')}`,
      module: name,
      testCase: `Create ${name} — Valid Data`,
      description: `Verify that a new ${name} record can be created with all required fields`,
      preconditions: `User has create permission for ${name}`,
      steps: [
        `Navigate to ${name} form`,
        ...requiredCols.map(c => `Enter valid value for "${c.name}" (${c.dataType})`),
        `Click Save / Submit`,
      ],
      expectedResult: `New ${name} record is created successfully. System shows success message.`,
      priority: 'High',
      status: 'Not Started',
    })

    // ─── CREATE — Missing Required Fields ───
    for (const col of requiredCols.slice(0, 3)) {
      cases.push({
        id: `TC-${String(counter++).padStart(3, '0')}`,
        module: name,
        testCase: `Create ${name} — Missing "${col.name}"`,
        description: `Verify validation when required field "${col.name}" is empty`,
        preconditions: `User has create permission`,
        steps: [
          `Navigate to ${name} form`,
          `Leave "${col.name}" empty`,
          `Fill other required fields`,
          `Click Save`,
        ],
        expectedResult: `System shows validation error: "${col.name} is required"`,
        priority: 'High',
        status: 'Not Started',
      })
    }

    // ─── READ ───
    cases.push({
      id: `TC-${String(counter++).padStart(3, '0')}`,
      module: name,
      testCase: `Read ${name} — List All`,
      description: `Verify that all ${name} records are listed`,
      preconditions: `At least one ${name} record exists`,
      steps: [
        `Navigate to ${name} list page`,
        `Verify records are displayed`,
        `Verify column headers match: ${table.columns.slice(0, 5).map(c => c.name).join(', ')}`,
      ],
      expectedResult: `All ${name} records are displayed in a table/list format`,
      priority: 'High',
      status: 'Not Started',
    })

    // ─── UPDATE ───
    cases.push({
      id: `TC-${String(counter++).padStart(3, '0')}`,
      module: name,
      testCase: `Update ${name} — Valid Data`,
      description: `Verify that an existing ${name} record can be updated`,
      preconditions: `At least one ${name} record exists. User has edit permission.`,
      steps: [
        `Navigate to ${name} list`,
        `Click Edit on an existing record`,
        `Modify one or more fields`,
        `Click Save`,
      ],
      expectedResult: `Record is updated. Changes are reflected in the list.`,
      priority: 'High',
      status: 'Not Started',
    })

    // ─── DELETE ───
    cases.push({
      id: `TC-${String(counter++).padStart(3, '0')}`,
      module: name,
      testCase: `Delete ${name}`,
      description: `Verify that a ${name} record can be deleted`,
      preconditions: `At least one ${name} record exists. User has delete permission.`,
      steps: [
        `Navigate to ${name} list`,
        `Click Delete on a record`,
        `Confirm deletion in dialog`,
      ],
      expectedResult: `Record is removed from the list. System shows success message.`,
      priority: 'Medium',
      status: 'Not Started',
    })

    // ─── FK Validation ───
    for (const fk of table.foreignKeys) {
      cases.push({
        id: `TC-${String(counter++).padStart(3, '0')}`,
        module: name,
        testCase: `FK Validation — ${fk.columnName} references ${fk.referencesTable}`,
        description: `Verify that ${fk.columnName} only accepts valid values from ${fk.referencesTable}`,
        preconditions: `${fk.referencesTable} has at least one record`,
        steps: [
          `Navigate to ${name} form`,
          `For field "${fk.columnName}", attempt to enter an invalid ID`,
          `Click Save`,
        ],
        expectedResult: `System rejects invalid FK value. Only valid ${fk.referencesTable} IDs are accepted.`,
        priority: 'Medium',
        status: 'Not Started',
      })
    }
  }

  return cases
}

export function uatToMarkdown(cases: UATTestCase[]): string {
  const lines: string[] = []
  lines.push('# UAT Test Cases')
  lines.push('')
  lines.push(`> Total Test Cases: ${cases.length}`)
  lines.push(`> Generated: ${new Date().toISOString().split('T')[0]}`)
  lines.push('')

  // Summary by module
  const modules = [...new Set(cases.map(c => c.module))]
  lines.push('## Summary by Module')
  lines.push('')
  lines.push('| Module | Test Cases | High | Medium | Low |')
  lines.push('|--------|-----------|------|--------|-----|')
  for (const mod of modules) {
    const modCases = cases.filter(c => c.module === mod)
    lines.push(
      `| ${mod} | ${modCases.length} | ${modCases.filter(c => c.priority === 'High').length} | ${modCases.filter(c => c.priority === 'Medium').length} | ${modCases.filter(c => c.priority === 'Low').length} |`
    )
  }
  lines.push('')
  lines.push('---')
  lines.push('')

  // Detailed test cases
  for (const tc of cases) {
    lines.push(`### ${tc.id}: ${tc.testCase}`)
    lines.push('')
    lines.push(`- **Module:** ${tc.module}`)
    lines.push(`- **Priority:** ${tc.priority}`)
    lines.push(`- **Status:** ${tc.status}`)
    lines.push(`- **Description:** ${tc.description}`)
    lines.push(`- **Preconditions:** ${tc.preconditions}`)
    lines.push('')
    lines.push('**Steps:**')
    tc.steps.forEach((s, i) => lines.push(`${i + 1}. ${s}`))
    lines.push('')
    lines.push(`**Expected Result:** ${tc.expectedResult}`)
    lines.push('')
    lines.push('---')
    lines.push('')
  }

  return lines.join('\n')
}

export function uatToCSV(cases: UATTestCase[]): string {
  const headers = ['ID', 'Module', 'Test Case', 'Description', 'Priority', 'Steps', 'Expected Result', 'Status']
  const rows = cases.map(tc => [
    tc.id,
    tc.module,
    `"${tc.testCase}"`,
    `"${tc.description}"`,
    tc.priority,
    `"${tc.steps.join('; ')}"`,
    `"${tc.expectedResult}"`,
    tc.status,
  ])

  return [headers.join(','), ...rows.map(r => r.join(','))].join('\n')
}
```

---

## 9. Flow Generator

```typescript
// src/lib/flow-generator.ts

import { TableDef } from './types'

export function generateDataFlow(tables: TableDef[]): string {
  const lines: string[] = []
  lines.push('flowchart TD')

  // Create nodes for each table
  for (const table of tables) {
    const cols = table.columns.length
    lines.push(`  ${table.tableName}["📋 ${table.tableName}<br/>${cols} columns"]`)
  }

  lines.push('')

  // Create edges for foreign keys
  for (const table of tables) {
    for (const fk of table.foreignKeys) {
      const refExists = tables.some(
        t => t.tableName.toLowerCase() === fk.referencesTable.toLowerCase()
      )
      if (refExists) {
        lines.push(
          `  ${fk.referencesTable} -->|"${fk.columnName}"| ${table.tableName}`
        )
      }
    }
  }

  return lines.join('\n')
}

export function generateCRUDFlow(tableName: string): string {
  return `flowchart TD
  Start([User Action]) --> Choose{Operation?}
  
  Choose -->|Create| C1[Open Form]
  C1 --> C2[Fill Required Fields]
  C2 --> C3{Validate}
  C3 -->|Valid| C4[Save to ${tableName}]
  C3 -->|Invalid| C5[Show Errors]
  C5 --> C2
  C4 --> Success([✅ Success])
  
  Choose -->|Read| R1[Fetch ${tableName} List]
  R1 --> R2[Display in Table]
  R2 --> R3{Search/Filter?}
  R3 -->|Yes| R4[Apply Filters]
  R4 --> R1
  R3 -->|No| R5[View Details]
  
  Choose -->|Update| U1[Select Record]
  U1 --> U2[Load Edit Form]
  U2 --> U3[Modify Fields]
  U3 --> U4{Validate}
  U4 -->|Valid| U5[Update ${tableName}]
  U4 -->|Invalid| U6[Show Errors]
  U6 --> U3
  U5 --> Success
  
  Choose -->|Delete| D1[Select Record]
  D1 --> D2{Confirm Delete?}
  D2 -->|Yes| D3[Delete from ${tableName}]
  D2 -->|No| D4([Cancel])
  D3 --> Success

  style Success fill:#4ade80
  style C5 fill:#f87171
  style U6 fill:#f87171`
}

export function generateModuleFlow(tables: TableDef[]): string {
  const lines: string[] = []
  lines.push('flowchart LR')
  lines.push('')

  // Group tables by their relationships
  // Tables with no FK = master tables
  const masters = tables.filter(t => t.foreignKeys.length === 0)
  const children = tables.filter(t => t.foreignKeys.length > 0)

  lines.push('  subgraph Masters["🏛️ Master Tables"]')
  for (const t of masters) {
    lines.push(`    ${t.tableName}["${t.tableName}"]`)
  }
  lines.push('  end')
  lines.push('')

  lines.push('  subgraph Transactions["📝 Transaction Tables"]')
  for (const t of children) {
    lines.push(`    ${t.tableName}["${t.tableName}"]`)
  }
  lines.push('  end')
  lines.push('')

  // Edges
  for (const t of children) {
    for (const fk of t.foreignKeys) {
      lines.push(`  ${fk.referencesTable} --> ${t.tableName}`)
    }
  }

  return lines.join('\n')
}
```

---

## 10. Database Helper

```typescript
// src/lib/db.ts

import { PrismaClient } from '@prisma/client'

const globalForPrisma = global as unknown as { prisma: PrismaClient }

export const prisma = globalForPrisma.prisma || new PrismaClient()

if (process.env.NODE_ENV !== 'production') {
  globalForPrisma.prisma = prisma
}
```

---

## 11. API Routes

### Parse SQL

```typescript
// src/app/api/parse-sql/route.ts

import { NextRequest, NextResponse } from 'next/server'
import { parseSqlServer } from '@/lib/sql-parser'
import { prisma } from '@/lib/db'

export async function POST(req: NextRequest) {
  try {
    const { sql, projectName } = await req.json()

    if (!sql || !projectName) {
      return NextResponse.json({ error: 'sql and projectName required' }, { status: 400 })
    }

    const result = parseSqlServer(sql)

    // Save project to database
    const project = await prisma.project.create({
      data: {
        name: projectName,
        rawSql: sql,
        tables: {
          create: result.tables.map(t => ({
            tableName: t.tableName,
            schemaName: t.schemaName,
            columns: {
              create: t.columns.map(c => ({
                columnName: c.name,
                dataType: c.dataType,
                maxLength: c.maxLength,
                isNullable: c.isNullable,
                isPrimaryKey: c.isPrimaryKey,
                isIdentity: c.isIdentity,
                defaultValue: c.defaultValue,
              })),
            },
            foreignKeys: {
              create: t.foreignKeys.map(fk => ({
                constraintName: fk.constraintName,
                columnName: fk.columnName,
                referencesTable: fk.referencesTable,
                referencesColumn: fk.referencesColumn,
              })),
            },
          })),
        },
      },
      include: {
        tables: {
          include: {
            columns: true,
            foreignKeys: true,
          },
        },
      },
    })

    return NextResponse.json({
      project,
      parseResult: result,
      stats: {
        tables: result.tables.length,
        columns: result.tables.reduce((a, t) => a + t.columns.length, 0),
        foreignKeys: result.tables.reduce((a, t) => a + t.foreignKeys.length, 0),
        errors: result.errors.length,
        warnings: result.warnings.length,
      },
    })
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
```

### Generate Prisma

```typescript
// src/app/api/generate-prisma/route.ts

import { NextRequest, NextResponse } from 'next/server'
import { generatePrismaSchema } from '@/lib/prisma-generator'
import { parseSqlServer } from '@/lib/sql-parser'

export async function POST(req: NextRequest) {
  const { sql, provider } = await req.json()
  const result = parseSqlServer(sql)
  const schema = generatePrismaSchema(result.tables, provider || 'sqlite')
  return NextResponse.json({ schema, tableCount: result.tables.length })
}
```

### Generate ERD

```typescript
// src/app/api/generate-erd/route.ts

import { NextRequest, NextResponse } from 'next/server'
import { generateErd, generateErdByModule } from '@/lib/erd-generator'
import { parseSqlServer } from '@/lib/sql-parser'

export async function POST(req: NextRequest) {
  const { sql, grouped } = await req.json()
  const result = parseSqlServer(sql)

  if (grouped) {
    const groups = generateErdByModule(result.tables)
    return NextResponse.json({ groups })
  }

  const erd = generateErd(result.tables)
  return NextResponse.json({ erd })
}
```

### Generate Docs

```typescript
// src/app/api/generate-docs/route.ts

import { NextRequest, NextResponse } from 'next/server'
import { generateDocumentation } from '@/lib/doc-generator'
import { parseSqlServer } from '@/lib/sql-parser'

export async function POST(req: NextRequest) {
  const { sql, projectName } = await req.json()
  const result = parseSqlServer(sql)
  const docs = generateDocumentation(result.tables, projectName)
  return NextResponse.json({ documentation: docs })
}
```

### Generate UAT

```typescript
// src/app/api/generate-uat/route.ts

import { NextRequest, NextResponse } from 'next/server'
import { generateUATCases, uatToMarkdown, uatToCSV } from '@/lib/uat-generator'
import { parseSqlServer } from '@/lib/sql-parser'

export async function POST(req: NextRequest) {
  const { sql, format } = await req.json()
  const result = parseSqlServer(sql)
  const cases = generateUATCases(result.tables)

  if (format === 'csv') {
    return NextResponse.json({ output: uatToCSV(cases), count: cases.length })
  }

  return NextResponse.json({
    markdown: uatToMarkdown(cases),
    cases,
    count: cases.length,
  })
}
```

### Generate Flows

```typescript
// src/app/api/generate-flows/route.ts

import { NextRequest, NextResponse } from 'next/server'
import { generateDataFlow, generateCRUDFlow, generateModuleFlow } from '@/lib/flow-generator'
import { parseSqlServer } from '@/lib/sql-parser'

export async function POST(req: NextRequest) {
  const { sql, type, tableName } = await req.json()
  const result = parseSqlServer(sql)

  if (type === 'crud' && tableName) {
    return NextResponse.json({ flow: generateCRUDFlow(tableName) })
  }
  if (type === 'module') {
    return NextResponse.json({ flow: generateModuleFlow(result.tables) })
  }

  return NextResponse.json({ flow: generateDataFlow(result.tables) })
}
```

### Projects CRUD

```typescript
// src/app/api/projects/route.ts

import { NextResponse } from 'next/server'
import { prisma } from '@/lib/db'

export async function GET() {
  const projects = await prisma.project.findMany({
    include: { tables: { include: { columns: true, foreignKeys: true } } },
    orderBy: { createdAt: 'desc' },
  })
  return NextResponse.json(projects)
}
```

```typescript
// src/app/api/projects/[id]/route.ts

import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/db'

export async function GET(_: NextRequest, { params }: { params: { id: string } }) {
  const project = await prisma.project.findUnique({
    where: { id: params.id },
    include: { tables: { include: { columns: true, foreignKeys: true } } },
  })
  return NextResponse.json(project)
}

export async function DELETE(_: NextRequest, { params }: { params: { id: string } }) {
  await prisma.project.delete({ where: { id: params.id } })
  return NextResponse.json({ success: true })
}
```

---

## 12. Frontend Components

### Sidebar

```tsx
// src/components/Sidebar.tsx
'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'

const NAV = [
  { href: '/',              icon: '🏠', label: 'Home' },
  { href: '/upload',        icon: '📤', label: 'Upload SQL' },
  { href: '/erd',           icon: '🗂️', label: 'ERD Diagram' },
  { href: '/prisma-gen',    icon: '⚙️', label: 'Prisma Schema' },
  { href: '/documentation', icon: '📄', label: 'Documentation' },
  { href: '/uat',           icon: '✅', label: 'UAT Cases' },
  { href: '/flows',         icon: '🔀', label: 'Flows' },
]

export default function Sidebar() {
  const pathname = usePathname()

  return (
    <aside className="w-64 bg-gray-900 text-white min-h-screen p-4 flex flex-col">
      <div className="text-xl font-bold mb-8 text-center border-b border-gray-700 pb-4">
        🛠️ Schema Toolkit
      </div>
      <nav className="flex-1 space-y-1">
        {NAV.map(n => (
          <Link
            key={n.href}
            href={n.href}
            className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors
              ${pathname === n.href
                ? 'bg-blue-600 text-white'
                : 'text-gray-300 hover:bg-gray-800 hover:text-white'
              }`}
          >
            <span className="text-lg">{n.icon}</span>
            <span>{n.label}</span>
          </Link>
        ))}
      </nav>
      <div className="text-xs text-gray-500 text-center mt-4">
        v1.0 — Schema Toolkit
      </div>
    </aside>
  )
}
```

### SQL Uploader

```tsx
// src/components/SqlUploader.tsx
'use client'

import { useState, useRef } from 'react'

interface Props {
  onSqlReady: (sql: string) => void
}

export default function SqlUploader({ onSqlReady }: Props) {
  const [sql, setSql] = useState('')
  const fileRef = useRef<HTMLInputElement>(null)

  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return

    let combined = ''
    for (const file of Array.from(files)) {
      const text = await file.text()
      combined += text + '\n\n'
    }
    setSql(combined)
    onSqlReady(combined)
  }

  return (
    <div className="space-y-4">
      {/* File Upload */}
      <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center
                      hover:border-blue-400 transition-colors cursor-pointer"
           onClick={() => fileRef.current?.click()}>
        <input
          ref={fileRef}
          type="file"
          accept=".sql,.txt"
          multiple
          onChange={handleFile}
          className="hidden"
        />
        <div className="text-4xl mb-2">📁</div>
        <p className="text-gray-600">
          Click or drag <strong>.sql</strong> files here
        </p>
        <p className="text-sm text-gray-400 mt-1">Supports multiple files</p>
      </div>

      {/* Manual Input */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Or paste SQL directly:
        </label>
        <textarea
          value={sql}
          onChange={e => { setSql(e.target.value); onSqlReady(e.target.value) }}
          className="w-full h-64 font-mono text-sm border rounded-lg p-4
                     focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          placeholder="CREATE TABLE [dbo].[Organizations] ( ... )"
        />
      </div>

      {sql && (
        <div className="text-sm text-green-600">
          ✅ {sql.length.toLocaleString()} characters loaded
        </div>
      )}
    </div>
  )
}
```

### Code Block

```tsx
// src/components/CodeBlock.tsx
'use client'

import { useState } from 'react'

interface Props {
  code: string
  language?: string
  title?: string
}

export default function CodeBlock({ code, language = 'plaintext', title }: Props) {
  const [copied, setCopied] = useState(false)

  const copy = () => {
    navigator.clipboard.writeText(code)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className="rounded-xl overflow-hidden border border-gray-200 shadow-sm">
      {title && (
        <div className="bg-gray-100 px-4 py-2 flex justify-between items-center border-b">
          <span className="font-medium text-sm text-gray-700">{title}</span>
          <button
            onClick={copy}
            className="text-xs bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600"
          >
            {copied ? '✅ Copied!' : '📋 Copy'}
          </button>
        </div>
      )}
      <pre className="bg-gray-950 text-green-400 p-4 overflow-auto max-h-[600px] text-sm">
        <code>{code}</code>
      </pre>
    </div>
  )
}
```

### Mermaid Renderer

```tsx
// src/components/MermaidRenderer.tsx
'use client'

import { useEffect, useRef, useState } from 'react'

interface Props {
  chart: string
  title?: string
}

export default function MermaidRenderer({ chart, title }: Props) {
  const ref = useRef<HTMLDivElement>(null)
  const [error, setError] = useState('')

  useEffect(() => {
    const render = async () => {
      try {
        const mermaid = (await import('mermaid')).default
        mermaid.initialize({
          startOnLoad: false,
          theme: 'default',
          er: { useMaxWidth: true },
          flowchart: { useMaxWidth: true, curve: 'basis' },
        })

        if (ref.current) {
          ref.current.innerHTML = ''
          const id = `mermaid-${Date.now()}`
          const { svg } = await mermaid.render(id, chart)
          ref.current.innerHTML = svg
          setError('')
        }
      } catch (e: any) {
        setError(e.message)
      }
    }
    if (chart) render()
  }, [chart])

  const exportSVG = () => {
    if (!ref.current) return
    const svg = ref.current.innerHTML
    const blob = new Blob([svg], { type: 'image/svg+xml' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${title || 'diagram'}.svg`
    a.click()
  }

  return (
    <div className="border rounded-xl overflow-hidden">
      {title && (
        <div className="bg-gray-100 px-4 py-2 flex justify-between items-center border-b">
          <span className="font-medium">{title}</span>
          <button
            onClick={exportSVG}
            className="text-xs bg-green-500 text-white px-3 py-1 rounded hover:bg-green-600"
          >
            📥 Export SVG
          </button>
        </div>
      )}
      {error ? (
        <div className="bg-red-50 p-4 text-red-600 text-sm">{error}</div>
      ) : (
        <div ref={ref} className="p-4 overflow-auto bg-white" />
      )}
    </div>
  )
}
```

### Stats Card

```tsx
// src/components/StatsCard.tsx

interface Props {
  icon: string
  label: string
  value: number | string
  color?: string
}

export default function StatsCard({ icon, label, value, color = 'blue' }: Props) {
  const colors: Record<string, string> = {
    blue:   'bg-blue-50 border-blue-200 text-blue-700',
    green:  'bg-green-50 border-green-200 text-green-700',
    purple: 'bg-purple-50 border-purple-200 text-purple-700',
    orange: 'bg-orange-50 border-orange-200 text-orange-700',
    red:    'bg-red-50 border-red-200 text-red-700',
  }

  return (
    <div className={`border rounded-xl p-4 ${colors[color]}`}>
      <div className="text-2xl mb-1">{icon}</div>
      <div className="text-2xl font-bold">{value}</div>
      <div className="text-sm opacity-75">{label}</div>
    </div>
  )
}
```

### Export Button

```tsx
// src/components/ExportButton.tsx
'use client'

interface Props {
  content: string
  filename: string
  label?: string
}

export default function ExportButton({ content, filename, label = 'Download' }: Props) {
  const download = () => {
    const blob = new Blob([content], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = filename
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <button
      onClick={download}
      className="bg-green-600 text-white px-4 py-2 rounded-lg
                 hover:bg-green-700 transition-colors flex items-center gap-2"
    >
      📥 {label}
    </button>
  )
}
```

---

## 13. Frontend Pages

### Layout

```tsx
// src/app/layout.tsx

import './globals.css'
import Sidebar from '@/components/Sidebar'

export const metadata = {
  title: 'Schema Toolkit',
  description: 'SQL → Prisma, ERD, Docs, UAT, Flows',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="flex min-h-screen bg-gray-50">
        <Sidebar />
        <main className="flex-1 p-8 overflow-auto">
          {children}
        </main>
      </body>
    </html>
  )
}
```

### Home Page

```tsx
// src/app/page.tsx

import Link from 'next/link'

const FEATURES = [
  {
    icon: '📤',
    title: 'Upload SQL',
    desc: 'Parse SQL Server schema files',
    href: '/upload',
    color: 'bg-blue-500',
  },
  {
    icon: '🗂️',
    title: 'ERD Diagram',
    desc: 'Auto-generate entity relationship diagrams',
    href: '/erd',
    color: 'bg-purple-500',
  },
  {
    icon: '⚙️',
    title: 'Prisma Schema',
    desc: 'Convert SQL tables to Prisma models',
    href: '/prisma-gen',
    color: 'bg-green-500',
  },
  {
    icon: '📄',
    title: 'Documentation',
    desc: 'Generate full database documentation',
    href: '/documentation',
    color: 'bg-orange-500',
  },
  {
    icon: '✅',
    title: 'UAT Test Cases',
    desc: 'Auto-generate test cases for each table',
    href: '/uat',
    color: 'bg-red-500',
  },
  {
    icon: '🔀',
    title: 'Flow Diagrams',
    desc: 'Data flow & CRUD process flows',
    href: '/flows',
    color: 'bg-teal-500',
  },
]

export default function Home() {
  return (
    <div>
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-800 mb-4">
          🛠️ Schema Toolkit
        </h1>
        <p className="text-lg text-gray-500 max-w-2xl mx-auto">
          Upload your SQL Server schema files and auto-generate
          Prisma models, ERD diagrams, documentation, UAT test cases,
          and flow diagrams — all in one place.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
        {FEATURES.map(f => (
          <Link
            key={f.href}
            href={f.href}
            className="group block bg-white rounded-2xl shadow-sm border border-gray-200
                       p-6 hover:shadow-lg hover:-translate-y-1 transition-all"
          >
            <div className={`w-12 h-12 ${f.color} rounded-xl flex items-center
                            justify-center text-white text-2xl mb-4
                            group-hover:scale-110 transition-transform`}>
              {f.icon}
            </div>
            <h3 className="text-lg font-semibold text-gray-800 mb-1">{f.title}</h3>
            <p className="text-gray-500 text-sm">{f.desc}</p>
          </Link>
        ))}
      </div>

      <div className="mt-12 text-center">
        <div className="inline-flex items-center gap-2 bg-yellow-50 border border-yellow-200
                        text-yellow-800 px-6 py-3 rounded-full text-sm">
          💡 Start by uploading your SQL files on the
          <Link href="/upload" className="font-bold underline">Upload page</Link>
        </div>
      </div>
    </div>
  )
}
```

### Upload Page

```tsx
// src/app/upload/page.tsx
'use client'

import { useState } from 'react'
import SqlUploader from '@/components/SqlUploader'
import StatsCard from '@/components/StatsCard'

export default function UploadPage() {
  const [sql, setSql] = useState('')
  const [result, setResult] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const [projectName, setProjectName] = useState('')

  const parse = async () => {
    if (!sql || !projectName) return
    setLoading(true)

    const res = await fetch('/api/parse-sql', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sql, projectName }),
    })

    const data = await res.json()
    setResult(data)
    setLoading(false)

    // Store SQL in localStorage for other pages
    localStorage.setItem('toolkit_sql', sql)
    localStorage.setItem('toolkit_project', projectName)
  }

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-2">📤 Upload SQL Schema</h1>
      <p className="text-gray-500 mb-8">
        Upload your SQL Server CREATE TABLE scripts
      </p>

      <div className="mb-4">
        <label className="block text-sm font-medium mb-1">Project Name</label>
        <input
          value={projectName}
          onChange={e => setProjectName(e.target.value)}
          className="w-full border rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500"
          placeholder="My HIS Project"
        />
      </div>

      <SqlUploader onSqlReady={setSql} />

      <button
        onClick={parse}
        disabled={!sql || !projectName || loading}
        className="mt-6 w-full bg-blue-600 text-white py-3 rounded-xl font-semibold
                   hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed
                   transition-colors"
      >
        {loading ? '⏳ Parsing...' : '🔍 Parse SQL Schema'}
      </button>

      {result && (
        <div className="mt-8 space-y-6">
          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <StatsCard icon="📋" label="Tables" value={result.stats.tables} color="blue" />
            <StatsCard icon="📊" label="Columns" value={result.stats.columns} color="green" />
            <StatsCard icon="🔗" label="Foreign Keys" value={result.stats.foreignKeys} color="purple" />
            <StatsCard icon="❌" label="Errors" value={result.stats.errors} color="red" />
            <StatsCard icon="⚠️" label="Warnings" value={result.stats.warnings} color="orange" />
          </div>

          {/* Tables List */}
          <div className="bg-white rounded-xl border p-6">
            <h3 className="font-semibold text-lg mb-4">Parsed Tables</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {result.parseResult.tables.map((t: any) => (
                <div
                  key={t.tableName}
                  className="bg-gray-50 rounded-lg px-4 py-2 text-sm
                             border hover:bg-blue-50 transition-colors"
                >
                  <span className="font-medium">{t.tableName}</span>
                  <span className="text-gray-400 ml-2">({t.columns.length} cols)</span>
                </div>
              ))}
            </div>
          </div>

          {/* Errors */}
          {result.parseResult.errors.length > 0 && (
            <div className="bg-red-50 border border-red-200 rounded-xl p-4">
              <h3 className="font-semibold text-red-700 mb-2">Errors</h3>
              {result.parseResult.errors.map((e: string, i: number) => (
                <p key={i} className="text-sm text-red-600">{e}</p>
              ))}
            </div>
          )}

          <div className="bg-green-50 border border-green-200 rounded-xl p-4 text-center">
            <p className="text-green-700">
              ✅ Schema parsed! Now visit <strong>ERD</strong>, <strong>Prisma</strong>,
              <strong> Docs</strong>, <strong>UAT</strong>, or <strong>Flows</strong> pages.
            </p>
          </div>
        </div>
      )}
    </div>
  )
}
```

### ERD Page

```tsx
// src/app/erd/page.tsx
'use client'

import { useState, useEffect } from 'react'
import MermaidRenderer from '@/components/MermaidRenderer'
import CodeBlock from '@/components/CodeBlock'
import ExportButton from '@/components/ExportButton'

export default function ErdPage() {
  const [erd, setErd] = useState('')
  const [loading, setLoading] = useState(false)
  const [showCode, setShowCode] = useState(false)

  useEffect(() => {
    const sql = localStorage.getItem('toolkit_sql')
    if (sql) generate(sql)
  }, [])

  const generate = async (sql: string) => {
    setLoading(true)
    const res = await fetch('/api/generate-erd', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sql }),
    })
    const data = await res.json()
    setErd(data.erd)
    setLoading(false)
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold">🗂️ ERD Diagram</h1>
          <p className="text-gray-500">Entity Relationship Diagram</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setShowCode(!showCode)}
            className="bg-gray-200 px-4 py-2 rounded-lg hover:bg-gray-300 text-sm"
          >
            {showCode ? '🖼️ Visual' : '📝 Mermaid Code'}
          </button>
          {erd && <ExportButton content={erd} filename="erd.mmd" label="Export Mermaid" />}
        </div>
      </div>

      {loading && <p className="text-gray-500">⏳ Generating ERD...</p>}

      {!loading && erd && (
        showCode
          ? <CodeBlock code={erd} title="Mermaid ERD Code" />
          : <MermaidRenderer chart={erd} title="Database ERD" />
      )}

      {!erd && !loading && (
        <div className="text-center py-20 text-gray-400">
          <p className="text-4xl mb-4">🗂️</p>
          <p>Upload SQL files first on the Upload page</p>
        </div>
      )}
    </div>
  )
}
```

### Prisma Generator Page

```tsx
// src/app/prisma-gen/page.tsx
'use client'

import { useState, useEffect } from 'react'
import CodeBlock from '@/components/CodeBlock'
import ExportButton from '@/components/ExportButton'

export default function PrismaGenPage() {
  const [schema, setSchema] = useState('')
  const [provider, setProvider] = useState<string>('sqlite')
  const [loading, setLoading] = useState(false)
  const [tableCount, setTableCount] = useState(0)

  const generate = async () => {
    const sql = localStorage.getItem('toolkit_sql')
    if (!sql) return

    setLoading(true)
    const res = await fetch('/api/generate-prisma', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sql, provider }),
    })
    const data = await res.json()
    setSchema(data.schema)
    setTableCount(data.tableCount)
    setLoading(false)
  }

  useEffect(() => { generate() }, [provider])

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold">⚙️ Prisma Schema</h1>
          <p className="text-gray-500">
            {tableCount} models generated
          </p>
        </div>
        <div className="flex gap-2 items-center">
          <select
            value={provider}
            onChange={e => setProvider(e.target.value)}
            className="border rounded-lg px-3 py-2"
          >
            <option value="sqlite">SQLite</option>
            <option value="postgresql">PostgreSQL</option>
            <option value="mysql">MySQL</option>
            <option value="sqlserver">SQL Server</option>
          </select>
          {schema && (
            <ExportButton content={schema} filename="schema.prisma" label="Download" />
          )}
        </div>
      </div>

      {loading && <p>⏳ Generating...</p>}
      {schema && <CodeBlock code={schema} title="schema.prisma" language="prisma" />}
    </div>
  )
}
```

### Documentation Page

```tsx
// src/app/documentation/page.tsx
'use client'

import { useState, useEffect } from 'react'
import CodeBlock from '@/components/CodeBlock'
import ExportButton from '@/components/ExportButton'

export default function DocsPage() {
  const [docs, setDocs] = useState('')
  const [loading, setLoading] = useState(false)
  const [viewMode, setViewMode] = useState<'raw' | 'preview'>('raw')

  useEffect(() => {
    const sql = localStorage.getItem('toolkit_sql')
    const name = localStorage.getItem('toolkit_project') || 'Project'
    if (sql) generate(sql, name)
  }, [])

  const generate = async (sql: string, projectName: string) => {
    setLoading(true)
    const res = await fetch('/api/generate-docs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sql, projectName }),
    })
    const data = await res.json()
    setDocs(data.documentation)
    setLoading(false)
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold">📄 Documentation</h1>
          <p className="text-gray-500">Full database documentation in Markdown</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setViewMode(viewMode === 'raw' ? 'preview' : 'raw')}
            className="bg-gray-200 px-4 py-2 rounded-lg hover:bg-gray-300 text-sm"
          >
            {viewMode === 'raw' ? '👁️ Preview' : '📝 Raw Markdown'}
          </button>
          {docs && (
            <>
              <ExportButton content={docs} filename="database-docs.md" label="Download MD" />
            </>
          )}
        </div>
      </div>

      {loading && <p>⏳ Generating documentation...</p>}

      {docs && viewMode === 'raw' && (
        <CodeBlock code={docs} title="database-documentation.md" />
      )}

      {docs && viewMode === 'preview' && (
        <div className="bg-white rounded-xl border p-8 prose prose-sm max-w-none">
          {/* Basic markdown rendering */}
          {docs.split('\n').map((line, i) => {
            if (line.startsWith('# '))     return <h1 key={i} className="text-2xl font-bold mt-6">{line.slice(2)}</h1>
            if (line.startsWith('## '))    return <h2 key={i} className="text-xl font-bold mt-4 text-blue-700">{line.slice(3)}</h2>
            if (line.startsWith('### '))   return <h3 key={i} className="text-lg font-semibold mt-3">{line.slice(4)}</h3>
            if (line.startsWith('> '))     return <blockquote key={i} className="border-l-4 border-blue-300 pl-4 text-gray-600 italic">{line.slice(2)}</blockquote>
            if (line.startsWith('- '))     return <li key={i} className="ml-4">{line.slice(2)}</li>
            if (line.startsWith('---'))    return <hr key={i} className="my-4" />
            if (line.startsWith('|'))      return <pre key={i} className="text-xs bg-gray-50 px-2">{line}</pre>
            if (line.trim() === '')        return <br key={i} />
            return <p key={i} className="text-sm">{line}</p>
          })}
        </div>
      )}
    </div>
  )
}
```

### UAT Page

```tsx
// src/app/uat/page.tsx
'use client'

import { useState, useEffect } from 'react'
import CodeBlock from '@/components/CodeBlock'
import ExportButton from '@/components/ExportButton'
import StatsCard from '@/components/StatsCard'

export default function UATPage() {
  const [markdown, setMarkdown] = useState('')
  const [csv, setCsv] = useState('')
  const [cases, setCases] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [view, setView] = useState<'table' | 'markdown'>('table')

  useEffect(() => {
    const sql = localStorage.getItem('toolkit_sql')
    if (sql) generate(sql)
  }, [])

  const generate = async (sql: string) => {
    setLoading(true)

    // Get markdown
    const res1 = await fetch('/api/generate-uat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sql, format: 'markdown' }),
    })
    const data1 = await res1.json()
    setMarkdown(data1.markdown)
    setCases(data1.cases)

    // Get CSV
    const res2 = await fetch('/api/generate-uat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sql, format: 'csv' }),
    })
    const data2 = await res2.json()
    setCsv(data2.output)

    setLoading(false)
  }

  const modules = [...new Set(cases.map((c: any) => c.module))]

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold">✅ UAT Test Cases</h1>
          <p className="text-gray-500">{cases.length} test cases generated</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setView(view === 'table' ? 'markdown' : 'table')}
            className="bg-gray-200 px-4 py-2 rounded-lg hover:bg-gray-300 text-sm"
          >
            {view === 'table' ? '📝 Markdown' : '📊 Table View'}
          </button>
          {markdown && <ExportButton content={markdown} filename="uat-test-cases.md" label="MD" />}
          {csv && <ExportButton content={csv} filename="uat-test-cases.csv" label="CSV" />}
        </div>
      </div>

      {loading && <p>⏳ Generating test cases...</p>}

      {cases.length > 0 && (
        <>
          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <StatsCard icon="📝" label="Total Cases" value={cases.length} color="blue" />
            <StatsCard icon="🔴" label="High Priority" value={cases.filter((c: any) => c.priority === 'High').length} color="red" />
            <StatsCard icon="🟡" label="Medium Priority" value={cases.filter((c: any) => c.priority === 'Medium').length} color="orange" />
            <StatsCard icon="📦" label="Modules" value={modules.length} color="purple" />
          </div>

          {view === 'table' ? (
            <div className="bg-white rounded-xl border overflow-hidden">
              <div className="overflow-auto max-h-[600px]">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 sticky top-0">
                    <tr>
                      <th className="px-4 py-3 text-left">ID</th>
                      <th className="px-4 py-3 text-left">Module</th>
                      <th className="px-4 py-3 text-left">Test Case</th>
                      <th className="px-4 py-3 text-left">Priority</th>
                      <th className="px-4 py-3 text-left">Steps</th>
                    </tr>
                  </thead>
                  <tbody>
                    {cases.map((tc: any) => (
                      <tr key={tc.id} className="border-t hover:bg-gray-50">
                        <td className="px-4 py-2 font-mono text-xs">{tc.id}</td>
                        <td className="px-4 py-2">
                          <span className="bg-blue-100 text-blue-700 px-2 py-1 rounded text-xs">
                            {tc.module}
                          </span>
                        </td>
                        <td className="px-4 py-2">{tc.testCase}</td>
                        <td className="px-4 py-2">
                          <span className={`px-2 py-1 rounded text-xs font-medium
                            ${tc.priority === 'High' ? 'bg-red-100 text-red-700' : ''}
                            ${tc.priority === 'Medium' ? 'bg-yellow-100 text-yellow-700' : ''}
                            ${tc.priority === 'Low' ? 'bg-green-100 text-green-700' : ''}
                          `}>
                            {tc.priority}
                          </span>
                        </td>
                        <td className="px-4 py-2 text-xs text-gray-500">
                          {tc.steps.length} steps
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            <CodeBlock code={markdown} title="UAT Test Cases (Markdown)" />
          )}
        </>
      )}
    </div>
  )
}
```

### Flows Page

```tsx
// src/app/flows/page.tsx
'use client'

import { useState, useEffect } from 'react'
import MermaidRenderer from '@/components/MermaidRenderer'
import CodeBlock from '@/components/CodeBlock'
import ExportButton from '@/components/ExportButton'

export default function FlowsPage() {
  const [flowType, setFlowType] = useState<'data' | 'module' | 'crud'>('data')
  const [flow, setFlow] = useState('')
  const [tables, setTables] = useState<string[]>([])
  const [selectedTable, setSelectedTable] = useState('')
  const [loading, setLoading] = useState(false)
  const [showCode, setShowCode] = useState(false)

  useEffect(() => {
    const sql = localStorage.getItem('toolkit_sql')
    if (sql) {
      // Extract table names from SQL
      const matches = sql.matchAll(/CREATE\s+TABLE\s+(?:\[?\w+\]?\.)?\[?(\w+)\]?/gi)
      setTables([...matches].map(m => m[1]))
      generate(sql, 'data')
    }
  }, [])

  const generate = async (sql?: string, type?: string, tableName?: string) => {
    const s = sql || localStorage.getItem('toolkit_sql')
    if (!s) return

    setLoading(true)
    const res = await fetch('/api/generate-flows', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        sql: s,
        type: type || flowType,
        tableName: tableName || selectedTable,
      }),
    })
    const data = await res.json()
    setFlow(data.flow)
    setLoading(false)
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold">🔀 Flow Diagrams</h1>
          <p className="text-gray-500">Data flow and process diagrams</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setShowCode(!showCode)}
            className="bg-gray-200 px-4 py-2 rounded-lg hover:bg-gray-300 text-sm"
          >
            {showCode ? '🖼️ Visual' : '📝 Code'}
          </button>
          {flow && <ExportButton content={flow} filename="flow.mmd" label="Export" />}
        </div>
      </div>

      {/* Flow Type Selector */}
      <div className="flex gap-4 mb-6">
        <button
          onClick={() => { setFlowType('data'); generate(undefined, 'data') }}
          className={`px-6 py-3 rounded-xl border-2 transition-all
            ${flowType === 'data'
              ? 'border-blue-500 bg-blue-50 text-blue-700'
              : 'border-gray-200 hover:border-gray-300'
            }`}
        >
          📊 Data Flow
        </button>
        <button
          onClick={() => { setFlowType('module'); generate(undefined, 'module') }}
          className={`px-6 py-3 rounded-xl border-2 transition-all
            ${flowType === 'module'
              ? 'border-blue-500 bg-blue-50 text-blue-700'
              : 'border-gray-200 hover:border-gray-300'
            }`}
        >
          📦 Module View
        </button>
        <button
          onClick={() => setFlowType('crud')}
          className={`px-6 py-3 rounded-xl border-2 transition-all
            ${flowType === 'crud'
              ? 'border-blue-500 bg-blue-50 text-blue-700'
              : 'border-gray-200 hover:border-gray-300'
            }`}
        >
          🔄 CRUD Flow
        </button>
      </div>

      {/* Table Selector for CRUD */}
      {flowType === 'crud' && (
        <div className="mb-6">
          <label className="block text-sm font-medium mb-1">Select Table:</label>
          <div className="flex gap-2">
            <select
              value={selectedTable}
              onChange={e => setSelectedTable(e.target.value)}
              className="border rounded-lg px-4 py-2 flex-1"
            >
              <option value="">-- Choose a table --</option>
              {tables.map(t => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
            <button
              onClick={() => generate(undefined, 'crud', selectedTable)}
              disabled={!selectedTable}
              className="bg-blue-600 text-white px-6 py-2 rounded-lg
                         hover:bg-blue-700 disabled:opacity-50"
            >
              Generate
            </button>
          </div>
        </div>
      )}

      {loading && <p>⏳ Generating flow...</p>}

      {flow && !loading && (
        showCode
          ? <CodeBlock code={flow} title="Mermaid Flow Code" />
          : <MermaidRenderer chart={flow} title={`${flowType} Flow Diagram`} />
      )}
    </div>
  )
}
```

---

## 14. Global CSS

```css
/* src/app/globals.css */

@tailwind base;
@tailwind components;
@tailwind utilities;

body {
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
}

/* Custom scrollbar */
::-webkit-scrollbar {
  width: 8px;
  height: 8px;
}
::-webkit-scrollbar-track {
  background: #f1f1f1;
}
::-webkit-scrollbar-thumb {
  background: #c1c1c1;
  border-radius: 4px;
}
::-webkit-scrollbar-thumb:hover {
  background: #a1a1a1;
}
```

---

## 15. Run the Project

```bash
# Terminal 1 — Setup database
npx prisma migrate dev --name init
npx prisma generate

# Terminal 2 — Run the app
npm run dev
```

Open **http://localhost:3000**

---

## 16. Complete Workflow

```
┌─────────────────────────────────────────────────────┐
│                                                     │
│   📁 Upload .sql files                              │
│        ↓                                            │
│   🔍 Parser extracts tables, columns, FKs           │
│        ↓                                            │
│   ┌──────────────────────────────────────────┐      │
│   │  Choose what to generate:                │      │
│   │                                          │      │
│   │  ⚙️  Prisma Schema   → schema.prisma     │      │
│   │  🗂️  ERD Diagram     → SVG / Mermaid     │      │
│   │  📄  Documentation   → Markdown          │      │
│   │  ✅  UAT Test Cases  → MD / CSV          │      │
│   │  🔀  Flow Diagrams   → SVG / Mermaid     │      │
│   └──────────────────────────────────────────┘      │
│        ↓                                            │
│   📥 Download all files                             │
│                                                     │
└─────────────────────────────────────────────────────┘
```

---

## Sample SQL to Test

Paste this on the **Upload** page to test immediately:

```sql
CREATE TABLE [dbo].[Countries] (
    [Id] UNIQUEIDENTIFIER NOT NULL,
    [Name] NVARCHAR(100) NOT NULL,
    [Code] NVARCHAR(10) NULL,
    [IsActive] BIT NOT NULL DEFAULT 1,
    CONSTRAINT [PK_Countries] PRIMARY KEY ([Id])
);

CREATE TABLE [dbo].[Cities] (
    [Id] UNIQUEIDENTIFIER NOT NULL,
    [Name] NVARCHAR(100) NOT NULL,
    [CountryId] UNIQUEIDENTIFIER NOT NULL,
    [IsActive] BIT NOT NULL DEFAULT 1,
    CONSTRAINT [PK_Cities] PRIMARY KEY ([Id]),
    CONSTRAINT [FK_Cities_Countries] FOREIGN KEY ([CountryId])
        REFERENCES [dbo].[Countries]([Id])
);

CREATE TABLE [dbo].[Organizations] (
    [Id] UNIQUEIDENTIFIER NOT NULL,
    [Name] NVARCHAR(200) NULL,
    [Email] NVARCHAR(100) NULL,
    [IsActive] INT NOT NULL DEFAULT 1,
    [CityId] UNIQUEIDENTIFIER NULL,
    [CountryId] UNIQUEIDENTIFIER NULL,
    [CreatedOn] DATETIME NULL DEFAULT GETDATE(),
    CONSTRAINT [PK_Organizations] PRIMARY KEY ([Id]),
    CONSTRAINT [FK_Org_City] FOREIGN KEY ([CityId])
        REFERENCES [dbo].[Cities]([Id]),
    CONSTRAINT [FK_Org_Country] FOREIGN KEY ([CountryId])
        REFERENCES [dbo].[Countries]([Id])
);

CREATE TABLE [dbo].[Patients] (
    [Id] UNIQUEIDENTIFIER NOT NULL,
    [FirstName] NVARCHAR(100) NOT NULL,
    [LastName] NVARCHAR(100) NOT NULL,
    [MRN] NVARCHAR(50) NOT NULL,
    [DateOfBirth] DATE NULL,
    [Gender] NVARCHAR(10) NULL,
    [OrganizationId] UNIQUEIDENTIFIER NOT NULL,
    [CityId] UNIQUEIDENTIFIER NULL,
    [IsActive] BIT NOT NULL DEFAULT 1,
    [CreatedOn] DATETIME NULL DEFAULT GETDATE(),
    CONSTRAINT [PK_Patients] PRIMARY KEY ([Id]),
    CONSTRAINT [FK_Patient_Org] FOREIGN KEY ([OrganizationId])
        REFERENCES [dbo].[Organizations]([Id]),
    CONSTRAINT [FK_Patient_City] FOREIGN KEY ([CityId])
        REFERENCES [dbo].[Cities]([Id])
);
```

This gives you **4 tables with relationships** — the tool will generate complete ERD, 20+ Prisma model fields, full documentation, 30+ UAT test cases, and flow diagrams from this single paste.