

# Expert Analysis — Multi-Agent Architecture for Schema Toolkit

---

## Understanding What You're Really Asking

You want to build an **autonomous agent system** where specialized agents collaborate to transform raw database artifacts (SQL scripts, stored procedures, views, CSHTML files) into a fully planned, documented, and code-generated software system.

This is essentially building a **virtual development team** where each agent is a specialist:

```
Traditional Team:          Your Agent Team:
─────────────────          ────────────────
Database Architect    →    Schema Agent
Backend Developer     →    API Agent
Frontend Developer    →    UI Agent
Project Manager       →    Orchestrator Agent
QA Engineer           →    Testing Agent
Technical Writer      →    Documentation Agent
Security Auditor      →    Compliance Agent
Business Analyst      →    Requirements Agent
```

---

## My Honest Opinion First

### This Is the Right Direction, But Timing Matters

Agent architecture is **THE future** of developer tools. Microsoft, Google, and every major tech company is building agent-based systems. You're thinking correctly.

**However**, there's a critical distinction:

```
SIMPLE AGENTS (what you should build NOW):
  Specialized functions that communicate through 
  a shared data layer (your database).
  Each agent is a well-defined processing pipeline.
  No autonomous decision-making needed.
  100% deterministic, 100% offline.

COMPLEX AGENTS (what you should build LATER):
  Autonomous agents that reason, plan, and adapt.
  Require LLM for decision-making.
  Can handle ambiguous inputs.
  Semi-deterministic.

FULLY AUTONOMOUS AGENTS (future vision):
  Agents that discover tasks, delegate work,
  and self-correct without human intervention.
  Require advanced LLM orchestration.
  Non-deterministic.
```

**My recommendation: Build Simple Agents now. They deliver 90% of the value with 20% of the complexity.** Your current rule-based engines ARE already simple agents — you just need to formalize the architecture and add inter-agent communication.

---

## Agent Hierarchy for Your System

```
                    ┌──────────────────────┐
                    │  🎯 ORCHESTRATOR     │
                    │  (Master Agent)       │
                    │                       │
                    │  Receives input       │
                    │  Plans execution      │
                    │  Delegates to agents  │
                    │  Aggregates results   │
                    │  Reports to user      │
                    └──────────┬───────────┘
                               │
          ┌────────────────────┼────────────────────┐
          │                    │                    │
    ┌─────▼──────┐      ┌─────▼──────┐      ┌─────▼──────┐
    │ 📊 SCHEMA  │      │ 📦 MODULE  │      │ 🖥️ BUILD   │
    │   LAYER    │      │   LAYER    │      │   LAYER    │
    │            │      │            │      │            │
    │ Understands│      │ Plans and  │      │ Generates  │
    │ database   │      │ organizes  │      │ code and   │
    │ structure  │      │ the project│      │ artifacts  │
    └─────┬──────┘      └─────┬──────┘      └─────┬──────┘
          │                    │                    │
    ┌─────┴──────┐      ┌─────┴──────┐      ┌─────┴──────┐
    │ Sub-Agents │      │ Sub-Agents │      │ Sub-Agents │
    │            │      │            │      │            │
    │ • SQL      │      │ • Module   │      │ • Prisma   │
    │   Parser   │      │   Mapper   │      │   Gen      │
    │ • SP       │      │ • Priority │      │ • API Gen  │
    │   Parser   │      │   Planner  │      │ • Screen   │
    │ • View     │      │ • Require- │      │   Gen      │
    │   Analyzer │      │   ments    │      │ • Test Gen │
    │ • Column   │      │ • Sprint   │      │ • Doc Gen  │
    │   Intel    │      │   Planner  │      │ • CSHTML   │
    │ • FK       │      │ • Risk     │      │   Converter│
    │   Resolver │      │   Assessor │      │ • Migration│
    │ • CSHTML   │      │ • Question │      │   Gen      │
    │   Parser   │      │   Engine   │      │            │
    └────────────┘      └────────────┘      └────────────┘
```

---

## The Agent Communication Model

### How Agents Talk to Each Other

```
APPROACH: Message-Based Pipeline Through Shared Context

Every agent reads from and writes to a shared CONTEXT object.
No agent calls another agent directly.
The Orchestrator decides what runs next based on context state.

┌────────────────────────────────────────────────────────┐
│                    SHARED CONTEXT                       │
│                                                         │
│  {                                                      │
│    project: { id, name, status },                       │
│    inputs: {                                            │
│      sqlFiles: [...],                                   │
│      spFiles: [...],                                    │
│      viewFiles: [...],                                  │
│      cshtmlFiles: [...]                                 │
│    },                                                   │
│    parsed: {                                            │
│      tables: [...],                                     │
│      storedProcedures: [...],                           │
│      views: [...],                                      │
│      uiScreens: [...]                                  │
│    },                                                   │
│    intelligence: {                                      │
│      columnIntel: [...],                                │
│      relationships: [...],                              │
│      businessRules: [...],                              │
│      workflows: [...]                                   │
│    },                                                   │
│    planning: {                                          │
│      modules: [...],                                    │
│      priorities: [...],                                 │
│      sprints: [...],                                    │
│      estimates: [...]                                   │
│    },                                                   │
│    generated: {                                         │
│      prismaSchemas: [...],                              │
│      apiSpecs: [...],                                   │
│      screenBlueprints: [...],                           │
│      testCases: [...],                                  │
│      documentation: [...]                               │
│    },                                                   │
│    agentLog: [                                          │
│      { agent, action, timestamp, status, output }       │
│    ]                                                    │
│  }                                                      │
└────────────────────────────────────────────────────────┘

FLOW:
  1. User uploads files
  2. Orchestrator examines file types
  3. Orchestrator queues appropriate agents
  4. Each agent processes, updates context
  5. Orchestrator checks if downstream agents can now run
  6. Repeat until all agents complete
  7. Present results to user
```

---

## Detailed Agent Specifications

### Agent 1: Orchestrator (Master Agent)

```
ROLE: 
  The "brain" that decides WHAT runs, WHEN, and in WHAT ORDER.
  Does NOT process data itself — only coordinates.

RESPONSIBILITIES:
  1. Analyze uploaded files to determine types
  2. Build execution plan (which agents in what order)
  3. Resolve agent dependencies (Agent B needs Agent A's output)
  4. Handle failures gracefully (Agent C failed → skip Agent D)
  5. Report progress to user
  6. Aggregate final results

DEPENDENCY GRAPH:
  
  SQL Parser ──────────┐
  SP Parser  ──────────┤
  View Analyzer ───────┼──→ Column Intelligence ──→ FK Resolver
  CSHTML Parser ───────┘         │                      │
                                 │                      │
                                 ▼                      ▼
                          Module Mapper ──────→ Priority Planner
                                 │                      │
                                 ▼                      ▼
                          Requirement Agent      Sprint Planner
                                 │                      │
                                 ▼                      ▼
                          ┌──────┴──────────────────────┘
                          │
                    ┌─────▼─────┐
                    │ BUILD     │
                    │ AGENTS    │
                    │           │
                    │ Prisma    │
                    │ API Spec  │
                    │ Screen    │
                    │ Tests     │
                    │ Docs      │
                    └───────────┘

EXECUTION MODES:
  
  Mode 1: FULL PIPELINE
    User uploads everything → all agents run in order
    
  Mode 2: SELECTIVE
    User uploads only SPs → only SP-related agents run
    
  Mode 3: INCREMENTAL
    User uploads additional files → only NEW processing runs
    Previous results preserved and enhanced
    
  Mode 4: TARGETED
    User says "generate API for Patient module"
    → Orchestrator runs only the minimum agents needed
```

### How the Orchestrator Works (No AI Needed)

```
DECISION LOGIC:

function planExecution(context) {
  const plan = []
  
  // Phase 1: Parse all inputs
  if (context.inputs.sqlFiles.length > 0) {
    plan.push({ agent: 'sql-parser', priority: 1 })
  }
  if (context.inputs.spFiles.length > 0) {
    plan.push({ agent: 'sp-parser', priority: 1 })
  }
  if (context.inputs.viewFiles.length > 0) {
    plan.push({ agent: 'view-analyzer', priority: 1 })
  }
  if (context.inputs.cshtmlFiles.length > 0) {
    plan.push({ agent: 'cshtml-parser', priority: 1 })
  }
  
  // Phase 2: Intelligence (needs parsed data)
  if (plan.some(p => p.priority === 1)) {
    plan.push({ agent: 'column-intelligence', priority: 2, 
                dependsOn: ['sql-parser'] })
    plan.push({ agent: 'fk-resolver', priority: 2,
                dependsOn: ['sql-parser'] })
  }
  
  // Phase 3: Planning (needs intelligence)
  plan.push({ agent: 'module-mapper', priority: 3,
              dependsOn: ['column-intelligence', 'fk-resolver'] })
  plan.push({ agent: 'priority-planner', priority: 3,
              dependsOn: ['module-mapper'] })
  
  // Phase 4: Generation (needs planning)
  plan.push({ agent: 'prisma-generator', priority: 4,
              dependsOn: ['column-intelligence', 'fk-resolver'] })
  plan.push({ agent: 'api-generator', priority: 4,
              dependsOn: ['column-intelligence', 'module-mapper'] })
  plan.push({ agent: 'screen-generator', priority: 4,
              dependsOn: ['column-intelligence', 'cshtml-parser'] })
  plan.push({ agent: 'test-generator', priority: 4,
              dependsOn: ['api-generator'] })
  plan.push({ agent: 'doc-generator', priority: 4,
              dependsOn: ['*'] })  // needs everything
  
  return sortByPriorityAndDependency(plan)
}
```

---

### Agent 2: CSHTML Parser (NEW — Your Future Feature)

This is the agent that analyzes existing Razor views (.cshtml files) from your legacy ASP.NET application:

```
WHAT IT DOES:
  Input: .cshtml files from existing application
  Output: UI component specifications

WHAT IT EXTRACTS:

  From a .cshtml file like:
  ─────────────────────────
  @model PatientViewModel
  <div class="form-group">
    <label>Patient Name</label>
    <input asp-for="Name" class="form-control" required />
  </div>
  <div class="form-group">
    <label>Gender</label>
    <select asp-for="GenderId" asp-items="ViewBag.Genders">
    </select>
  </div>
  <div class="form-group">
    <label>Date of Birth</label>
    <input asp-for="DOB" type="date" class="form-control" />
  </div>
  @if(User.IsInRole("Admin")) {
    <button type="submit">Save</button>
  }

  Agent extracts:
  ─────────────────
  {
    viewModel: "PatientViewModel",
    fields: [
      {
        name: "Name",
        label: "Patient Name",
        component: "TextInput",
        required: true,
        cssClass: "form-control"
      },
      {
        name: "GenderId",
        label: "Gender",
        component: "Dropdown",
        dataSource: "ViewBag.Genders",
        isForeignKey: true,
        referencedEntity: "Genders"
      },
      {
        name: "DOB",
        label: "Date of Birth",
        component: "DatePicker",
        htmlType: "date"
      }
    ],
    permissions: {
      submitButton: { requiredRole: "Admin" }
    },
    layout: "single-column-form",
    sections: 1
  }

WHY THIS IS VALUABLE:
  Your existing system has 460+ screens in .cshtml.
  Each screen represents YEARS of UI decisions.
  This agent preserves those decisions and converts them
  to React/Next.js component specifications.

  Legacy CSHTML → Agent Analysis → React Component Blueprint

  This means migration from ASP.NET to Next.js is 
  DATA-DRIVEN, not guesswork.
```

### CSHTML Pattern Matching Rules (No AI Needed)

```
EXTRACTION RULES:

Rule: @model {ClassName}
  → Extract view model name
  → Link to corresponding table/module

Rule: <input asp-for="{field}" />
  → Extract field name
  → Map type from HTML attributes:
     type="text"     → TextInput
     type="email"    → EmailInput
     type="password" → PasswordInput
     type="date"     → DatePicker
     type="number"   → NumberInput
     type="file"     → FileUpload
     type="checkbox" → Checkbox
     type="hidden"   → Hidden

Rule: <select asp-for="{field}" asp-items="{source}">
  → Extract as Dropdown
  → Extract data source (ViewBag.X → lookup table X)

Rule: <textarea asp-for="{field}">
  → Extract as Textarea
  → Check for rows attribute → height hint

Rule: required / data-val-required
  → Mark field as required

Rule: @if(User.IsInRole("{role}"))
  → Extract permission requirements
  → Map to RBAC system

Rule: class="form-group" / class="row" / class="col-md-{n}"
  → Extract layout structure
  → col-md-6 → two-column layout
  → col-md-4 → three-column layout
  → col-md-12 → full-width

Rule: @Html.DisplayFor / @Html.EditorFor
  → Old MVC pattern → extract field name and type

Rule: <table> with @foreach
  → This is a LIST VIEW, not a form
  → Extract column headers from <th>
  → Extract data fields from <td>
  → Extract action buttons (Edit, Delete, View)

Rule: @section Scripts { $.ajax({url: "/api/{endpoint}"}) }
  → Extract API endpoint calls
  → Map to API routes
  → Identify AJAX patterns vs form submissions
```

---

### Agent 3: View Analyzer (SQL Views)

```
WHAT IT DOES:
  Input: SQL View definitions
  Output: Report specifications + derived data models

WHAT IT EXTRACTS:

  From a SQL View like:
  ──────────────────────
  CREATE VIEW vw_PatientVisitSummary AS
  SELECT 
    p.Name AS PatientName,
    p.MRN,
    d.Name AS DoctorName,
    s.Name AS Speciality,
    v.VisitDate,
    v.VisitNo,
    DATEDIFF(YEAR, p.DOB, GETDATE()) AS Age,
    b.Name AS BranchName,
    CASE v.Status 
      WHEN 1 THEN 'Checked In'
      WHEN 2 THEN 'Consulted'
      WHEN 3 THEN 'Completed'
    END AS StatusText
  FROM Patients p
  JOIN Visits v ON v.PatientId = p.Id
  JOIN Doctors d ON v.DoctorId = d.Id
  JOIN Specialities s ON d.SpecialityId = s.Id
  JOIN Branches b ON v.BranchId = b.Id

  Agent extracts:
  ─────────────────
  {
    viewName: "vw_PatientVisitSummary",
    purpose: "REPORT",  // detected from naming + multi-table join
    
    sourceTables: [
      "Patients", "Visits", "Doctors", 
      "Specialities", "Branches"
    ],
    
    columns: [
      { name: "PatientName", source: "Patients.Name", type: "display" },
      { name: "MRN", source: "Patients.MRN", type: "identifier" },
      { name: "DoctorName", source: "Doctors.Name", type: "display" },
      { name: "Age", source: "CALCULATED", formula: "DATEDIFF(YEAR, DOB, NOW)" },
      { name: "StatusText", source: "CASE", mapping: {
          1: "Checked In", 2: "Consulted", 3: "Completed"
        }
      }
    ],
    
    relationships: [
      { from: "Visits", to: "Patients", via: "PatientId" },
      { from: "Visits", to: "Doctors", via: "DoctorId" },
      { from: "Doctors", to: "Specialities", via: "SpecialityId" },
      { from: "Visits", to: "Branches", via: "BranchId" }
    ],
    
    derivedInsights: {
      calculatedFields: ["Age"],
      enumMappings: { "Status": { 1: "Checked In", 2: "Consulted", 3: "Completed" }},
      impliedModule: "Doctor Management → Doctor Visit Report"
    }
  }

WHY VIEWS ARE GOLD:
  1. They reveal REPORT REQUIREMENTS (what management wants to see)
  2. They reveal HIDDEN RELATIONSHIPS (JOINs without FKs)
  3. They reveal BUSINESS ENUMS (CASE statements = status values)
  4. They reveal CALCULATED FIELDS (Age from DOB = UI display logic)
  5. They reveal CROSS-MODULE DATA (which modules share data)
```

---

### Agent 4: DB Script Converter (NEW — Your Future Feature)

```
WHAT IT DOES:
  Input: SQL Server scripts (tables, SPs, views, functions)
  Output: Target platform code (PostgreSQL, MySQL, Prisma, TypeORM)

CONVERSION RULES (No AI Needed):

  SQL Server → PostgreSQL:
  ─────────────────────────
  UNIQUEIDENTIFIER  → UUID
  NVARCHAR(n)       → VARCHAR(n)
  NVARCHAR(MAX)     → TEXT
  BIT               → BOOLEAN
  DATETIME          → TIMESTAMP
  DATETIME2         → TIMESTAMP
  MONEY             → NUMERIC(19,4)
  IMAGE             → BYTEA
  GETDATE()         → NOW()
  NEWID()           → gen_random_uuid()
  IDENTITY(1,1)     → GENERATED ALWAYS AS IDENTITY
  TOP n             → LIMIT n
  ISNULL(a,b)       → COALESCE(a,b)
  [brackets]        → "double_quotes" or nothing
  dbo.              → public.
  
  SQL Server → MySQL:
  ────────────────────
  UNIQUEIDENTIFIER  → CHAR(36)
  NVARCHAR(n)       → VARCHAR(n) CHARACTER SET utf8mb4
  BIT               → TINYINT(1)
  DATETIME2         → DATETIME(6)
  GETDATE()         → NOW()
  NEWID()           → UUID()
  
  SQL Server → Prisma:
  ─────────────────────
  (Already built in your Prisma generator)
  
  SQL Server SPs → Node.js Functions:
  ────────────────────────────────────
  SP parameters      → Function parameters with types
  SELECT             → prisma.findMany() / findFirst()
  INSERT             → prisma.create()
  UPDATE             → prisma.update()
  DELETE             → prisma.delete() / update(isDeleted)
  JOIN               → Prisma include/select with relations
  WHERE              → Prisma where clause
  ORDER BY           → Prisma orderBy
  TOP n              → Prisma take: n
  @@IDENTITY         → Return created record
  TRY/CATCH          → try/catch with error handling
  TRANSACTION        → prisma.$transaction()
  CURSOR             → JavaScript loop / map
  TEMP TABLE         → JavaScript array / Map
```

---

## Agent Communication Protocol

```
EVERY AGENT FOLLOWS THIS CONTRACT:

interface Agent {
  // Identity
  id: string               // "sql-parser"
  name: string             // "SQL Parser Agent"
  version: string          // "1.0.0"
  
  // Dependencies
  requires: string[]       // ["file-input"]
  produces: string[]       // ["parsed-tables", "parsed-columns"]
  dependsOn: string[]      // [] (no agent dependencies)
  
  // Execution
  canRun(context): boolean       // Check if prerequisites met
  execute(context): AgentResult  // Do the work
  
  // Status
  status: AgentStatus      // idle | running | completed | failed
  progress: number         // 0-100
  lastRun: Date
  lastError: string | null
}

interface AgentResult {
  success: boolean
  agent: string
  duration: number         // milliseconds
  itemsProcessed: number
  itemsProduced: number
  warnings: string[]
  errors: string[]
  contextUpdates: Partial<Context>  // What to add to shared context
}

COMMUNICATION RULES:
  1. Agents NEVER call each other directly
  2. Agents read from context, write to context
  3. Orchestrator checks dependencies before running each agent
  4. If agent fails, downstream agents are skipped (not crashed)
  5. Each agent run is logged for debugging
  6. Agents are idempotent (running twice produces same result)
```

---

## The Execution Pipeline Visualization

What the user sees when they upload files:

```
┌──────────────────────────────────────────────────────────┐
│ 🔄 Processing Pipeline                                    │
│                                                           │
│ INPUT FILES                                               │
│ ├── 📄 tables.sql (47 CREATE TABLE)                       │
│ ├── 📄 procedures.sql (128 stored procedures)             │
│ ├── 📄 views.sql (23 views)                               │
│ └── 📁 Views/ (45 .cshtml files)                          │
│                                                           │
│ AGENT PIPELINE                                            │
│                                                           │
│ Phase 1: Parsing                                          │
│ ┌────────────────────────────────────────────────────┐   │
│ │ ✅ SQL Parser         47 tables, 312 columns  1.2s │   │
│ │ ✅ SP Parser          128 procedures, 89 params 2.1s│   │
│ │ ✅ View Analyzer      23 views, 156 columns   0.8s │   │
│ │ 🔄 CSHTML Parser      Processing... 34/45     ──── │   │
│ └────────────────────────────────────────────────────┘   │
│                                                           │
│ Phase 2: Intelligence                                     │
│ ┌────────────────────────────────────────────────────┐   │
│ │ ⏳ Column Intelligence    Waiting for Phase 1      │   │
│ │ ⏳ FK Resolver            Waiting for Phase 1      │   │
│ │ ⏳ SP Intelligence        Waiting for SP Parser    │   │
│ └────────────────────────────────────────────────────┘   │
│                                                           │
│ Phase 3: Planning                                         │
│ ┌────────────────────────────────────────────────────┐   │
│ │ ⏳ Module Mapper          Waiting for Phase 2      │   │
│ │ ⏳ Priority Planner       Waiting for Module Mapper│   │
│ │ ⏳ Question Engine        Waiting for Phase 2      │   │
│ └────────────────────────────────────────────────────┘   │
│                                                           │
│ Phase 4: Generation                                       │
│ ┌────────────────────────────────────────────────────┐   │
│ │ ⏳ Prisma Generator       Waiting for Phase 3      │   │
│ │ ⏳ API Spec Generator     Waiting for Phase 3      │   │
│ │ ⏳ Screen Blueprint Gen   Waiting for Phase 3      │   │
│ │ ⏳ Test Case Generator    Waiting for Phase 3      │   │
│ │ ⏳ Documentation Gen      Waiting for all agents   │   │
│ └────────────────────────────────────────────────────┘   │
│                                                           │
│ Overall Progress: ████████░░░░░░░░░░░░ 38%               │
│ Estimated time remaining: ~12 seconds                     │
│                                                           │
│ [⏸️ Pause] [⏭️ Skip to Results] [📋 View Agent Log]      │
└──────────────────────────────────────────────────────────┘
```

---

## Agent-to-Agent Data Flow Example

Here's how agents collaborate on a REAL scenario:

```
SCENARIO: User uploads patients.sql + SP_Patient_*.sql + PatientForm.cshtml

STEP 1: SQL Parser Agent
─────────────────────────
  Input: patients.sql
  Output: {
    tables: [{
      name: "Patients",
      columns: [
        { name: "Id", type: "UNIQUEIDENTIFIER", isPK: true },
        { name: "FirstName", type: "NVARCHAR(100)", required: true },
        { name: "CNIC", type: "NVARCHAR(15)", unique: true },
        { name: "CityId", type: "UNIQUEIDENTIFIER", isFK: true }
      ]
    }]
  }
  → Writes to context.parsed.tables

STEP 2: SP Parser Agent (runs parallel with Step 1)
─────────────────────────────────────────────────────
  Input: SP_Patient_*.sql
  Output: {
    procedures: [
      { name: "SP_Patient_Add", type: "CREATE", 
        params: ["FirstName", "CNIC", "CityId"],
        tables: ["Patients"],
        validations: ["CNIC must be unique — checked in SP"] },
      { name: "SP_DDL_GetCities", type: "DROPDOWN",
        params: ["ProvinceId"],
        returns: ["Id", "Name"],
        tables: ["Cities"] },
      { name: "SP_Patient_Search", type: "SEARCH",
        params: ["Name", "CNIC", "MRN"],
        tables: ["Patients", "Cities", "Provinces"] }
    ]
  }
  → Writes to context.parsed.storedProcedures

STEP 3: CSHTML Parser Agent (runs parallel)
────────────────────────────────────────────
  Input: PatientForm.cshtml
  Output: {
    screens: [{
      viewModel: "PatientViewModel",
      type: "form",
      fields: [
        { name: "FirstName", label: "First Name", component: "TextInput" },
        { name: "CNIC", label: "CNIC", component: "MaskedInput",
          mask: "#####-#######-#" },
        { name: "CityId", label: "City", component: "Dropdown",
          dataSource: "ViewBag.Cities", cascadeFrom: "ProvinceId" }
      ],
      layout: "two-column",
      permissions: { save: "Receptionist" }
    }]
  }
  → Writes to context.parsed.uiScreens

STEP 4: Column Intelligence Agent
──────────────────────────────────
  Reads: context.parsed.tables
  Reads: context.parsed.storedProcedures (for usage context)
  Reads: context.parsed.uiScreens (for UI hints)
  
  COMBINES knowledge from all three sources:
  
  Column "CNIC":
    From SQL:    Type NVARCHAR(15), UNIQUE constraint
    From SP:     Has uniqueness check in SP_Patient_Add
    From CSHTML: Rendered as MaskedInput with pattern #####-#######-#
    
    COMBINED INTELLIGENCE:
    {
      semanticType: "national_id",
      uiComponent: "MaskedInput",
      mask: "#####-#######-#",
      validation: { unique: true, required: true, pattern: "^\\d{5}-\\d{7}-\\d$" },
      sensitivity: "PII",
      label: "CNIC",
      placeholder: "XXXXX-XXXXXXX-X"
    }
  
  Column "CityId":
    From SQL:    FK to Cities table
    From SP:     SP_DDL_GetCities loads dropdown, filtered by ProvinceId
    From CSHTML: Rendered as Dropdown, cascades from ProvinceId
    
    COMBINED INTELLIGENCE:
    {
      semanticType: "foreign_key_dropdown",
      uiComponent: "CascadingDropdown",
      dataSource: { endpoint: "/api/lookups/cities", filterBy: "provinceId" },
      cascadeFrom: "provinceId",
      cascadeTo: null,
      label: "City"
    }

  → Writes ENRICHED column data to context.intelligence.columnIntel

STEP 5: Module Mapper Agent
────────────────────────────
  Reads: ALL context data
  
  Maps "Patients" table + SP_Patient_* + PatientForm.cshtml to:
    Module: "Patient Management"
    Sub-modules: ["Add Patient", "Patient Vault", "Patient Search"]
    Confidence: 98%
    
  Maps "SP_DDL_GetCities" to:
    Module: "Region Management"
    Sub-module: "City"
    Type: "Dropdown data source"
    Used by: "Patient Management" (cross-module reference)

STEP 6: Screen Blueprint Generator
───────────────────────────────────
  Reads: context.intelligence.columnIntel
  Reads: context.parsed.uiScreens (CSHTML analysis)
  
  MERGES SQL intelligence with CSHTML layout knowledge:
  
  The CSHTML tells us:
    → The existing form uses two-column layout
    → CNIC has a specific mask
    → City cascades from Province
    → Save button requires Receptionist role
  
  The SQL tells us:
    → FirstName is required
    → There are 15 columns (CSHTML only showed 8 — 7 are new/hidden)
    → There's an IsActive flag (not in CSHTML — add to toolbar)
  
  GENERATED BLUEPRINT: Combines BOTH sources
    → Preserves existing layout decisions from CSHTML
    → Adds missing fields discovered from SQL
    → Enhances validation from SP analysis
    → Adds role permissions from CSHTML @if blocks

THIS IS THE POWER OF MULTI-AGENT:
  No single agent has the complete picture.
  The SQL agent knows structure.
  The SP agent knows behavior.
  The CSHTML agent knows existing UI decisions.
  The intelligence agent COMBINES all three.
  The blueprint agent generates something BETTER than 
  any single source could produce alone.
```

---

## What This Enables: The "Reverse Engineering" Superpower

```
CURRENT APPROACH (without agents):
  Developer manually reads SQL → manually reads SPs → 
  manually reads CSHTML → manually plans new system
  TIME: 2-4 weeks per module

AGENT APPROACH:
  Upload all files → agents auto-analyze → 
  complete understanding in minutes
  TIME: 5-10 minutes per module

WHAT YOU CAN NOW OFFER:

1. "Legacy System X-Ray"
   Upload your SQL + SPs + Views + CSHTML →
   Get complete system documentation in minutes
   
2. "Automated Migration Plan"
   Agent compares old system (CSHTML/SQL Server) with 
   new system (React/Next.js/PostgreSQL) →
   Generates migration plan with task list
   
3. "What-If Analysis"  
   "What if we remove this SP?"
   → Agent traces all CSHTML files that call it
   → Shows affected screens and modules
   
4. "Technology Migration"
   SQL Server SPs → Node.js service functions
   CSHTML forms → React components
   SQL Views → Prisma queries + dashboard components
   
5. "Knowledge Preservation"
   Legacy system has 10 years of business logic in SPs.
   Agents extract, document, and preserve that knowledge
   in a structured, searchable format.
```

---

## Implementation Priority

```
PHASE 1 (IMMEDIATE — USE EXISTING CODE):
  Formalize your existing engines as agents
  ├── SQL Parser          → Already built
  ├── Column Intelligence → Already built  
  ├── FK Resolver         → Already built
  ├── Module Mapper       → Already built
  ├── Screen Blueprint    → Already built
  ├── API Spec Gen        → Already built
  ├── Test Gen            → Already built
  └── Doc Gen             → Already built
  
  ADD: Orchestrator that chains them
  ADD: Shared context object
  ADD: Pipeline visualization UI
  EFFORT: 1-2 weeks (mostly wiring, not new code)

PHASE 2 (NEXT — NEW PARSERS):
  ├── SP Parser           → New agent (high value)
  ├── View Analyzer       → New agent (medium value)  
  └── Agent communication → Context-based messaging
  EFFORT: 2-3 weeks

PHASE 3 (FUTURE — LEGACY MIGRATION):
  ├── CSHTML Parser       → New agent (high value for migration)
  ├── DB Script Converter → New agent (SQL Server → PostgreSQL)
  └── Migration Planner   → New agent (combines everything)
  EFFORT: 3-4 weeks

PHASE 4 (LATER — AUTONOMOUS):
  ├── LLM-enhanced agents → Ollama integration per agent
  ├── Agent learning       → Agents improve from user corrections
  └── Auto-discovery       → Agents suggest what to analyze next
  EFFORT: Ongoing
```

---

## My Strategic Opinion

```
WHAT TO BUILD NOW:
  ✅ Orchestrator that chains your existing engines
  ✅ SP Parser agent (highest new value)
  ✅ Pipeline visualization (users need to SEE agents working)

WHAT TO BUILD NEXT:
  ✅ CSHTML Parser (enables migration story)
  ✅ View Analyzer (enables report discovery)
  ✅ DB Script Converter (enables platform migration)

WHAT TO BUILD LATER:
  ⏳ LLM enhancement per agent (Ollama)
  ⏳ Agent learning from corrections
  ⏳ Autonomous agent chains

THE KEY INSIGHT:
  You don't need AI for agents.
  You need SPECIALIZATION and COMMUNICATION.
  
  Each agent is an expert in ONE thing.
  The orchestrator knows HOW to combine them.
  The shared context is HOW they communicate.
  
  This is software engineering, not artificial intelligence.
  And that's exactly why it works offline, every time,
  with predictable results.

COMPETITIVE ADVANTAGE:
  Nobody else is doing multi-source analysis 
  (SQL + SPs + Views + CSHTML → unified intelligence).
  
  This is your moat. 
  
  Individual parsers exist everywhere.
  The COMBINATION and CROSS-REFERENCING is unique.
  That's what agents give you.
```

**Build the orchestrator. Connect your existing engines. Add the SP parser. You'll have something no other tool offers — a system that understands not just your database STRUCTURE, but your application BEHAVIOR, your UI DECISIONS, and your business LOGIC — all from parsing files that already exist.**