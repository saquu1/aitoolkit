
# 🏗️ AI-Powered SaaS HIS Builder — Complete System

This extends your Schema Toolkit into a full **AI-assisted SaaS product builder** that understands your database, asks intelligent questions, and generates everything layer by layer.

---

## Extended Project Structure

```
schema-toolkit/
├── prisma/
│   └── schema.prisma              # Extended with new models
├── src/
│   ├── app/
│   │   ├── layout.tsx
│   │   ├── page.tsx
│   │   ├── globals.css
│   │   ├── upload/page.tsx         # (existing)
│   │   ├── erd/page.tsx            # (existing)
│   │   ├── prisma-gen/page.tsx     # (existing)
│   │   ├── documentation/page.tsx  # (existing)
│   │   ├── uat/page.tsx            # (existing)
│   │   ├── flows/page.tsx          # (existing)
│   │   │
│   │   │── ai-chat/page.tsx        # AI conversation engine
│   │   │── layers/page.tsx         # Layer-by-layer builder
│   │   │── layers/[layer]/page.tsx # Individual layer detail
│   │   │── modules/page.tsx        # Module dependency map
│   │   │── modules/[id]/page.tsx   # Module detail + generator
│   │   │── architecture/page.tsx   # Architecture planner
│   │   │── saas-checklist/page.tsx # SaaS product checklist
│   │   │── requirements/page.tsx   # AI requirement gatherer
│   │   │── api-designer/page.tsx   # API endpoint designer
│   │   │── roadmap/page.tsx        # Product roadmap
│   │   │
│   │   ├── api/
│   │   │   ├── ai-analyze/route.ts
│   │   │   ├── ai-chat/route.ts
│   │   │   ├── generate-module/route.ts
│   │   │   ├── generate-architecture/route.ts
│   │   │   ├── generate-api-specs/route.ts
│   │   │   ├── generate-requirements/route.ts
│   │   │   ├── layer-analysis/route.ts
│   │   │   └── saas-checklist/route.ts
│   │
│   ├── lib/
│   │   ├── ai-engine.ts            # AI logic engine
│   │   ├── layer-definitions.ts    # HIS layer configs
│   │   ├── module-registry.ts      # All HIS modules
│   │   ├── architecture-gen.ts     # Architecture generator
│   │   ├── api-spec-generator.ts   # API spec generator
│   │   ├── requirement-engine.ts   # Requirement analyzer
│   │   ├── saas-framework.ts       # SaaS design framework
│   │   ├── dependency-resolver.ts  # Module dependencies
│   │   ├── schema-intelligence.ts  # AI schema understanding
│   │   ├── code-generator.ts       # Full code generator
│   │   └── (existing files...)
│   │
│   └── components/
│       ├── AIChatWindow.tsx
│       ├── LayerCard.tsx
│       ├── ModuleCard.tsx
│       ├── DependencyGraph.tsx
│       ├── ArchitectureDiagram.tsx
│       ├── ChecklistTracker.tsx
│       ├── RequirementForm.tsx
│       ├── RoadmapTimeline.tsx
│       └── (existing components...)
```

---

## 1. Extended Prisma Schema

```prisma
// prisma/schema.prisma — ADD these models to existing schema

model AIConversation {
  id        String    @id @default(uuid())
  projectId String?
  title     String
  context   String    @default("general")
  createdAt DateTime  @default(now())
  messages  AIMessage[]
}

model AIMessage {
  id             String         @id @default(uuid())
  conversationId String
  role           String         // "user" | "ai" | "system"
  content        String
  metadata       String?        // JSON string for structured data
  createdAt      DateTime       @default(now())
  conversation   AIConversation @relation(fields: [conversationId], references: [id], onDelete: Cascade)
}

model ModulePlan {
  id           String   @id @default(uuid())
  projectId    String?
  layerNumber  Int
  layerName    String
  moduleName   String
  moduleKey    String
  status       String   @default("planned") // planned | in_progress | completed | skipped
  priority     Int      @default(0)
  dependencies String?  // JSON array of module keys
  tables       String?  // JSON array of table names
  apiEndpoints String?  // JSON string
  notes        String?
  createdAt    DateTime @default(now())
  updatedAt    DateTime @updatedAt
}

model SaaSChecklist {
  id          String  @id @default(uuid())
  projectId   String?
  category    String
  item        String
  description String?
  isCompleted Boolean @default(false)
  priority    String  @default("medium")
  phase       String  // design | development | testing | deployment | post-launch
  order       Int     @default(0)
}

model Requirement {
  id          String   @id @default(uuid())
  projectId   String?
  moduleKey   String?
  category    String   // functional | non-functional | technical | business
  title       String
  description String
  priority    String   @default("medium")
  status      String   @default("draft")
  aiGenerated Boolean  @default(false)
  userStory   String?
  acceptance  String?  // JSON array of acceptance criteria
  createdAt   DateTime @default(now())
}
```

```bash
npx prisma migrate dev --name add-ai-models
```

---

## 2. HIS Layer Definitions (Complete Knowledge Base)

```typescript
// src/lib/layer-definitions.ts

export interface LayerModule {
  key: string
  name: string
  description: string
  tables: string[]
  dependsOn: string[]
  apiEndpoints: string[]
  priority: 'critical' | 'high' | 'medium' | 'low'
  revenue: boolean
  estimatedDays: number
  features: string[]
  userRoles: string[]
}

export interface Layer {
  number: number
  name: string
  title: string
  description: string
  icon: string
  color: string
  modules: LayerModule[]
}

export const HIS_LAYERS: Layer[] = [
  // ──────────────────────────────────────────────────
  // LAYER 1 — FOUNDATION
  // ──────────────────────────────────────────────────
  {
    number: 1,
    name: 'foundation',
    title: '🧱 LAYER 1 — FOUNDATION',
    description: 'Master Data Layer — Everything depends on this. Must be built first.',
    icon: '🧱',
    color: 'blue',
    modules: [
      {
        key: 'org-setup',
        name: 'Organization Setup',
        description: 'Multi-tenant organization management with hierarchy',
        tables: [
          'Organizations', 'OrganizationTypes', 'OrganizationBranches',
          'OrganizationSettings', 'OrganizationLicenses'
        ],
        dependsOn: [],
        apiEndpoints: [
          'GET /api/organizations',
          'POST /api/organizations',
          'PUT /api/organizations/:id',
          'DELETE /api/organizations/:id',
          'GET /api/organizations/:id/branches',
          'POST /api/organizations/:id/settings'
        ],
        priority: 'critical',
        revenue: false,
        estimatedDays: 5,
        features: [
          'Multi-tenant organization creation',
          'Branch/location management',
          'Organization hierarchy (parent-child)',
          'Settings per organization',
          'License management',
          'Logo and branding per org'
        ],
        userRoles: ['SuperAdmin', 'OrgAdmin']
      },
      {
        key: 'user-auth',
        name: 'Users, Roles & Authentication',
        description: 'Complete user management with RBAC and multi-tenant isolation',
        tables: [
          'Users', 'Roles', 'UserRoles', 'Permissions', 'RolePermissions',
          'UserSessions', 'UserLoginHistory', 'PasswordResets'
        ],
        dependsOn: ['org-setup'],
        apiEndpoints: [
          'POST /api/auth/login',
          'POST /api/auth/register',
          'POST /api/auth/refresh',
          'POST /api/auth/logout',
          'POST /api/auth/forgot-password',
          'GET /api/users',
          'POST /api/users',
          'PUT /api/users/:id',
          'GET /api/roles',
          'POST /api/roles',
          'PUT /api/roles/:id/permissions'
        ],
        priority: 'critical',
        revenue: false,
        estimatedDays: 8,
        features: [
          'JWT + Refresh token authentication',
          'Role-based access control (RBAC)',
          'Permission-level access (granular)',
          'Multi-tenant user isolation',
          'Login history & audit trail',
          'Password policy enforcement',
          'Session management',
          'Two-factor authentication (optional)'
        ],
        userRoles: ['SuperAdmin', 'OrgAdmin', 'IT Admin']
      },
      {
        key: 'geography',
        name: 'Geography Master',
        description: 'Countries, provinces, cities used everywhere',
        tables: ['Countries', 'Provinces', 'Cities', 'Areas'],
        dependsOn: [],
        apiEndpoints: [
          'GET /api/countries',
          'GET /api/countries/:id/provinces',
          'GET /api/provinces/:id/cities',
          'GET /api/cities/:id/areas'
        ],
        priority: 'critical',
        revenue: false,
        estimatedDays: 2,
        features: [
          'Country management',
          'Province/state cascading',
          'City management',
          'Area/locality management',
          'Cascading dropdowns support'
        ],
        userRoles: ['SuperAdmin']
      },
      {
        key: 'lookup-data',
        name: 'Lookup & Reference Data',
        description: 'All dropdown values, categories, and reference data',
        tables: [
          'LookupCategories', 'LookupValues', 'Titles', 'Genders',
          'MaritalStatuses', 'BloodGroups', 'Nationalities', 'Languages',
          'Religions', 'Ethnicities'
        ],
        dependsOn: [],
        apiEndpoints: [
          'GET /api/lookups',
          'GET /api/lookups/:category',
          'POST /api/lookups',
          'PUT /api/lookups/:id'
        ],
        priority: 'critical',
        revenue: false,
        estimatedDays: 3,
        features: [
          'Dynamic lookup categories',
          'Configurable dropdown values',
          'Active/inactive status',
          'Sort order management',
          'Bulk import/export',
          'Multi-language support'
        ],
        userRoles: ['SuperAdmin', 'OrgAdmin']
      },
      {
        key: 'department-setup',
        name: 'Department & Facility Setup',
        description: 'Hospital departments, wards, rooms, beds',
        tables: [
          'Departments', 'DepartmentTypes', 'Wards', 'Rooms', 'Beds',
          'BedTypes', 'Facilities', 'FacilityTypes'
        ],
        dependsOn: ['org-setup'],
        apiEndpoints: [
          'GET /api/departments',
          'POST /api/departments',
          'GET /api/departments/:id/wards',
          'GET /api/wards/:id/beds',
          'PUT /api/beds/:id/status'
        ],
        priority: 'critical',
        revenue: false,
        estimatedDays: 5,
        features: [
          'Department CRUD with hierarchy',
          'Ward management (IPD)',
          'Room and bed management',
          'Bed availability tracking',
          'Facility configuration',
          'Department-wise settings'
        ],
        userRoles: ['OrgAdmin', 'DeptAdmin']
      },
      {
        key: 'employee-doctor',
        name: 'Employee & Doctor Management',
        description: 'Staff registry including doctors, nurses, technicians',
        tables: [
          'Employees', 'EmployeeTypes', 'Doctors', 'DoctorSpecializations',
          'Specializations', 'DoctorSchedules', 'DoctorDepartments',
          'Designations', 'EmployeeDepartments', 'DoctorFees'
        ],
        dependsOn: ['org-setup', 'department-setup', 'geography'],
        apiEndpoints: [
          'GET /api/employees',
          'POST /api/employees',
          'GET /api/doctors',
          'POST /api/doctors',
          'GET /api/doctors/:id/schedule',
          'POST /api/doctors/:id/schedule',
          'GET /api/doctors/:id/fees',
          'GET /api/specializations'
        ],
        priority: 'critical',
        revenue: false,
        estimatedDays: 7,
        features: [
          'Employee registration with documents',
          'Doctor profile management',
          'Specialization mapping',
          'Schedule/availability management',
          'Department assignment',
          'Fee structure per doctor',
          'Doctor dashboard'
        ],
        userRoles: ['HRAdmin', 'OrgAdmin', 'Doctor']
      },
      {
        key: 'service-catalog',
        name: 'Service & Pricing Catalog',
        description: 'All hospital services with pricing tiers',
        tables: [
          'Services', 'ServiceCategories', 'ServicePricing',
          'PricingTiers', 'Packages', 'PackageServices',
          'ServiceDepartments', 'InsuranceServicePricing'
        ],
        dependsOn: ['org-setup', 'department-setup'],
        apiEndpoints: [
          'GET /api/services',
          'POST /api/services',
          'GET /api/services/:id/pricing',
          'POST /api/services/:id/pricing',
          'GET /api/packages',
          'POST /api/packages'
        ],
        priority: 'critical',
        revenue: true,
        estimatedDays: 6,
        features: [
          'Service category hierarchy',
          'Multi-tier pricing (walk-in, panel, insurance)',
          'Package management (health checkup packages)',
          'Department-service mapping',
          'Insurance-specific pricing',
          'Discount rules per service'
        ],
        userRoles: ['OrgAdmin', 'FinanceAdmin']
      }
    ]
  },

  // ──────────────────────────────────────────────────
  // LAYER 2 — CORE TRANSACTIONS
  // ──────────────────────────────────────────────────
  {
    number: 2,
    name: 'core-transactions',
    title: '⚙️ LAYER 2 — CORE TRANSACTION ENGINE',
    description: 'Patient flow, visits, appointments — the operational backbone',
    icon: '⚙️',
    color: 'green',
    modules: [
      {
        key: 'patient-reg',
        name: 'Patient Registration (MPI)',
        description: 'Master Patient Index — central patient registry',
        tables: [
          'Patients', 'PatientContacts', 'PatientInsurance',
          'PatientDocuments', 'PatientHistory', 'PatientAllergies',
          'PatientNextOfKin', 'PatientMRN'
        ],
        dependsOn: ['org-setup', 'geography', 'lookup-data'],
        apiEndpoints: [
          'GET /api/patients',
          'POST /api/patients',
          'PUT /api/patients/:id',
          'GET /api/patients/:id',
          'GET /api/patients/search',
          'GET /api/patients/:id/history',
          'POST /api/patients/:id/documents',
          'GET /api/patients/:id/insurance'
        ],
        priority: 'critical',
        revenue: false,
        estimatedDays: 8,
        features: [
          'Patient registration with demographics',
          'Auto MRN generation',
          'Duplicate detection (name, phone, CNIC)',
          'Patient search (fuzzy + exact)',
          'Contact management',
          'Insurance card linking',
          'Document upload',
          'Patient merge capability',
          'QR code generation',
          'Patient portal access'
        ],
        userRoles: ['Receptionist', 'Registration', 'Nurse']
      },
      {
        key: 'appointment',
        name: 'Appointment Management',
        description: 'Doctor appointment scheduling system',
        tables: [
          'Appointments', 'AppointmentSlots', 'AppointmentStatuses',
          'AppointmentTypes', 'DoctorAvailability', 'AppointmentReminders'
        ],
        dependsOn: ['patient-reg', 'employee-doctor'],
        apiEndpoints: [
          'GET /api/appointments',
          'POST /api/appointments',
          'PUT /api/appointments/:id',
          'PUT /api/appointments/:id/status',
          'GET /api/doctors/:id/slots',
          'GET /api/appointments/calendar'
        ],
        priority: 'high',
        revenue: true,
        estimatedDays: 7,
        features: [
          'Slot-based scheduling',
          'Doctor availability calendar',
          'Walk-in vs scheduled',
          'Appointment status workflow',
          'SMS/Email reminders',
          'Reschedule & cancel',
          'Waitlist management',
          'Online booking support'
        ],
        userRoles: ['Receptionist', 'Patient', 'Doctor']
      },
      {
        key: 'opd-visit',
        name: 'OPD Visit Management',
        description: 'Outpatient department visit tracking',
        tables: [
          'OPDVisits', 'OPDVisitServices', 'OPDQueue',
          'OPDVitals', 'VisitTypes', 'TokenManagement'
        ],
        dependsOn: ['patient-reg', 'appointment', 'employee-doctor', 'service-catalog'],
        apiEndpoints: [
          'POST /api/opd/visits',
          'GET /api/opd/visits/:id',
          'PUT /api/opd/visits/:id',
          'GET /api/opd/queue',
          'POST /api/opd/visits/:id/vitals',
          'GET /api/opd/today-summary'
        ],
        priority: 'critical',
        revenue: true,
        estimatedDays: 8,
        features: [
          'Visit creation from appointment/walk-in',
          'Token number generation',
          'Queue management',
          'Vitals recording (BP, temp, weight, etc.)',
          'Visit-service linking',
          'Doctor assignment',
          'Visit summary',
          'Follow-up scheduling'
        ],
        userRoles: ['Receptionist', 'Nurse', 'Doctor']
      },
      {
        key: 'ipd-admission',
        name: 'IPD Admission & Discharge',
        description: 'Inpatient admission, transfer, discharge (ADT)',
        tables: [
          'IPDAdmissions', 'IPDTransfers', 'IPDDischarges',
          'BedAllocation', 'IPDDailyCharges', 'IPDServices',
          'AdmissionTypes', 'DischargeTypes'
        ],
        dependsOn: ['patient-reg', 'department-setup', 'employee-doctor', 'service-catalog'],
        apiEndpoints: [
          'POST /api/ipd/admit',
          'GET /api/ipd/admissions',
          'PUT /api/ipd/admissions/:id',
          'POST /api/ipd/admissions/:id/transfer',
          'POST /api/ipd/admissions/:id/discharge',
          'GET /api/ipd/bed-availability',
          'GET /api/ipd/admissions/:id/charges'
        ],
        priority: 'critical',
        revenue: true,
        estimatedDays: 12,
        features: [
          'Admission from ER/OPD',
          'Bed allocation with availability check',
          'Bed transfer between wards',
          'Daily charge calculation',
          'Doctor assignment (attending/consulting)',
          'Discharge workflow (summary, clearance)',
          'Against medical advice (AMA) discharge',
          'Patient census dashboard'
        ],
        userRoles: ['Receptionist', 'Nurse', 'Doctor', 'WardManager']
      },
      {
        key: 'emergency',
        name: 'Emergency / ER Module',
        description: 'Emergency department with triage',
        tables: [
          'ERVisits', 'ERTriage', 'TriageLevels',
          'ERBedAllocation', 'ERDisposition'
        ],
        dependsOn: ['patient-reg', 'employee-doctor', 'department-setup'],
        apiEndpoints: [
          'POST /api/er/visits',
          'POST /api/er/visits/:id/triage',
          'PUT /api/er/visits/:id/disposition',
          'GET /api/er/dashboard'
        ],
        priority: 'high',
        revenue: true,
        estimatedDays: 8,
        features: [
          'Quick registration (minimal data)',
          'Triage assessment (ESI levels)',
          'ER bed tracking',
          'Disposition (admit/discharge/transfer)',
          'ER dashboard with real-time status',
          'Time tracking (door-to-doctor)'
        ],
        userRoles: ['ERNurse', 'ERDoctor', 'Receptionist']
      }
    ]
  },

  // ──────────────────────────────────────────────────
  // LAYER 3 — REVENUE-GENERATING MODULES
  // ──────────────────────────────────────────────────
  {
    number: 3,
    name: 'revenue',
    title: '💰 LAYER 3 — REVENUE-GENERATING MODULES',
    description: 'Billing, pharmacy, lab — these modules generate direct revenue',
    icon: '💰',
    color: 'yellow',
    modules: [
      {
        key: 'billing',
        name: 'Billing & Invoicing',
        description: 'Complete billing engine with multi-payer support',
        tables: [
          'Invoices', 'InvoiceItems', 'InvoicePayments', 'PaymentMethods',
          'Receipts', 'Refunds', 'CreditNotes', 'BillingCategories',
          'DiscountRules', 'TaxRules', 'InvoiceStatuses'
        ],
        dependsOn: ['patient-reg', 'service-catalog', 'opd-visit', 'ipd-admission'],
        apiEndpoints: [
          'POST /api/billing/invoices',
          'GET /api/billing/invoices/:id',
          'POST /api/billing/invoices/:id/pay',
          'POST /api/billing/refunds',
          'GET /api/billing/daily-collection',
          'GET /api/billing/outstanding'
        ],
        priority: 'critical',
        revenue: true,
        estimatedDays: 15,
        features: [
          'OPD/IPD/ER billing',
          'Multi-payment method (cash, card, online)',
          'Partial payment support',
          'Discount management (%, flat, approval)',
          'Tax calculation',
          'Credit note & refund',
          'Insurance claim billing',
          'Package billing',
          'Daily collection report',
          'Outstanding management',
          'Receipt printing'
        ],
        userRoles: ['Cashier', 'BillingAdmin', 'FinanceManager']
      },
      {
        key: 'pharmacy',
        name: 'Pharmacy Management',
        description: 'Drug inventory, dispensing, and sales',
        tables: [
          'Drugs', 'DrugCategories', 'DrugManufacturers', 'DrugGenericNames',
          'PharmacyStock', 'PharmacyPurchaseOrders', 'PharmacyPurchaseItems',
          'PharmacyDispensing', 'PharmacyDispensingItems', 'PharmacySales',
          'DrugInteractions', 'PharmacyStores', 'StockTransfers',
          'PharmacyReturns', 'BatchTracking', 'ExpiryAlerts'
        ],
        dependsOn: ['patient-reg', 'billing', 'employee-doctor'],
        apiEndpoints: [
          'GET /api/pharmacy/drugs',
          'POST /api/pharmacy/drugs',
          'GET /api/pharmacy/stock',
          'POST /api/pharmacy/purchase-orders',
          'POST /api/pharmacy/dispense',
          'GET /api/pharmacy/expiring',
          'POST /api/pharmacy/sales',
          'GET /api/pharmacy/stock-alerts'
        ],
        priority: 'critical',
        revenue: true,
        estimatedDays: 18,
        features: [
          'Drug master with generic/brand names',
          'Multi-store inventory management',
          'Purchase order workflow',
          'GRN (Goods Received Note)',
          'Prescription-based dispensing',
          'OTC (over-the-counter) sales',
          'Batch & expiry tracking',
          'Auto reorder level alerts',
          'Stock transfer between stores',
          'Return management',
          'Drug interaction warnings',
          'Barcode support',
          'Controlled substance tracking'
        ],
        userRoles: ['Pharmacist', 'PharmacyAdmin', 'Doctor']
      },
      {
        key: 'laboratory',
        name: 'Laboratory (LIS)',
        description: 'Lab test ordering, sample tracking, results',
        tables: [
          'LabTests', 'LabTestCategories', 'LabTestParameters',
          'LabOrders', 'LabOrderItems', 'LabSamples', 'SampleTypes',
          'LabResults', 'LabResultValues', 'LabProfiles',
          'LabProfileTests', 'LabMachineInterfaces', 'NormalRanges'
        ],
        dependsOn: ['patient-reg', 'billing', 'employee-doctor'],
        apiEndpoints: [
          'GET /api/lab/tests',
          'POST /api/lab/orders',
          'GET /api/lab/orders/:id',
          'POST /api/lab/orders/:id/collect-sample',
          'POST /api/lab/orders/:id/results',
          'GET /api/lab/worklist',
          'GET /api/lab/reports/:id'
        ],
        priority: 'critical',
        revenue: true,
        estimatedDays: 15,
        features: [
          'Test catalog with parameters',
          'Test profiles/panels',
          'Order entry (doctor/reception)',
          'Sample collection & barcode',
          'Sample tracking workflow',
          'Result entry with normal ranges',
          'Auto-flagging abnormal values',
          'Report generation (PDF)',
          'Machine interface (HL7/ASTM)',
          'Critical value alerts',
          'Quality control',
          'TAT tracking'
        ],
        userRoles: ['LabTechnician', 'Pathologist', 'Doctor', 'Receptionist']
      },
      {
        key: 'radiology',
        name: 'Radiology (RIS)',
        description: 'Imaging orders, scheduling, reporting',
        tables: [
          'RadiologyExams', 'RadiologyCategories', 'RadiologyOrders',
          'RadiologySchedule', 'RadiologyReports', 'RadiologyTemplates',
          'Modalities', 'DicomStudies'
        ],
        dependsOn: ['patient-reg', 'billing', 'employee-doctor'],
        apiEndpoints: [
          'GET /api/radiology/exams',
          'POST /api/radiology/orders',
          'POST /api/radiology/orders/:id/report',
          'GET /api/radiology/worklist',
          'GET /api/radiology/reports/:id'
        ],
        priority: 'high',
        revenue: true,
        estimatedDays: 12,
        features: [
          'Exam catalog management',
          'Order entry',
          'Modality worklist (MWL)',
          'Structured reporting with templates',
          'PACS integration',
          'DICOM viewer link',
          'Report approval workflow'
        ],
        userRoles: ['Radiologist', 'RadTechnician', 'Doctor']
      },
      {
        key: 'insurance',
        name: 'Insurance & Panel Management',
        description: 'Insurance companies, policies, claims processing',
        tables: [
          'InsuranceCompanies', 'InsurancePlans', 'InsurancePolicies',
          'PatientPolicies', 'InsuranceClaims', 'ClaimItems',
          'ClaimStatuses', 'PreAuthorization', 'PanelCompanies',
          'PanelPricing', 'CorporateContracts'
        ],
        dependsOn: ['patient-reg', 'billing', 'service-catalog'],
        apiEndpoints: [
          'GET /api/insurance/companies',
          'POST /api/insurance/claims',
          'GET /api/insurance/claims/:id',
          'PUT /api/insurance/claims/:id/status',
          'POST /api/insurance/pre-auth',
          'GET /api/insurance/outstanding'
        ],
        priority: 'high',
        revenue: true,
        estimatedDays: 12,
        features: [
          'Insurance company management',
          'Plan/policy management',
          'Patient policy linking',
          'Claim submission workflow',
          'Pre-authorization',
          'Panel company contracts',
          'Corporate billing',
          'Claim status tracking',
          'Receivable aging reports',
          'Reconciliation'
        ],
        userRoles: ['InsuranceOfficer', 'BillingAdmin', 'FinanceManager']
      }
    ]
  },

  // ──────────────────────────────────────────────────
  // LAYER 4 — CLINICAL EXPANSION
  // ──────────────────────────────────────────────────
  {
    number: 4,
    name: 'clinical',
    title: '🏥 LAYER 4 — CLINICAL EXPANSION',
    description: 'EMR, prescriptions, clinical workflows',
    icon: '🏥',
    color: 'red',
    modules: [
      {
        key: 'emr',
        name: 'Electronic Medical Records (EMR)',
        description: 'Clinical documentation and medical history',
        tables: [
          'ClinicalNotes', 'NoteTemplates', 'ClinicalEncounters',
          'Diagnoses', 'ICD10Codes', 'PatientDiagnoses',
          'Procedures', 'CPTCodes', 'ClinicalForms', 'FormResponses'
        ],
        dependsOn: ['patient-reg', 'opd-visit', 'ipd-admission', 'employee-doctor'],
        apiEndpoints: [
          'POST /api/emr/notes',
          'GET /api/emr/patients/:id/history',
          'POST /api/emr/encounters/:id/diagnoses',
          'GET /api/emr/templates',
          'POST /api/emr/forms/:id/submit'
        ],
        priority: 'high',
        revenue: false,
        estimatedDays: 20,
        features: [
          'SOAP note documentation',
          'Template-based documentation',
          'ICD-10 diagnosis coding',
          'Problem list management',
          'Clinical form builder',
          'History timeline view',
          'Voice-to-text (optional)',
          'Clinical decision support'
        ],
        userRoles: ['Doctor', 'Nurse', 'ClinicalStaff']
      },
      {
        key: 'prescription',
        name: 'E-Prescription',
        description: 'Electronic prescription with drug interaction checks',
        tables: [
          'Prescriptions', 'PrescriptionItems', 'PrescriptionTemplates',
          'DrugFavorites', 'DrugDoseForms', 'DrugRoutes',
          'DrugFrequencies', 'DrugAllergies'
        ],
        dependsOn: ['emr', 'pharmacy', 'patient-reg'],
        apiEndpoints: [
          'POST /api/prescriptions',
          'GET /api/prescriptions/:id',
          'GET /api/prescriptions/patient/:id',
          'POST /api/prescriptions/:id/dispense'
        ],
        priority: 'high',
        revenue: false,
        estimatedDays: 10,
        features: [
          'Drug search with autocomplete',
          'Dosage form selection',
          'Frequency and duration',
          'Drug allergy alerts',
          'Drug interaction checking',
          'Doctor favorites/templates',
          'Prescription printing',
          'Direct pharmacy integration',
          'Prescription renewal'
        ],
        userRoles: ['Doctor', 'Pharmacist']
      },
      {
        key: 'nursing',
        name: 'Nursing Module',
        description: 'Nursing assessment, care plans, MAR',
        tables: [
          'NursingAssessments', 'CarePlans', 'CareActivities',
          'MedicationAdministration', 'VitalSigns', 'IntakeOutput',
          'NursingNotes', 'NursingShifts'
        ],
        dependsOn: ['ipd-admission', 'patient-reg', 'prescription'],
        apiEndpoints: [
          'POST /api/nursing/assessments',
          'POST /api/nursing/vitals',
          'POST /api/nursing/medications/administer',
          'GET /api/nursing/mar/:admissionId',
          'POST /api/nursing/io'
        ],
        priority: 'medium',
        revenue: false,
        estimatedDays: 12,
        features: [
          'Nursing assessment forms',
          'Vitals monitoring',
          'Medication Administration Record (MAR)',
          'I/O charting',
          'Care plan management',
          'Shift handover notes',
          'Fall risk assessment',
          'Pain assessment'
        ],
        userRoles: ['Nurse', 'HeadNurse']
      },
      {
        key: 'ot-management',
        name: 'Operation Theater (OT)',
        description: 'Surgical scheduling and OT management',
        tables: [
          'OperationTheaters', 'OTSchedule', 'SurgicalProcedures',
          'OTTeams', 'OTConsumables', 'SurgicalNotes',
          'AnesthesiaRecords', 'PreOpAssessments', 'PostOpNotes'
        ],
        dependsOn: ['ipd-admission', 'employee-doctor', 'billing'],
        apiEndpoints: [
          'GET /api/ot/theaters',
          'POST /api/ot/schedule',
          'GET /api/ot/schedule/calendar',
          'POST /api/ot/procedures/:id/notes'
        ],
        priority: 'medium',
        revenue: true,
        estimatedDays: 12,
        features: [
          'OT scheduling calendar',
          'Surgical team assignment',
          'Pre-op assessment',
          'Anesthesia record',
          'OT consumable tracking',
          'Surgical notes',
          'Post-op monitoring',
          'OT utilization reports'
        ],
        userRoles: ['Surgeon', 'Anesthesiologist', 'OTNurse', 'OTScheduler']
      }
    ]
  },

  // ──────────────────────────────────────────────────
  // LAYER 5 — ENTERPRISE & ACCOUNTING
  // ──────────────────────────────────────────────────
  {
    number: 5,
    name: 'enterprise',
    title: '🏢 LAYER 5 — ENTERPRISE & ACCOUNTING',
    description: 'Financial accounting, HR, inventory — enterprise backbone',
    icon: '🏢',
    color: 'purple',
    modules: [
      {
        key: 'general-ledger',
        name: 'General Ledger & Chart of Accounts',
        description: 'Double-entry accounting system',
        tables: [
          'ChartOfAccounts', 'AccountTypes', 'JournalEntries',
          'JournalLines', 'FiscalYears', 'FiscalPeriods',
          'AccountBalances', 'CostCenters'
        ],
        dependsOn: ['org-setup', 'billing'],
        apiEndpoints: [
          'GET /api/accounting/accounts',
          'POST /api/accounting/journal-entries',
          'GET /api/accounting/trial-balance',
          'GET /api/accounting/balance-sheet',
          'GET /api/accounting/income-statement'
        ],
        priority: 'high',
        revenue: false,
        estimatedDays: 15,
        features: [
          'Chart of accounts management',
          'Double-entry journal entries',
          'Auto posting from billing',
          'Trial balance',
          'Balance sheet',
          'Income statement',
          'Cost center tracking',
          'Fiscal year management',
          'Period closing'
        ],
        userRoles: ['Accountant', 'FinanceManager', 'CFO']
      },
      {
        key: 'accounts-receivable',
        name: 'Accounts Receivable',
        description: 'Track money owed to the hospital',
        tables: [
          'ARInvoices', 'ARPayments', 'ARAgingReport',
          'CustomerAccounts', 'PaymentPlans'
        ],
        dependsOn: ['general-ledger', 'billing', 'insurance'],
        apiEndpoints: [
          'GET /api/ar/outstanding',
          'GET /api/ar/aging',
          'POST /api/ar/payments',
          'GET /api/ar/customer/:id'
        ],
        priority: 'high',
        revenue: false,
        estimatedDays: 8,
        features: [
          'Insurance receivable tracking',
          'Patient receivable tracking',
          'Aging analysis',
          'Payment plan management',
          'Write-off management',
          'Dunning notices'
        ],
        userRoles: ['ARClerk', 'FinanceManager']
      },
      {
        key: 'accounts-payable',
        name: 'Accounts Payable',
        description: 'Track money hospital owes to vendors',
        tables: [
          'Vendors', 'PurchaseOrders', 'PurchaseOrderItems',
          'GoodsReceivedNotes', 'APInvoices', 'APPayments',
          'VendorContracts'
        ],
        dependsOn: ['general-ledger'],
        apiEndpoints: [
          'GET /api/ap/vendors',
          'POST /api/ap/purchase-orders',
          'POST /api/ap/grn',
          'POST /api/ap/payments',
          'GET /api/ap/aging'
        ],
        priority: 'medium',
        revenue: false,
        estimatedDays: 10,
        features: [
          'Vendor management',
          'Purchase order workflow',
          'GRN matching',
          'Invoice processing',
          'Payment scheduling',
          'Vendor aging report'
        ],
        userRoles: ['PurchaseOfficer', 'AccountsPayable', 'FinanceManager']
      },
      {
        key: 'inventory',
        name: 'Inventory & Supply Chain',
        description: 'General hospital inventory management',
        tables: [
          'InventoryItems', 'ItemCategories', 'Warehouses',
          'StockLevels', 'StockMovements', 'StoreRequisitions',
          'IssueNotes', 'InventoryAdjustments'
        ],
        dependsOn: ['org-setup', 'department-setup'],
        apiEndpoints: [
          'GET /api/inventory/items',
          'GET /api/inventory/stock',
          'POST /api/inventory/requisitions',
          'POST /api/inventory/issues',
          'POST /api/inventory/adjustments'
        ],
        priority: 'medium',
        revenue: false,
        estimatedDays: 10,
        features: [
          'Item master management',
          'Multi-warehouse support',
          'Requisition workflow',
          'Issue note generation',
          'Stock adjustment/write-off',
          'Reorder alerts',
          'Consumption reports'
        ],
        userRoles: ['StoreKeeper', 'DeptManager', 'PurchaseOfficer']
      },
      {
        key: 'hr-payroll',
        name: 'HR & Payroll',
        description: 'Human resource management and payroll processing',
        tables: [
          'HREmployees', 'LeaveTypes', 'LeaveApplications',
          'AttendanceRecords', 'PayrollRuns', 'SalaryComponents',
          'EmployeeSalaries', 'PaySlips', 'Deductions', 'Allowances'
        ],
        dependsOn: ['employee-doctor', 'general-ledger'],
        apiEndpoints: [
          'POST /api/hr/leave-apply',
          'GET /api/hr/attendance',
          'POST /api/hr/payroll/run',
          'GET /api/hr/payslips/:employeeId'
        ],
        priority: 'medium',
        revenue: false,
        estimatedDays: 15,
        features: [
          'Leave management',
          'Attendance tracking',
          'Salary structure',
          'Payroll processing',
          'Pay slip generation',
          'Statutory deductions',
          'Overtime calculation',
          'Employee self-service'
        ],
        userRoles: ['HRManager', 'Employee', 'PayrollOfficer']
      }
    ]
  },

  // ──────────────────────────────────────────────────
  // LAYER 6 — ADVANCED OPTIMIZATION
  // ──────────────────────────────────────────────────
  {
    number: 6,
    name: 'optimization',
    title: '🤖 LAYER 6 — ADVANCED OPTIMIZATION',
    description: 'AI-powered analytics, automation, patient engagement',
    icon: '🤖',
    color: 'indigo',
    modules: [
      {
        key: 'analytics',
        name: 'Analytics & Business Intelligence',
        description: 'Dashboards, KPIs, and reporting engine',
        tables: [
          'DashboardConfigs', 'ReportTemplates', 'ReportSchedules',
          'KPIDefinitions', 'KPIValues', 'DataExports'
        ],
        dependsOn: ['billing', 'patient-reg', 'laboratory', 'pharmacy'],
        apiEndpoints: [
          'GET /api/analytics/dashboard',
          'GET /api/analytics/kpis',
          'POST /api/analytics/reports/generate',
          'GET /api/analytics/revenue/trend'
        ],
        priority: 'medium',
        revenue: false,
        estimatedDays: 15,
        features: [
          'Executive dashboard',
          'Revenue analytics',
          'Patient volume trends',
          'Department-wise analytics',
          'Custom report builder',
          'Scheduled report delivery',
          'Export to Excel/PDF',
          'Drill-down capability'
        ],
        userRoles: ['CEO', 'CFO', 'DeptHead', 'Admin']
      },
      {
        key: 'patient-portal',
        name: 'Patient Portal & Mobile App',
        description: 'Patient-facing portal for self-service',
        tables: [
          'PortalUsers', 'PortalSessions', 'OnlineAppointments',
          'PatientNotifications', 'Feedback', 'PatientMessages'
        ],
        dependsOn: ['patient-reg', 'appointment', 'laboratory', 'billing'],
        apiEndpoints: [
          'POST /api/portal/register',
          'POST /api/portal/login',
          'GET /api/portal/appointments',
          'GET /api/portal/results',
          'GET /api/portal/bills',
          'POST /api/portal/feedback'
        ],
        priority: 'medium',
        revenue: true,
        estimatedDays: 12,
        features: [
          'Patient self-registration',
          'Online appointment booking',
          'Lab results viewing',
          'Bill viewing & payment',
          'Prescription history',
          'Feedback & ratings',
          'Push notifications',
          'Telemedicine link'
        ],
        userRoles: ['Patient']
      },
      {
        key: 'notifications',
        name: 'Notification Engine',
        description: 'Multi-channel notifications (SMS, Email, Push, WhatsApp)',
        tables: [
          'NotificationTemplates', 'NotificationQueue',
          'NotificationLogs', 'NotificationChannels',
          'SubscriptionPreferences'
        ],
        dependsOn: ['org-setup', 'patient-reg'],
        apiEndpoints: [
          'POST /api/notifications/send',
          'GET /api/notifications/templates',
          'GET /api/notifications/logs',
          'PUT /api/notifications/preferences'
        ],
        priority: 'medium',
        revenue: false,
        estimatedDays: 8,
        features: [
          'SMS notifications',
          'Email notifications',
          'Push notifications',
          'WhatsApp integration',
          'Template management',
          'Delivery tracking',
          'Preference management',
          'Bulk notifications'
        ],
        userRoles: ['Admin', 'System']
      },
      {
        key: 'audit-compliance',
        name: 'Audit Trail & Compliance',
        description: 'Complete audit logging and regulatory compliance',
        tables: [
          'AuditLogs', 'DataChangeHistory', 'AccessLogs',
          'ComplianceRules', 'ComplianceChecks', 'ConsentForms',
          'PatientConsents'
        ],
        dependsOn: ['user-auth'],
        apiEndpoints: [
          'GET /api/audit/logs',
          'GET /api/audit/data-changes/:entity/:id',
          'GET /api/audit/access-report',
          'GET /api/compliance/status'
        ],
        priority: 'high',
        revenue: false,
        estimatedDays: 8,
        features: [
          'Every action logged (who, what, when)',
          'Data change history (before/after)',
          'Access logging',
          'HIPAA compliance tracking',
          'Consent management',
          'Data retention policies',
          'Export audit reports',
          'Anomaly detection'
        ],
        userRoles: ['ComplianceOfficer', 'SuperAdmin', 'Auditor']
      }
    ]
  }
]

// ─── Helpers ──────────────────────────────────────

export function getAllModules(): LayerModule[] {
  return HIS_LAYERS.flatMap(l => l.modules)
}

export function getModuleByKey(key: string): LayerModule | undefined {
  return getAllModules().find(m => m.key === key)
}

export function getLayerByModule(moduleKey: string): Layer | undefined {
  return HIS_LAYERS.find(l => l.modules.some(m => m.key === moduleKey))
}

export function getDependencyChain(moduleKey: string): string[] {
  const visited = new Set<string>()
  const chain: string[] = []

  function resolve(key: string) {
    if (visited.has(key)) return
    visited.add(key)
    const mod = getModuleByKey(key)
    if (!mod) return
    for (const dep of mod.dependsOn) {
      resolve(dep)
    }
    chain.push(key)
  }

  resolve(moduleKey)
  return chain
}

export function getModuleStats() {
  const all = getAllModules()
  return {
    totalModules: all.length,
    totalTables: all.reduce((a, m) => a + m.tables.length, 0),
    totalAPIs: all.reduce((a, m) => a + m.apiEndpoints.length, 0),
    totalDays: all.reduce((a, m) => a + m.estimatedDays, 0),
    revenueModules: all.filter(m => m.revenue).length,
    criticalModules: all.filter(m => m.priority === 'critical').length
  }
}
```

---

## 3. AI Engine (Schema Intelligence)

```typescript
// src/lib/ai-engine.ts

import { TableDef } from './types'
import { HIS_LAYERS, getAllModules, getDependencyChain, getModuleByKey } from './layer-definitions'

export interface AIResponse {
  message: string
  suggestions?: string[]
  data?: any
  actions?: AIAction[]
}

export interface AIAction {
  type: 'generate' | 'navigate' | 'info' | 'warning' | 'checklist'
  label: string
  payload: any
}

export class SchemaAI {
  private tables: TableDef[]
  private projectName: string

  constructor(tables: TableDef[], projectName: string = 'HIS Project') {
    this.tables = tables
    this.projectName = projectName
  }

  analyze(question: string): AIResponse {
    const q = question.toLowerCase().trim()

    // ─── Schema Analysis Questions ───
    if (q.includes('analyze') || q.includes('overview') || q.includes('summary')) {
      return this.schemaOverview()
    }

    if (q.includes('missing') || q.includes('what am i missing') || q.includes('gaps')) {
      return this.findMissingTables()
    }

    if (q.includes('layer') || q.includes('layers')) {
      return this.layerAnalysis()
    }

    if (q.includes('start') || q.includes('where do i begin') || q.includes('first')) {
      return this.whereToStart()
    }

    if (q.includes('dependency') || q.includes('dependencies') || q.includes('order')) {
      return this.buildOrder()
    }

    if (q.includes('revenue') || q.includes('money') || q.includes('earning')) {
      return this.revenueAnalysis()
    }

    if (q.includes('timeline') || q.includes('how long') || q.includes('estimate')) {
      return this.timelineEstimate()
    }

    if (q.includes('relationship') || q.includes('foreign key') || q.includes('connected')) {
      return this.relationshipAnalysis()
    }

    if (q.includes('saas') || q.includes('multi-tenant') || q.includes('product')) {
      return this.saasAdvice()
    }

    if (q.includes('security') || q.includes('auth') || q.includes('permission')) {
      return this.securityAdvice()
    }

    if (q.includes('api') || q.includes('endpoint')) {
      return this.apiAdvice()
    }

    if (q.includes('architecture') || q.includes('microservice') || q.includes('structure')) {
      return this.architectureAdvice()
    }

    if (q.includes('priority') || q.includes('critical') || q.includes('important')) {
      return this.priorityAnalysis()
    }

    // ─── Table-specific questions ───
    const tableMatch = this.tables.find(t =>
      q.includes(t.tableName.toLowerCase())
    )
    if (tableMatch) {
      return this.tableAnalysis(tableMatch)
    }

    // ─── Module-specific questions ───
    const allModules = getAllModules()
    const moduleMatch = allModules.find(m =>
      q.includes(m.key.toLowerCase()) || q.includes(m.name.toLowerCase())
    )
    if (moduleMatch) {
      return this.moduleAnalysis(moduleMatch)
    }

    // ─── Default ───
    return this.defaultResponse(question)
  }

  // ─── Analysis Methods ─────────────────────────

  private schemaOverview(): AIResponse {
    const totalCols = this.tables.reduce((a, t) => a + t.columns.length, 0)
    const totalFKs = this.tables.reduce((a, t) => a + t.foreignKeys.length, 0)
    const tablesWithPK = this.tables.filter(t => t.columns.some(c => c.isPrimaryKey))
    const tablesWithoutFK = this.tables.filter(t => t.foreignKeys.length === 0)
    const mostConnected = [...this.tables]
      .sort((a, b) => b.foreignKeys.length - a.foreignKeys.length)
      .slice(0, 5)

    return {
      message: `## 📊 Schema Analysis — ${this.projectName}

### Overview
| Metric | Value |
|--------|-------|
| Total Tables | **${this.tables.length}** |
| Total Columns | **${totalCols}** |
| Total Foreign Keys | **${totalFKs}** |
| Tables with PK | **${tablesWithPK.length}** |
| Master Tables (no FK) | **${tablesWithoutFK.length}** |

### Master Tables (No Foreign Keys — Foundation)
${tablesWithoutFK.map(t => `- **${t.tableName}** (${t.columns.length} columns)`).join('\n')}

### Most Connected Tables
${mostConnected.map(t => `- **${t.tableName}** — ${t.foreignKeys.length} relationships`).join('\n')}

### 🧠 AI Assessment
${this.tables.length < 20
  ? '⚠️ Your schema has fewer than 20 tables. For a complete HIS, you typically need 100-200+ tables. I can help identify what is missing.'
  : this.tables.length < 50
    ? '📋 Your schema has a moderate number of tables. Let me check which HIS modules are covered and which are missing.'
    : '✅ Your schema has a substantial number of tables. Let me analyze coverage across all HIS layers.'}`,
      suggestions: [
        'What tables am I missing?',
        'Show me the layer analysis',
        'What should I build first?',
        'Show me the build order',
        'Which modules generate revenue?'
      ]
    }
  }

  private findMissingTables(): AIResponse {
    const existingNames = new Set(this.tables.map(t => t.tableName.toLowerCase()))
    const allModules = getAllModules()

    const coverage: { module: string; found: string[]; missing: string[] }[] = []

    for (const mod of allModules) {
      const found: string[] = []
      const missing: string[] = []
      for (const table of mod.tables) {
        if (existingNames.has(table.toLowerCase())) {
          found.push(table)
        } else {
          missing.push(table)
        }
      }
      if (missing.length > 0 || found.length > 0) {
        coverage.push({ module: mod.name, found, missing })
      }
    }

    const totalExpected = allModules.reduce((a, m) => a + m.tables.length, 0)
    const totalFound = coverage.reduce((a, c) => a + c.found.length, 0)
    const totalMissing = coverage.reduce((a, c) => a + c.missing.length, 0)

    const criticalMissing = coverage
      .filter(c => {
        const mod = allModules.find(m => m.name === c.module)
        return mod?.priority === 'critical' && c.missing.length > 0
      })

    return {
      message: `## 🔍 Missing Tables Analysis

### Coverage Summary
| Metric | Count |
|--------|-------|
| Your Tables | **${this.tables.length}** |
| Expected HIS Tables | **${totalExpected}** |
| Matched | **${totalFound}** ✅ |
| Missing | **${totalMissing}** ❌ |
| Coverage | **${Math.round((totalFound / totalExpected) * 100)}%** |

### 🚨 Critical Missing (Must Build First)
${criticalMissing.map(c => `
**${c.module}**
- ✅ Found: ${c.found.length > 0 ? c.found.join(', ') : 'None'}
- ❌ Missing: ${c.missing.join(', ')}`).join('\n')}

### 📋 All Modules Coverage
${coverage.map(c => {
  const pct = c.found.length / (c.found.length + c.missing.length) * 100
  const bar = pct >= 80 ? '🟢' : pct >= 50 ? '🟡' : pct > 0 ? '🟠' : '🔴'
  return `${bar} **${c.module}** — ${Math.round(pct)}% (${c.found.length}/${c.found.length + c.missing.length})`
}).join('\n')}

### 🧠 AI Recommendation
${criticalMissing.length > 0
  ? `You need to create tables for **${criticalMissing.length} critical modules** first. I can generate the complete SQL/Prisma schema for any of these.`
  : `Your schema covers the critical modules well! Focus on completing the medium-priority modules next.`}`,
      suggestions: [
        'Generate missing tables for patient registration',
        'Show me the build order',
        'Which modules should I skip for MVP?',
        'Generate Prisma schema for billing module'
      ]
    }
  }

  private layerAnalysis(): AIResponse {
    const existingNames = new Set(this.tables.map(t => t.tableName.toLowerCase()))

    const layerData = HIS_LAYERS.map(layer => {
      let found = 0
      let total = 0
      for (const mod of layer.modules) {
        for (const table of mod.tables) {
          total++
          if (existingNames.has(table.toLowerCase())) found++
        }
      }
      return {
        ...layer,
        found,
        total,
        percentage: total > 0 ? Math.round((found / total) * 100) : 0
      }
    })

    return {
      message: `## 🏗️ Layer-by-Layer Analysis

${layerData.map(l => {
  const bar = '█'.repeat(Math.round(l.percentage / 5)) + '░'.repeat(20 - Math.round(l.percentage / 5))
  return `### ${l.title}
> ${l.description}

\`[${bar}] ${l.percentage}%\` (${l.found}/${l.total} tables)

Modules: ${l.modules.map(m => {
  const modFound = m.tables.filter(t => existingNames.has(t.toLowerCase())).length
  return modFound === m.tables.length ? `✅ ${m.name}` : modFound > 0 ? `🟡 ${m.name}` : `❌ ${m.name}`
}).join(' | ')}
`}).join('\n---\n')}

### 🧠 AI Recommendation
**Build Order:** ${layerData
  .filter(l => l.percentage < 100)
  .sort((a, b) => a.number - b.number)
  .map(l => `Layer ${l.number}`)
  .join(' → ')}

${layerData[0].percentage < 50
  ? '⚠️ **Your Foundation (Layer 1) is incomplete!** You MUST complete Layer 1 before building anything else.'
  : '✅ Foundation layer looks good. You can proceed to transaction modules.'}`,
      suggestions: [
        'Tell me about Layer 1 in detail',
        'What should I build first?',
        'Generate all Layer 1 tables',
        'Show dependency chain'
      ]
    }
  }

  private whereToStart(): AIResponse {
    const existingNames = new Set(this.tables.map(t => t.tableName.toLowerCase()))
    const allModules = getAllModules()

    // Find first incomplete critical module
    const incomplete = allModules
      .filter(m => m.priority === 'critical')
      .filter(m => m.tables.some(t => !existingNames.has(t.toLowerCase())))
      .sort((a, b) => {
        const aDeps = a.dependsOn.length
        const bDeps = b.dependsOn.length
        return aDeps - bDeps
      })

    const firstModule = incomplete[0]
    const chain = firstModule ? getDependencyChain(firstModule.key) : []

    return {
      message: `## 🚀 Where To Start

### Recommended Build Sequence

${chain.map((key, i) => {
  const mod = getModuleByKey(key)!
  const layer = HIS_LAYERS.find(l => l.modules.some(m => m.key === key))!
  const complete = mod.tables.every(t => existingNames.has(t.toLowerCase()))
  return `**Step ${i + 1}:** ${complete ? '✅' : '🔨'} **${mod.name}** (Layer ${layer.number})
   - Tables: ${mod.tables.length} | APIs: ${mod.apiEndpoints.length} | Est: ${mod.estimatedDays} days
   - ${complete ? 'Already complete!' : `Need to create: ${mod.tables.filter(t => !existingNames.has(t.toLowerCase())).join(', ')}`}`
}).join('\n\n')}

### 🧠 AI Recommendation

**Start with: ${firstModule?.name || 'All critical modules complete!'}**

${firstModule ? `
This module needs these tables:
${firstModule.tables.map(t => `- ${existingNames.has(t.toLowerCase()) ? '✅' : '❌'} ${t}`).join('\n')}

Dependencies that must exist first:
${firstModule.dependsOn.length > 0 ? firstModule.dependsOn.map(d => {
  const dep = getModuleByKey(d)
  return `- ${dep?.name}: ${dep?.tables.every(t => existingNames.has(t.toLowerCase())) ? '✅ Complete' : '❌ Incomplete'}`
}).join('\n') : '- None (this is a foundation module)'}` : 'All critical modules are complete! Move to revenue modules.'}`,
      suggestions: [
        `Generate schema for ${firstModule?.name || 'billing'}`,
        'Show me the full build timeline',
        'What is the MVP scope?',
        'Generate all foundation tables'
      ]
    }
  }

  private buildOrder(): AIResponse {
    const allModules = getAllModules()
    const ordered: string[] = []
    const visited = new Set<string>()

    function visit(key: string) {
      if (visited.has(key)) return
      visited.add(key)
      const mod = getModuleByKey(key)
      if (!mod) return
      for (const dep of mod.dependsOn) visit(dep)
      ordered.push(key)
    }

    // Visit critical first, then high, then medium
    const priorities = ['critical', 'high', 'medium', 'low']
    for (const p of priorities) {
      for (const mod of allModules.filter(m => m.priority === p)) {
        visit(mod.key)
      }
    }

    let totalDays = 0
    return {
      message: `## 📋 Recommended Build Order

${ordered.map((key, i) => {
  const mod = getModuleByKey(key)!
  const layer = HIS_LAYERS.find(l => l.modules.some(m => m.key === key))!
  totalDays += mod.estimatedDays
  return `### ${i + 1}. ${mod.name}
| Property | Value |
|----------|-------|
| Layer | ${layer.title} |
| Priority | ${mod.priority.toUpperCase()} |
| Tables | ${mod.tables.length} |
| APIs | ${mod.apiEndpoints.length} |
| Estimated | ${mod.estimatedDays} days |
| Running Total | ${totalDays} days |
| Revenue | ${mod.revenue ? '💰 Yes' : 'No'} |
| Depends On | ${mod.dependsOn.length > 0 ? mod.dependsOn.map(d => getModuleByKey(d)?.name).join(', ') : 'None'} |`
}).join('\n\n---\n\n')}

### 📊 Summary
- **Total Modules:** ${ordered.length}
- **Total Estimated Days:** ${totalDays}
- **Total Tables:** ${allModules.reduce((a, m) => a + m.tables.length, 0)}
- **Total API Endpoints:** ${allModules.reduce((a, m) => a + m.apiEndpoints.length, 0)}`,
      suggestions: [
        'Generate schema for the first 3 modules',
        'What is the MVP scope?',
        'Show me revenue modules only',
        'Timeline with team of 3 developers'
      ]
    }
  }

  private revenueAnalysis(): AIResponse {
    const revModules = getAllModules().filter(m => m.revenue)

    return {
      message: `## 💰 Revenue-Generating Modules

These modules directly contribute to hospital revenue and should be prioritized for ROI:

${revModules.map((m, i) => {
  const layer = HIS_LAYERS.find(l => l.modules.some(mod => mod.key === m.key))!
  return `### ${i + 1}. ${m.name}
- **Layer:** ${layer.title}
- **Priority:** ${m.priority}
- **Revenue Streams:** ${m.features.filter(f =>
  f.toLowerCase().includes('billing') ||
  f.toLowerCase().includes('sales') ||
  f.toLowerCase().includes('payment') ||
  f.toLowerCase().includes('pricing')
).join(', ') || 'Service fees'}
- **Estimated Dev Time:** ${m.estimatedDays} days
- **Tables:** ${m.tables.join(', ')}`
}).join('\n\n---\n\n')}

### 🧠 Revenue Optimization Strategy
1. **Phase 1 (Month 1-2):** OPD Billing → Immediate cash flow
2. **Phase 2 (Month 2-3):** Pharmacy + Lab → Highest revenue modules
3. **Phase 3 (Month 3-4):** Insurance Claims → Recurring revenue
4. **Phase 4 (Month 4+):** Patient Portal → Online payments & bookings

### 💡 SaaS Revenue Tip
For your SaaS product, consider:
- **Per-module pricing** — sell pharmacy, lab separately
- **Per-bed pricing** — scale with hospital size
- **Transaction-based** — % of billing processed
- **Tiered plans** — Basic / Professional / Enterprise`,
      suggestions: [
        'Generate billing module schema',
        'Show me SaaS pricing strategy',
        'Generate pharmacy module complete',
        'What is MVP for fastest revenue?'
      ]
    }
  }

  private timelineEstimate(): AIResponse {
    const allModules = getAllModules()

    const phases = [
      { name: 'MVP (Foundation + Core)', months: 3, modules: allModules.filter(m => m.priority === 'critical') },
      { name: 'Phase 2 (Revenue)', months: 2, modules: allModules.filter(m => m.priority === 'high' && m.revenue) },
      { name: 'Phase 3 (Clinical)', months: 3, modules: allModules.filter(m => m.priority === 'high' && !m.revenue) },
      { name: 'Phase 4 (Enterprise)', months: 3, modules: allModules.filter(m => m.priority === 'medium') },
      { name: 'Phase 5 (Advanced)', months: 2, modules: allModules.filter(m => m.priority === 'low') },
    ]

    const totalDays = allModules.reduce((a, m) => a + m.estimatedDays, 0)

    return {
      message: `## ⏱️ Development Timeline Estimate

### Team Size Impact
| Team Size | Total Duration | Cost (approx) |
|-----------|---------------|---------------|
| 1 Dev | ${totalDays} days (~${Math.ceil(totalDays / 22)} months) | Budget |
| 2 Devs | ${Math.ceil(totalDays / 1.7)} days (~${Math.ceil(totalDays / 22 / 1.7)} months) | Moderate |
| 3 Devs | ${Math.ceil(totalDays / 2.3)} days (~${Math.ceil(totalDays / 22 / 2.3)} months) | Professional |
| 5 Devs | ${Math.ceil(totalDays / 3.5)} days (~${Math.ceil(totalDays / 22 / 3.5)} months) | Enterprise |

### Phase-wise Breakdown (3-Dev Team)

${phases.map(p => `**${p.name}** — ~${p.months} months
${p.modules.map(m => `  - ${m.name} (${m.estimatedDays} days)`).join('\n')}`).join('\n\n')}

### 🧠 AI Recommendation for Solo/Small Team
1. **Month 1-2:** Complete Layer 1 Foundation (all master data)
2. **Month 3:** Patient Registration + OPD
3. **Month 4:** Billing (start generating revenue!)
4. **Month 5:** Lab OR Pharmacy (pick one)
5. **Month 6:** The other one + Insurance
6. **Month 7-8:** Clinical modules (EMR, Prescription)
7. **Month 9+:** Enterprise features

### ⚡ Quick Win Strategy
Build **Foundation → OPD → Billing** first = you have a **working billable product in 3 months!**`,
      suggestions: [
        'Generate the MVP scope',
        'Show me Week-by-Week plan for Month 1',
        'What can I skip for MVP?',
        'Generate all foundation modules now'
      ]
    }
  }

  private relationshipAnalysis(): AIResponse {
    const fkCount = this.tables.reduce((a, t) => a + t.foreignKeys.length, 0)
    const isolated = this.tables.filter(t => {
      const hasFK = t.foreignKeys.length > 0
      const isReferenced = this.tables.some(other =>
        other.foreignKeys.some(fk =>
          fk.referencesTable.toLowerCase() === t.tableName.toLowerCase()
        )
      )
      return !hasFK && !isReferenced
    })

    const mostReferenced = this.tables
      .map(t => ({
        name: t.tableName,
        refs: this.tables.filter(other =>
          other.foreignKeys.some(fk =>
            fk.referencesTable.toLowerCase() === t.tableName.toLowerCase()
          )
        ).length
      }))
      .sort((a, b) => b.refs - a.refs)
      .slice(0, 10)

    return {
      message: `## 🔗 Relationship Analysis

### Statistics
| Metric | Value |
|--------|-------|
| Total Relationships | **${fkCount}** |
| Isolated Tables | **${isolated.length}** |

### 🏆 Most Referenced Tables (Core Entities)
${mostReferenced.map((t, i) => `${i + 1}. **${t.name}** — referenced by ${t.refs} tables`).join('\n')}

${isolated.length > 0 ? `### ⚠️ Isolated Tables (No Relationships)
These tables have no foreign keys and are not referenced by others:
${isolated.map(t => `- ${t.tableName}`).join('\n')}

These might be:
- Lookup/reference tables (OK if intentional)
- Missing relationships (should be connected)
- Standalone utility tables` : '### ✅ No isolated tables found!'}

### 🧠 AI Recommendation
${mostReferenced[0]?.refs > 5
  ? `**${mostReferenced[0].name}** is highly central to your schema. Ensure it has proper indexing and caching strategy.`
  : 'Consider adding more relationships to ensure data integrity.'}`,
      suggestions: [
        'Show me the ERD diagram',
        'Which tables need more relationships?',
        'Generate missing foreign keys',
        'Show data flow diagram'
      ]
    }
  }

  private saasAdvice(): AIResponse {
    return {
      message: `## 🚀 SaaS Product Design Guide for HIS

### 1. Multi-Tenancy Strategy
| Approach | Pros | Cons | Recommended |
|----------|------|------|-------------|
| **Shared DB, Shared Schema** | Lowest cost, easy maintenance | Data isolation risk | ✅ For MVP |
| **Shared DB, Separate Schema** | Better isolation | More complex | For growth |
| **Separate DB per Tenant** | Best isolation | Highest cost | Enterprise only |

### 2. Must-Have SaaS Features
- [ ] **Tenant Isolation** — Every query filtered by organizationId
- [ ] **Subscription Management** — Plans, billing, usage tracking
- [ ] **Role-Based Access** — Admin, Doctor, Nurse, Receptionist, etc.
- [ ] **White Labeling** — Custom logo, colors per tenant
- [ ] **Data Backup per Tenant** — Independent backup/restore
- [ ] **Usage Metering** — Track API calls, storage, users
- [ ] **Onboarding Wizard** — Self-service setup
- [ ] **Audit Logging** — Who did what, when
- [ ] **API Rate Limiting** — Prevent abuse
- [ ] **Data Export** — Tenant can export their data

### 3. SaaS Pricing Models for HIS
| Model | Example | Best For |
|-------|---------|----------|
| Per User/Month | $10/user/month | Small clinics |
| Per Bed | $50/bed/month | Hospitals |
| Per Module | $100/module/month | Modular buyers |
| Transaction Based | 1% of billing | High-volume hospitals |
| Tiered Plans | Basic/Pro/Enterprise | General market |

### 4. Technical Architecture
\`\`\`
Internet → CDN → Load Balancer
                      ↓
              API Gateway (rate limit, auth)
                      ↓
         ┌─────────────────────────┐
         │  Microservices / Modular│
         │  ┌─────┐ ┌─────┐      │
         │  │ Auth │ │ OPD │ ... │
         │  └─────┘ └─────┘      │
         └─────────────────────────┘
                      ↓
              Database (tenant-aware)
                      ↓
              Redis Cache + Queue
\`\`\`

### 5. Compliance Requirements
- **HIPAA** — For US market
- **HL7/FHIR** — Healthcare interoperability
- **GDPR** — For EU market
- **Local regulations** — Country-specific

### 6. Go-To-Market Strategy
1. **Phase 1:** Target small clinics (5-20 beds) — simpler needs
2. **Phase 2:** Medium hospitals (20-100 beds) — full HIS
3. **Phase 3:** Hospital chains — enterprise features
4. **Phase 4:** Government/large hospitals — compliance + scale`,
      suggestions: [
        'Generate multi-tenant schema',
        'Show me subscription management tables',
        'Design the onboarding wizard flow',
        'What is the MVP for first paying customer?'
      ]
    }
  }

  private securityAdvice(): AIResponse {
    return {
      message: `## 🔒 Security Architecture for Healthcare SaaS

### Authentication Flow
\`\`\`
User Login → Validate Credentials → Generate JWT + Refresh Token
    ↓
Every API Call → Verify JWT → Check Tenant → Check Role → Check Permission
    ↓
Audit Log Every Action
\`\`\`

### Required Security Tables
| Table | Purpose |
|-------|---------|
| Users | User accounts |
| Roles | Role definitions |
| UserRoles | User-role mapping |
| Permissions | Granular permissions |
| RolePermissions | Role-permission mapping |
| Sessions | Active sessions |
| AuditLogs | Every action logged |
| LoginHistory | Login attempts |
| PasswordPolicy | Password rules |
| TwoFactorAuth | 2FA settings |

### Security Checklist
- [ ] JWT with short expiry (15 min) + refresh token (7 days)
- [ ] Password hashing (bcrypt, argon2)
- [ ] Rate limiting on login (5 attempts/15 min)
- [ ] CORS configuration
- [ ] Input validation (Zod/Joi)
- [ ] SQL injection prevention (Prisma handles this)
- [ ] XSS prevention (React handles this)
- [ ] CSRF protection
- [ ] Data encryption at rest
- [ ] HTTPS everywhere
- [ ] API key for external integrations
- [ ] IP whitelisting (optional)
- [ ] Session management
- [ ] PHI (Protected Health Information) encryption
- [ ] Audit trail for all data changes`,
      suggestions: [
        'Generate auth module schema',
        'Show me the JWT flow',
        'Generate RBAC tables',
        'Show me permission structure for HIS'
      ]
    }
  }

  private apiAdvice(): AIResponse {
    const allModules = getAllModules()
    const totalAPIs = allModules.reduce((a, m) => a + m.apiEndpoints.length, 0)

    return {
      message: `## 🌐 API Design Guide

### API Statistics
- **Total Endpoints Needed:** ${totalAPIs}
- **Modules:** ${allModules.length}

### API Design Principles
1. **RESTful** with consistent naming
2. **Versioned** — \`/api/v1/...\`
3. **Paginated** — All list endpoints
4. **Filtered** — Query params for filtering
5. **Tenant-scoped** — Auto-filter by organization

### Standard API Response Format
\`\`\`json
{
  "success": true,
  "data": { ... },
  "meta": {
    "page": 1,
    "limit": 20,
    "total": 150
  },
  "errors": []
}
\`\`\`

### API Endpoints by Module
${allModules.slice(0, 5).map(m => `
**${m.name}**
${m.apiEndpoints.map(e => `- \`${e}\``).join('\n')}`).join('\n')}

... and ${allModules.length - 5} more modules

### Middleware Stack
\`\`\`
Request → CORS → Rate Limit → Auth → Tenant → Permission → Validate → Handler → Audit → Response
\`\`\``,
      suggestions: [
        'Generate API specs for billing',
        'Show me the middleware code',
        'Generate Postman collection',
        'Design the API gateway'
      ]
    }
  }

  private architectureAdvice(): AIResponse {
    return {
      message: `## 🏗️ Architecture Options

### Option 1: Modular Monolith (Recommended for Start)
\`\`\`
┌──────────────────────────────────────┐
│           Next.js Frontend           │
├──────────────────────────────────────┤
│           API Layer (Express)        │
├────────┬────────┬────────┬──────────┤
│  Auth  │  OPD   │Billing │ Pharmacy │
│ Module │ Module │ Module │  Module  │
├────────┴────────┴────────┴──────────┤
│        Prisma ORM + Database        │
└──────────────────────────────────────┘
\`\`\`
✅ Start here. Easy to develop, test, deploy.
Can be split into microservices later.

### Option 2: Microservices (Scale Phase)
\`\`\`
┌───────────┐     ┌───────────┐
│  API GW   │────▶│   Auth    │
│           │     │  Service  │
│           │     └───────────┘
│           │     ┌───────────┐
│           │────▶│   OPD     │
│           │     │  Service  │
│           │     └───────────┘
│           │     ┌───────────┐
│           │────▶│  Billing  │
│           │     │  Service  │
└───────────┘     └───────────┘
\`\`\`

### Option 3: Hybrid (Best of Both)
\`\`\`
Monolith core + Separate services for:
- Notification service
- Report generation service
- File storage service
- Analytics service
\`\`\`

### 🧠 Recommendation
Start with **Modular Monolith** → Evolve to **Hybrid** → Then **Microservices** if needed.

### Folder Structure for Modular Monolith
\`\`\`
src/
├── modules/
│   ├── auth/
│   │   ├── auth.controller.ts
│   │   ├── auth.service.ts
│   │   ├── auth.routes.ts
│   │   ├── auth.validation.ts
│   │   └── auth.types.ts
│   ├── patient/
│   ├── billing/
│   ├── pharmacy/
│   └── laboratory/
├── shared/
│   ├── middleware/
│   ├── utils/
│   └── database/
└── config/
\`\`\``,
      suggestions: [
        'Generate modular monolith structure',
        'Show me the module template code',
        'Design the database per module',
        'Generate Docker setup'
      ]
    }
  }

  private priorityAnalysis(): AIResponse {
    const allModules = getAllModules()
    const grouped = {
      critical: allModules.filter(m => m.priority === 'critical'),
      high: allModules.filter(m => m.priority === 'high'),
      medium: allModules.filter(m => m.priority === 'medium'),
      low: allModules.filter(m => m.priority === 'low')
    }

    return {
      message: `## 🎯 Priority Analysis

### 🔴 CRITICAL (Must Have for MVP)
${grouped.critical.map(m => `- **${m.name}** — ${m.estimatedDays} days ${m.revenue ? '💰' : ''}`).join('\n')}
**Subtotal:** ${grouped.critical.reduce((a, m) => a + m.estimatedDays, 0)} days

### 🟠 HIGH (Should Have)
${grouped.high.map(m => `- **${m.name}** — ${m.estimatedDays} days ${m.revenue ? '💰' : ''}`).join('\n')}
**Subtotal:** ${grouped.high.reduce((a, m) => a + m.estimatedDays, 0)} days

### 🟡 MEDIUM (Nice to Have)
${grouped.medium.map(m => `- **${m.name}** — ${m.estimatedDays} days ${m.revenue ? '💰' : ''}`).join('\n')}
**Subtotal:** ${grouped.medium.reduce((a, m) => a + m.estimatedDays, 0)} days

### 🟢 LOW (Future Scope)
${grouped.low.length > 0
  ? grouped.low.map(m => `- **${m.name}** — ${m.estimatedDays} days`).join('\n')
  : 'None defined at this priority level'}

### 🧠 MVP Scope Recommendation
Build all **CRITICAL** modules first = **${grouped.critical.reduce((a, m) => a + m.estimatedDays, 0)} dev-days**
That gives you a working system with: registration, visits, billing.`,
      suggestions: [
        'Generate MVP scope document',
        'Show me the critical path',
        'Generate schema for all critical modules',
        'What is the MLP (Minimum Lovable Product)?'
      ]
    }
  }

  private tableAnalysis(table: TableDef): AIResponse {
    const referencedBy = this.tables.filter(t =>
      t.foreignKeys.some(fk =>
        fk.referencesTable.toLowerCase() === table.tableName.toLowerCase()
      )
    )

    return {
      message: `## 📋 Table Analysis: ${table.tableName}

### Schema: ${table.schemaName}

### Columns (${table.columns.length})
| # | Name | Type | Nullable | PK | Identity |
|---|------|------|----------|----|----|
${table.columns.map((c, i) =>
  `| ${i + 1} | ${c.name} | ${c.dataType}${c.maxLength ? `(${c.maxLength})` : ''} | ${c.isNullable ? '✅' : '❌'} | ${c.isPrimaryKey ? '🔑' : ''} | ${c.isIdentity ? '⚡' : ''} |`
).join('\n')}

### Foreign Keys (${table.foreignKeys.length})
${table.foreignKeys.length > 0
  ? table.foreignKeys.map(fk => `- **${fk.columnName}** → ${fk.referencesTable}.${fk.referencesColumn}`).join('\n')
  : 'No foreign keys (this is a master table)'}

### Referenced By (${referencedBy.length} tables)
${referencedBy.length > 0
  ? referencedBy.map(t => `- ${t.tableName}`).join('\n')
  : 'Not referenced by any table'}

### 🧠 AI Observations
${table.columns.length < 3 ? '⚠️ Very few columns — might be a junction table or incomplete.' : ''}
${!table.columns.some(c => c.isPrimaryKey) ? '⚠️ No primary key detected! Every table should have a PK.' : ''}
${table.columns.some(c => c.name.toLowerCase().includes('createdon') || c.name.toLowerCase().includes('created')) ? '✅ Has audit columns (CreatedOn)' : '⚠️ Missing audit columns (CreatedOn, ModifiedOn, CreatedBy)'}
${table.foreignKeys.length === 0 && referencedBy.length === 0 ? '⚠️ Isolated table — no relationships found.' : ''}`,
      suggestions: [
        `Generate Prisma model for ${table.tableName}`,
        `Show me tables related to ${table.tableName}`,
        `Generate CRUD API for ${table.tableName}`,
        `Generate UAT test cases for ${table.tableName}`
      ]
    }
  }

  private moduleAnalysis(mod: any): AIResponse {
    const chain = getDependencyChain(mod.key)

    return {
      message: `## 📦 Module: ${mod.name}

> ${mod.description}

### Details
| Property | Value |
|----------|-------|
| Priority | **${mod.priority.toUpperCase()}** |
| Revenue | ${mod.revenue ? '💰 Yes' : 'No'} |
| Estimated Days | **${mod.estimatedDays}** |
| Tables | ${mod.tables.length} |
| API Endpoints | ${mod.apiEndpoints.length} |
| User Roles | ${mod.userRoles.join(', ')} |

### Required Tables
${mod.tables.map((t: string) => `- ${t}`).join('\n')}

### API Endpoints
${mod.apiEndpoints.map((e: string) => `- \`${e}\``).join('\n')}

### Features
${mod.features.map((f: string, i: number) => `${i + 1}. ${f}`).join('\n')}

### Dependencies (Build First)
${mod.dependsOn.length > 0
  ? mod.dependsOn.map((d: string) => `- ${getModuleByKey(d)?.name || d}`).join('\n')
  : 'None — this is a foundation module'}

### Full Dependency Chain
${chain.map((k, i) => `${i + 1}. ${getModuleByKey(k)?.name || k}`).join('\n')}`,
      suggestions: [
        `Generate schema for ${mod.name}`,
        `Generate API code for ${mod.name}`,
        `Generate UAT for ${mod.name}`,
        `What depends on ${mod.name}?`
      ]
    }
  }

  private defaultResponse(question: string): AIResponse {
    return {
      message: `## 🤖 I can help with that!

I understand you're asking about: **"${question}"**

Here are things I can analyze for your project:

### Schema Analysis
- "Analyze my schema" — Full overview
- "What tables am I missing?" — Gap analysis
- "Show me layer analysis" — Layer-by-layer coverage

### Build Planning
- "Where should I start?" — Recommended starting point
- "Show me the build order" — Full dependency chain
- "How long will this take?" — Timeline estimate
- "What is the MVP?" — Minimum viable product scope

### Technical Guidance
- "Tell me about SaaS design" — Multi-tenant architecture
- "Security advice" — Auth & compliance
- "API design" — Endpoint structure
- "Architecture options" — Monolith vs microservices

### Module Specific
- Ask about any module: "Tell me about billing"
- Ask about any table: "Analyze the Patients table"

### Generation
- "Generate schema for [module]"
- "Generate API for [module]"
- "Show me the ERD"

Try one of these or ask anything specific!`,
      suggestions: [
        'Analyze my schema',
        'What am I missing?',
        'Where should I start?',
        'Show me the build order',
        'Tell me about SaaS design',
        'How long will this take?'
      ]
    }
  }
}
```

---

## 4. SaaS Framework

```typescript
// src/lib/saas-framework.ts

export interface ChecklistItem {
  id: string
  category: string
  item: string
  description: string
  priority: 'critical' | 'high' | 'medium' | 'low'
  phase: 'design' | 'development' | 'testing' | 'deployment' | 'post-launch'
  order: number
}

export function getSaaSChecklist(): ChecklistItem[] {
  let order = 0

  return [
    // ── DESIGN PHASE ──
    { id: `chk-${++order}`, category: 'Architecture', item: 'Multi-tenancy strategy decided', description: 'Shared DB with tenant ID filtering vs separate schemas vs separate DBs', priority: 'critical', phase: 'design', order },
    { id: `chk-${++order}`, category: 'Architecture', item: 'Database schema finalized', description: 'All tables designed with proper relationships', priority: 'critical', phase: 'design', order },
    { id: `chk-${++order}`, category: 'Architecture', item: 'API design documented', description: 'All REST endpoints defined with request/response schemas', priority: 'critical', phase: 'design', order },
    { id: `chk-${++order}`, category: 'Architecture', item: 'Tech stack finalized', description: 'Frontend, backend, database, hosting decisions made', priority: 'critical', phase: 'design', order },
    { id: `chk-${++order}`, category: 'Architecture', item: 'Modular architecture planned', description: 'Modules can be enabled/disabled per tenant', priority: 'high', phase: 'design', order },
    { id: `chk-${++order}`, category: 'UX', item: 'User personas defined', description: 'Doctor, Nurse, Receptionist, Admin, Patient personas', priority: 'high', phase: 'design', order },
    { id: `chk-${++order}`, category: 'UX', item: 'User journey maps created', description: 'Key workflows mapped for each role', priority: 'high', phase: 'design', order },
    { id: `chk-${++order}`, category: 'UX', item: 'Wireframes/mockups created', description: 'Key screens designed before development', priority: 'high', phase: 'design', order },
    { id: `chk-${++order}`, category: 'Business', item: 'Pricing model defined', description: 'Per user, per bed, per module, or tiered pricing', priority: 'high', phase: 'design', order },
    { id: `chk-${++order}`, category: 'Business', item: 'Target market identified', description: 'Clinic size, geography, specializations', priority: 'high', phase: 'design', order },
    { id: `chk-${++order}`, category: 'Business', item: 'Competitor analysis done', description: 'Identified differentiators vs existing HIS products', priority: 'medium', phase: 'design', order },
    { id: `chk-${++order}`, category: 'Compliance', item: 'Regulatory requirements listed', description: 'HIPAA, local health authority requirements', priority: 'critical', phase: 'design', order },
    { id: `chk-${++order}`, category: 'Compliance', item: 'Data retention policy defined', description: 'How long to keep patient data, deletion policy', priority: 'high', phase: 'design', order },

    // ── DEVELOPMENT PHASE ──
    { id: `chk-${++order}`, category: 'Auth', item: 'JWT authentication implemented', description: 'Login, register, refresh token, logout', priority: 'critical', phase: 'development', order },
    { id: `chk-${++order}`, category: 'Auth', item: 'RBAC (Role-Based Access Control)', description: 'Roles and permissions system working', priority: 'critical', phase: 'development', order },
    { id: `chk-${++order}`, category: 'Auth', item: 'Tenant isolation middleware', description: 'Every query auto-filtered by organizationId', priority: 'critical', phase: 'development', order },
    { id: `chk-${++order}`, category: 'Auth', item: 'Password hashing (bcrypt/argon2)', description: 'Secure password storage', priority: 'critical', phase: 'development', order },
    { id: `chk-${++order}`, category: 'Database', item: 'Prisma schema complete', description: 'All models defined with relationships', priority: 'critical', phase: 'development', order },
    { id: `chk-${++order}`, category: 'Database', item: 'Migration strategy established', description: 'Schema changes managed via migrations', priority: 'critical', phase: 'development', order },
    { id: `chk-${++order}`, category: 'Database', item: 'Seed data scripts ready', description: 'Lookup data, test data scripts', priority: 'high', phase: 'development', order },
    { id: `chk-${++order}`, category: 'Database', item: 'Audit logging implemented', description: 'Every create/update/delete logged', priority: 'high', phase: 'development', order },
    { id: `chk-${++order}`, category: 'API', item: 'API versioning implemented', description: '/api/v1/ prefix on all routes', priority: 'high', phase: 'development', order },
    { id: `chk-${++order}`, category: 'API', item: 'Input validation on all endpoints', description: 'Zod/Joi validation schemas', priority: 'critical', phase: 'development', order },
    { id: `chk-${++order}`, category: 'API', item: 'Error handling standardized', description: 'Consistent error response format', priority: 'high', phase: 'development', order },
    { id: `chk-${++order}`, category: 'API', item: 'Pagination on list endpoints', description: 'page, limit, total in all list responses', priority: 'high', phase: 'development', order },
    { id: `chk-${++order}`, category: 'API', item: 'Rate limiting configured', description: 'Prevent API abuse', priority: 'high', phase: 'development', order },
    { id: `chk-${++order}`, category: 'Frontend', item: 'Responsive design', description: 'Works on desktop, tablet, and mobile', priority: 'high', phase: 'development', order },
    { id: `chk-${++order}`, category: 'Frontend', item: 'Form validation (client-side)', description: 'Real-time validation before submission', priority: 'high', phase: 'development', order },
    { id: `chk-${++order}`, category: 'Frontend', item: 'Loading states and error handling', description: 'Skeleton loaders, error boundaries', priority: 'medium', phase: 'development', order },
    { id: `chk-${++order}`, category: 'Frontend', item: 'Dark mode support', description: 'Theme switching capability', priority: 'low', phase: 'development', order },
    { id: `chk-${++order}`, category: 'DevOps', item: 'Environment configuration', description: 'dev, uat, prod configs separated', priority: 'critical', phase: 'development', order },
    { id: `chk-${++order}`, category: 'DevOps', item: 'Git workflow established', description: 'Branching strategy (GitFlow or trunk-based)', priority: 'high', phase: 'development', order },
    { id: `chk-${++order}`, category: 'DevOps', item: 'CI/CD pipeline setup', description: 'Auto build, test, deploy on push', priority: 'high', phase: 'development', order },

    // ── TESTING PHASE ──
    { id: `chk-${++order}`, category: 'Testing', item: 'Unit tests for business logic', description: 'Service layer unit tests', priority: 'high', phase: 'testing', order },
    { id: `chk-${++order}`, category: 'Testing', item: 'API integration tests', description: 'Test all endpoints with real DB', priority: 'high', phase: 'testing', order },
    { id: `chk-${++order}`, category: 'Testing', item: 'UAT test cases executed', description: 'User acceptance testing completed', priority: 'critical', phase: 'testing', order },
    { id: `chk-${++order}`, category: 'Testing', item: 'Performance testing done', description: 'Load test with expected concurrent users', priority: 'medium', phase: 'testing', order },
    { id: `chk-${++order}`, category: 'Testing', item: 'Security testing done', description: 'OWASP top 10 vulnerabilities checked', priority: 'high', phase: 'testing', order },
    { id: `chk-${++order}`, category: 'Testing', item: 'Cross-browser testing', description: 'Chrome, Firefox, Safari, Edge', priority: 'medium', phase: 'testing', order },

    // ── DEPLOYMENT PHASE ──
    { id: `chk-${++order}`, category: 'Infrastructure', item: 'Production server provisioned', description: 'Cloud server with proper specs', priority: 'critical', phase: 'deployment', order },
    { id: `chk-${++order}`, category: 'Infrastructure', item: 'SSL certificate configured', description: 'HTTPS on all domains', priority: 'critical', phase: 'deployment', order },
    { id: `chk-${++order}`, category: 'Infrastructure', item: 'Database backup automated', description: 'Daily automated backups with retention', priority: 'critical', phase: 'deployment', order },
    { id: `chk-${++order}`, category: 'Infrastructure', item: 'Monitoring setup', description: 'Uptime monitoring, error tracking (Sentry)', priority: 'high', phase: 'deployment', order },
    { id: `chk-${++order}`, category: 'Infrastructure', item: 'Domain and DNS configured', description: 'Production domain pointed correctly', priority: 'critical', phase: 'deployment', order },
    { id: `chk-${++order}`, category: 'Infrastructure', item: 'Docker containerized', description: 'Application containerized for consistent deployment', priority: 'high', phase: 'deployment', order },

    // ── POST-LAUNCH ──
    { id: `chk-${++order}`, category: 'Operations', item: 'User documentation created', description: 'Help docs for each module', priority: 'high', phase: 'post-launch', order },
    { id: `chk-${++order}`, category: 'Operations', item: 'Admin documentation created', description: 'Setup and configuration guide', priority: 'high', phase: 'post-launch', order },
    { id: `chk-${++order}`, category: 'Operations', item: 'Support ticket system setup', description: 'Channel for users to report issues', priority: 'high', phase: 'post-launch', order },
    { id: `chk-${++order}`, category: 'Operations', item: 'Analytics tracking', description: 'Track feature usage, user engagement', priority: 'medium', phase: 'post-launch', order },
    { id: `chk-${++order}`, category: 'Operations', item: 'Feedback collection mechanism', description: 'In-app feedback, NPS surveys', priority: 'medium', phase: 'post-launch', order },
    { id: `chk-${++order}`, category: 'Growth', item: 'Onboarding flow optimized', description: 'Self-service signup and setup wizard', priority: 'high', phase: 'post-launch', order },
    { id: `chk-${++order}`, category: 'Growth', item: 'Demo/trial environment', description: 'Free trial with sample data', priority: 'high', phase: 'post-launch', order },
    { id: `chk-${++order}`, category: 'Growth', item: 'Marketing website', description: 'Landing page with features, pricing, signup', priority: 'high', phase: 'post-launch', order },
  ]
}
```

---

## 5. Code Generator (Generates Full Module Code)

```typescript
// src/lib/code-generator.ts

import { LayerModule } from './layer-definitions'

export function generateModuleCode(mod: LayerModule): {
  prismaSchema: string
  apiRoutes: string
  controller: string
  service: string
  validation: string
  types: string
  frontendPage: string
  frontendForm: string
} {
  const modelName = toPascal(mod.key)
  const varName = toCamel(mod.key)
  const mainTable = mod.tables[0]

  // ─── PRISMA SCHEMA ───
  const prismaSchema = `// ─── ${mod.name} Models ───

model ${toPascal(mainTable)} {
  id              String    @id @default(uuid())
  organizationId  String
${mod.tables[0] === 'Patients' ? `  firstName       String
  lastName        String
  mrn             String    @unique
  dateOfBirth     DateTime?
  gender          String?
  email           String?
  phone           String?` : `  name            String
  code            String?
  description     String?`}
  isActive        Boolean   @default(true)
  createdBy       String?
  modifiedBy      String?
  createdOn       DateTime  @default(now())
  modifiedOn      DateTime  @updatedAt

  organization    Organization @relation(fields: [organizationId], references: [id])
  
  @@map("${mainTable}")
}
${mod.tables.slice(1).map(t => `
model ${toPascal(t)} {
  id              String    @id @default(uuid())
  ${toCamel(mainTable)}Id  String
  organizationId  String
  isActive        Boolean   @default(true)
  createdOn       DateTime  @default(now())
  modifiedOn      DateTime  @updatedAt

  ${toCamel(mainTable)}  ${toPascal(mainTable)} @relation(fields: [${toCamel(mainTable)}Id], references: [id])
  organization     Organization @relation(fields: [organizationId], references: [id])
  
  @@map("${t}")
}`).join('\n')}`

  // ─── API ROUTES ───
  const apiRoutes = `// src/modules/${mod.key}/routes.ts

import { Router } from 'express'
import { ${modelName}Controller } from './${mod.key}.controller'
import { authenticate, authorize } from '../../shared/middleware/auth'
import { validate } from '../../shared/middleware/validate'
import { create${modelName}Schema, update${modelName}Schema } from './${mod.key}.validation'

const router = Router()
const controller = new ${modelName}Controller()

// All routes require authentication
router.use(authenticate)

// List all
router.get('/',
  authorize([${mod.userRoles.map(r => `'${r}'`).join(', ')}]),
  controller.getAll
)

// Get by ID
router.get('/:id',
  authorize([${mod.userRoles.map(r => `'${r}'`).join(', ')}]),
  controller.getById
)

// Create
router.post('/',
  authorize([${mod.userRoles.slice(0, 2).map(r => `'${r}'`).join(', ')}]),
  validate(create${modelName}Schema),
  controller.create
)

// Update
router.put('/:id',
  authorize([${mod.userRoles.slice(0, 2).map(r => `'${r}'`).join(', ')}]),
  validate(update${modelName}Schema),
  controller.update
)

// Delete (soft)
router.delete('/:id',
  authorize([${mod.userRoles[0] ? `'${mod.userRoles[0]}'` : "'Admin'"}]),
  controller.delete
)

export default router`

  // ─── CONTROLLER ───
  const controller = `// src/modules/${mod.key}/${mod.key}.controller.ts

import { Request, Response, NextFunction } from 'express'
import { ${modelName}Service } from './${mod.key}.service'

const service = new ${modelName}Service()

export class ${modelName}Controller {
  
  async getAll(req: Request, res: Response, next: NextFunction) {
    try {
      const { page = 1, limit = 20, search, status } = req.query
      const orgId = req.user!.organizationId

      const result = await service.findAll({
        organizationId: orgId,
        page: Number(page),
        limit: Number(limit),
        search: search as string,
        status: status as string,
      })

      res.json({
        success: true,
        data: result.data,
        meta: {
          page: Number(page),
          limit: Number(limit),
          total: result.total,
          totalPages: Math.ceil(result.total / Number(limit)),
        }
      })
    } catch (error) {
      next(error)
    }
  }

  async getById(req: Request, res: Response, next: NextFunction) {
    try {
      const orgId = req.user!.organizationId
      const data = await service.findById(req.params.id, orgId)
      
      if (!data) {
        return res.status(404).json({
          success: false,
          error: '${mod.name} not found'
        })
      }

      res.json({ success: true, data })
    } catch (error) {
      next(error)
    }
  }

  async create(req: Request, res: Response, next: NextFunction) {
    try {
      const orgId = req.user!.organizationId
      const userId = req.user!.id

      const data = await service.create({
        ...req.body,
        organizationId: orgId,
        createdBy: userId,
      })

      res.status(201).json({ success: true, data })
    } catch (error) {
      next(error)
    }
  }

  async update(req: Request, res: Response, next: NextFunction) {
    try {
      const orgId = req.user!.organizationId
      const userId = req.user!.id

      const data = await service.update(req.params.id, {
        ...req.body,
        organizationId: orgId,
        modifiedBy: userId,
      })

      res.json({ success: true, data })
    } catch (error) {
      next(error)
    }
  }

  async delete(req: Request, res: Response, next: NextFunction) {
    try {
      const orgId = req.user!.organizationId
      await service.softDelete(req.params.id, orgId)
      res.json({ success: true, message: '${mod.name} deleted successfully' })
    } catch (error) {
      next(error)
    }
  }
}`

  // ─── SERVICE ───
  const service = `// src/modules/${mod.key}/${mod.key}.service.ts

import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

interface FindAllParams {
  organizationId: string
  page: number
  limit: number
  search?: string
  status?: string
}

export class ${modelName}Service {

  async findAll(params: FindAllParams) {
    const { organizationId, page, limit, search, status } = params
    const skip = (page - 1) * limit

    const where: any = {
      organizationId,
      isActive: status === 'inactive' ? false : true,
    }

    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { code: { contains: search, mode: 'insensitive' } },
      ]
    }

    const [data, total] = await Promise.all([
      prisma.${toCamel(mainTable)}.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdOn: 'desc' },
      }),
      prisma.${toCamel(mainTable)}.count({ where }),
    ])

    return { data, total }
  }

  async findById(id: string, organizationId: string) {
    return prisma.${toCamel(mainTable)}.findFirst({
      where: { id, organizationId },
    })
  }

  async create(data: any) {
    return prisma.${toCamel(mainTable)}.create({ data })
  }

  async update(id: string, data: any) {
    const { organizationId, ...updateData } = data
    return prisma.${toCamel(mainTable)}.update({
      where: { id },
      data: updateData,
    })
  }

  async softDelete(id: string, organizationId: string) {
    return prisma.${toCamel(mainTable)}.update({
      where: { id },
      data: { isActive: false },
    })
  }
}`

  // ─── VALIDATION ───
  const validation = `// src/modules/${mod.key}/${mod.key}.validation.ts

import { z } from 'zod'

export const create${modelName}Schema = z.object({
  body: z.object({
    name: z.string().min(1, 'Name is required').max(200),
    code: z.string().optional(),
    description: z.string().optional(),
  })
})

export const update${modelName}Schema = z.object({
  body: z.object({
    name: z.string().min(1).max(200).optional(),
    code: z.string().optional(),
    description: z.string().optional(),
    isActive: z.boolean().optional(),
  })
})

export type Create${modelName}Input = z.infer<typeof create${modelName}Schema>['body']
export type Update${modelName}Input = z.infer<typeof update${modelName}Schema>['body']`

  // ─── TYPES ───
  const types = `// src/modules/${mod.key}/${mod.key}.types.ts

export interface ${modelName} {
  id: string
  organizationId: string
  name: string
  code?: string
  description?: string
  isActive: boolean
  createdBy?: string
  modifiedBy?: string
  createdOn: Date
  modifiedOn: Date
}

export interface Create${modelName}DTO {
  name: string
  code?: string
  description?: string
}

export interface Update${modelName}DTO {
  name?: string
  code?: string
  description?: string
  isActive?: boolean
}`

  // ─── FRONTEND PAGE ───
  const frontendPage = `// src/app/${mod.key}/page.tsx
'use client'

import { useState, useEffect } from 'react'

interface ${modelName}Record {
  id: string
  name: string
  code?: string
  isActive: boolean
  createdOn: string
}

export default function ${modelName}Page() {
  const [data, setData] = useState<${modelName}Record[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [showForm, setShowForm] = useState(false)
  const [editId, setEditId] = useState<string | null>(null)

  useEffect(() => {
    fetchData()
  }, [search])

  const fetchData = async () => {
    setLoading(true)
    const res = await fetch(\`/api/${mod.key}?search=\${search}\`)
    const json = await res.json()
    setData(json.data || [])
    setLoading(false)
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure?')) return
    await fetch(\`/api/${mod.key}/\${id}\`, { method: 'DELETE' })
    fetchData()
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold">${mod.name}</h1>
          <p className="text-gray-500">${mod.description}</p>
        </div>
        <button
          onClick={() => { setEditId(null); setShowForm(true) }}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
        >
          + Add New
        </button>
      </div>

      {/* Search */}
      <div className="mb-4">
        <input
          type="text"
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search..."
          className="w-full max-w-md border rounded-lg px-4 py-2"
        />
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left text-sm font-medium">Name</th>
              <th className="px-4 py-3 text-left text-sm font-medium">Code</th>
              <th className="px-4 py-3 text-left text-sm font-medium">Status</th>
              <th className="px-4 py-3 text-left text-sm font-medium">Created</th>
              <th className="px-4 py-3 text-left text-sm font-medium">Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={5} className="text-center py-8 text-gray-400">Loading...</td></tr>
            ) : data.length === 0 ? (
              <tr><td colSpan={5} className="text-center py-8 text-gray-400">No records found</td></tr>
            ) : data.map(item => (
              <tr key={item.id} className="border-t hover:bg-gray-50">
                <td className="px-4 py-3 font-medium">{item.name}</td>
                <td className="px-4 py-3 text-gray-500">{item.code || '-'}</td>
                <td className="px-4 py-3">
                  <span className={\`px-2 py-1 rounded text-xs \${
                    item.isActive ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                  }\`}>
                    {item.isActive ? 'Active' : 'Inactive'}
                  </span>
                </td>
                <td className="px-4 py-3 text-gray-500 text-sm">
                  {new Date(item.createdOn).toLocaleDateString()}
                </td>
                <td className="px-4 py-3">
                  <button
                    onClick={() => { setEditId(item.id); setShowForm(true) }}
                    className="text-blue-600 hover:underline text-sm mr-3"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDelete(item.id)}
                    className="text-red-600 hover:underline text-sm"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}`

  // ─── FRONTEND FORM ───
  const frontendForm = `// src/components/${modelName}Form.tsx
'use client'

import { useState, useEffect } from 'react'

interface Props {
  editId?: string | null
  onClose: () => void
  onSaved: () => void
}

export default function ${modelName}Form({ editId, onClose, onSaved }: Props) {
  const [form, setForm] = useState({ name: '', code: '', description: '' })
  const [saving, setSaving] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})

  useEffect(() => {
    if (editId) {
      fetch(\`/api/${mod.key}/\${editId}\`)
        .then(r => r.json())
        .then(d => setForm({ name: d.data.name, code: d.data.code || '', description: d.data.description || '' }))
    }
  }, [editId])

  const validate = () => {
    const errs: Record<string, string> = {}
    if (!form.name.trim()) errs.name = 'Name is required'
    setErrors(errs)
    return Object.keys(errs).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!validate()) return

    setSaving(true)
    const url = editId ? \`/api/${mod.key}/\${editId}\` : '/api/${mod.key}'
    const method = editId ? 'PUT' : 'POST'

    await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    })

    setSaving(false)
    onSaved()
    onClose()
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-2xl p-6 w-full max-w-md">
        <h2 className="text-xl font-bold mb-4">
          {editId ? 'Edit' : 'Create'} ${mod.name}
        </h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">Name *</label>
            <input
              value={form.name}
              onChange={e => setForm({...form, name: e.target.value})}
              className={\`w-full border rounded-lg px-3 py-2 \${errors.name ? 'border-red-500' : ''}\`}
            />
            {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Code</label>
            <input
              value={form.code}
              onChange={e => setForm({...form, code: e.target.value})}
              className="w-full border rounded-lg px-3 py-2"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Description</label>
            <textarea
              value={form.description}
              onChange={e => setForm({...form, description: e.target.value})}
              className="w-full border rounded-lg px-3 py-2"
              rows={3}
            />
          </div>
          <div className="flex gap-2 pt-2">
            <button
              type="submit"
              disabled={saving}
              className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700
                         disabled:opacity-50"
            >
              {saving ? 'Saving...' : editId ? 'Update' : 'Create'}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="flex-1 bg-gray-200 py-2 rounded-lg hover:bg-gray-300"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}`

  return { prismaSchema, apiRoutes, controller, service, validation, types, frontendPage, frontendForm }
}

function toPascal(str: string): string {
  return str.split('-').map(s => s.charAt(0).toUpperCase() + s.slice(1)).join('')
}

function toCamel(str: string): string {
  const pascal = toPascal(str)
  return pascal.charAt(0).toLowerCase() + pascal.slice(1)
}
```

---

## 6. AI Chat API Route

```typescript
// src/app/api/ai-chat/route.ts

import { NextRequest, NextResponse } from 'next/server'
import { parseSqlServer } from '@/lib/sql-parser'
import { SchemaAI } from '@/lib/ai-engine'
import { prisma } from '@/lib/db'

export async function POST(req: NextRequest) {
  try {
    const { message, conversationId, sql } = await req.json()

    // Parse tables from SQL (if provided)
    let tables = []
    if (sql) {
      const result = parseSqlServer(sql)
      tables = result.tables
    }

    // Create AI engine with schema context
    const ai = new SchemaAI(tables, 'HIS Project')
    const response = ai.analyze(message)

    // Save conversation
    let convId = conversationId
    if (!convId) {
      const conv = await prisma.aIConversation.create({
        data: {
          title: message.substring(0, 50),
          context: 'schema-analysis',
        },
      })
      convId = conv.id
    }

    // Save messages
    await prisma.aIMessage.createMany({
      data: [
        { conversationId: convId, role: 'user', content: message },
        {
          conversationId: convId,
          role: 'ai',
          content: response.message,
          metadata: JSON.stringify({
            suggestions: response.suggestions,
            actions: response.actions,
          }),
        },
      ],
    })

    return NextResponse.json({
      conversationId: convId,
      response,
    })
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
```

---

## 7. Module Generator API

```typescript
// src/app/api/generate-module/route.ts

import { NextRequest, NextResponse } from 'next/server'
import { getModuleByKey } from '@/lib/layer-definitions'
import { generateModuleCode } from '@/lib/code-generator'

export async function POST(req: NextRequest) {
  const { moduleKey } = await req.json()

  const mod = getModuleByKey(moduleKey)
  if (!mod) {
    return NextResponse.json({ error: 'Module not found' }, { status: 404 })
  }

  const code = generateModuleCode(mod)

  return NextResponse.json({
    module: mod,
    code,
  })
}
```

---

## 8. Layer Analysis API

```typescript
// src/app/api/layer-analysis/route.ts

import { NextRequest, NextResponse } from 'next/server'
import { parseSqlServer } from '@/lib/sql-parser'
import { HIS_LAYERS, getModuleStats } from '@/lib/layer-definitions'

export async function POST(req: NextRequest) {
  const { sql } = await req.json()
  const result = parseSqlServer(sql || '')
  const existingNames = new Set(result.tables.map(t => t.tableName.toLowerCase()))

  const layers = HIS_LAYERS.map(layer => {
    const modules = layer.modules.map(mod => {
      const found = mod.tables.filter(t => existingNames.has(t.toLowerCase()))
      const missing = mod.tables.filter(t => !existingNames.has(t.toLowerCase()))
      return {
        ...mod,
        found,
        missing,
        coverage: mod.tables.length > 0
          ? Math.round((found.length / mod.tables.length) * 100)
          : 0,
      }
    })

    const totalFound = modules.reduce((a, m) => a + m.found.length, 0)
    const totalTables = modules.reduce((a, m) => a + m.tables.length, 0)

    return {
      ...layer,
      modules,
      totalFound,
      totalTables,
      coverage: totalTables > 0 ? Math.round((totalFound / totalTables) * 100) : 0,
    }
  })

  return NextResponse.json({
    layers,
    stats: getModuleStats(),
    existingTables: result.tables.length,
  })
}
```

---

## 9. AI Chat Page

```tsx
// src/app/ai-chat/page.tsx
'use client'

import { useState, useRef, useEffect } from 'react'

interface Message {
  role: 'user' | 'ai'
  content: string
  suggestions?: string[]
  timestamp: Date
}

const QUICK_ACTIONS = [
  { icon: '📊', label: 'Analyze Schema', prompt: 'Analyze my schema and give me an overview' },
  { icon: '🔍', label: 'Find Missing', prompt: 'What tables am I missing for a complete HIS?' },
  { icon: '🏗️', label: 'Layer Analysis', prompt: 'Show me the layer-by-layer analysis' },
  { icon: '🚀', label: 'Where to Start', prompt: 'Where should I start building?' },
  { icon: '📋', label: 'Build Order', prompt: 'Show me the recommended build order' },
  { icon: '💰', label: 'Revenue Modules', prompt: 'Which modules generate revenue?' },
  { icon: '⏱️', label: 'Timeline', prompt: 'How long will this take to build?' },
  { icon: '🔗', label: 'Relationships', prompt: 'Analyze my table relationships' },
  { icon: '🔒', label: 'Security', prompt: 'Give me security architecture advice' },
  { icon: '🚀', label: 'SaaS Design', prompt: 'Tell me about SaaS product design for HIS' },
  { icon: '🏢', label: 'Architecture', prompt: 'What architecture should I use?' },
  { icon: '🎯', label: 'Priority', prompt: 'What are the critical modules I need?' },
]

export default function AIChatPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'ai',
      content: `## 🤖 Welcome to Schema AI Assistant!

I can analyze your SQL schema and help you build a complete Hospital Information System.

### What I can do:
- **Analyze** your uploaded SQL schema
- **Identify** missing tables and modules
- **Plan** the build order with dependencies
- **Generate** code for any module
- **Advise** on SaaS architecture, security, and design

### Getting Started
Upload your SQL files on the **Upload page** first, then ask me anything!

Or click any quick action below to get started.`,
      suggestions: [
        'Analyze my schema',
        'What am I missing?',
        'Where should I start?',
      ],
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [convId, setConvId] = useState<string | null>(null)
  const messagesEnd = useRef<HTMLDivElement>(null)

  useEffect(() => {
    messagesEnd.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const sendMessage = async (text?: string) => {
    const msg = text || input
    if (!msg.trim()) return

    const sql = localStorage.getItem('toolkit_sql') || ''

    setMessages(prev => [...prev, { role: 'user', content: msg, timestamp: new Date() }])
    setInput('')
    setLoading(true)

    try {
      const res = await fetch('/api/ai-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: msg,
          conversationId: convId,
          sql,
        }),
      })

      const data = await res.json()

      if (data.conversationId) setConvId(data.conversationId)

      setMessages(prev => [
        ...prev,
        {
          role: 'ai',
          content: data.response.message,
          suggestions: data.response.suggestions,
          timestamp: new Date(),
        },
      ])
    } catch {
      setMessages(prev => [
        ...prev,
        { role: 'ai', content: '❌ Error processing your request. Please try again.', timestamp: new Date() },
      ])
    }

    setLoading(false)
  }

  return (
    <div className="flex flex-col h-[calc(100vh-4rem)]">
      {/* Header */}
      <div className="border-b px-6 py-4 bg-white">
        <h1 className="text-2xl font-bold">🤖 AI Schema Assistant</h1>
        <p className="text-gray-500 text-sm">
          Ask me anything about your database, HIS modules, or SaaS architecture
        </p>
      </div>

      {/* Quick Actions */}
      <div className="px-6 py-3 bg-gray-50 border-b overflow-x-auto">
        <div className="flex gap-2 min-w-max">
          {QUICK_ACTIONS.map(a => (
            <button
              key={a.label}
              onClick={() => sendMessage(a.prompt)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-white border rounded-full
                         text-sm hover:bg-blue-50 hover:border-blue-300 transition-colors
                         whitespace-nowrap"
            >
              <span>{a.icon}</span>
              <span>{a.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-auto px-6 py-4 space-y-6">
        {messages.map((msg, i) => (
          <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] rounded-2xl px-5 py-4 ${
              msg.role === 'user'
                ? 'bg-blue-600 text-white'
                : 'bg-white border border-gray-200 shadow-sm'
            }`}>
              {/* Render markdown-like content */}
              <div className={`prose prose-sm max-w-none ${msg.role === 'user' ? 'text-white' : ''}`}>
                {msg.content.split('\n').map((line, j) => {
                  if (line.startsWith('## '))
                    return <h2 key={j} className={`text-lg font-bold mt-3 mb-1 ${msg.role === 'user' ? 'text-white' : 'text-gray-800'}`}>{line.slice(3)}</h2>
                  if (line.startsWith('### '))
                    return <h3 key={j} className={`text-md font-semibold mt-2 ${msg.role === 'user' ? 'text-white' : 'text-gray-700'}`}>{line.slice(4)}</h3>
                  if (line.startsWith('- '))
                    return <li key={j} className="ml-4 text-sm">{line.slice(2)}</li>
                  if (line.startsWith('|'))
                    return <pre key={j} className="text-xs font-mono bg-gray-50 px-2 py-0.5 rounded overflow-auto">{line}</pre>
                  if (line.startsWith('> '))
                    return <blockquote key={j} className="border-l-3 border-blue-300 pl-3 italic text-sm text-gray-600">{line.slice(2)}</blockquote>
                  if (line.startsWith('---'))
                    return <hr key={j} className="my-2 border-gray-200" />
                  if (line.startsWith('```'))
                    return null
                  if (line.trim() === '')
                    return <br key={j} />
                  return <p key={j} className="text-sm my-0.5">{line}</p>
                })}
              </div>

              {/* Suggestion buttons */}
              {msg.suggestions && msg.suggestions.length > 0 && (
                <div className="mt-4 flex flex-wrap gap-2">
                  {msg.suggestions.map((s, k) => (
                    <button
                      key={k}
                      onClick={() => sendMessage(s)}
                      className="text-xs bg-blue-50 text-blue-700 px-3 py-1.5 rounded-full
                                 border border-blue-200 hover:bg-blue-100 transition-colors"
                    >
                      {s}
                    </button>
                  ))}
                </div>
              )}

              <div className={`text-xs mt-2 ${msg.role === 'user' ? 'text-blue-200' : 'text-gray-400'}`}>
                {msg.timestamp.toLocaleTimeString()}
              </div>
            </div>
          </div>
        ))}

        {loading && (
          <div className="flex justify-start">
            <div className="bg-white border rounded-2xl px-5 py-4 shadow-sm">
              <div className="flex gap-1.5">
                <div className="w-2.5 h-2.5 bg-blue-400 rounded-full animate-bounce" />
                <div className="w-2.5 h-2.5 bg-blue-400 rounded-full animate-bounce [animation-delay:0.1s]" />
                <div className="w-2.5 h-2.5 bg-blue-400 rounded-full animate-bounce [animation-delay:0.2s]" />
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEnd} />
      </div>

      {/* Input */}
      <div className="border-t bg-white px-6 py-4">
        <div className="flex gap-3 max-w-4xl mx-auto">
          <input
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && !e.shiftKey && sendMessage()}
            placeholder="Ask about your schema, modules, architecture..."
            className="flex-1 border rounded-xl px-4 py-3 focus:ring-2 focus:ring-blue-500
                       focus:border-transparent"
            disabled={loading}
          />
          <button
            onClick={() => sendMessage()}
            disabled={loading || !input.trim()}
            className="bg-blue-600 text-white px-6 py-3 rounded-xl hover:bg-blue-700
                       disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            Send
          </button>
        </div>
      </div>
    </div>
  )
}
```

---

## 10. Layers Page

```tsx
// src/app/layers/page.tsx
'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import StatsCard from '@/components/StatsCard'

export default function LayersPage() {
  const [data, setData] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const sql = localStorage.getItem('toolkit_sql') || ''
    fetch('/api/layer-analysis', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sql }),
    })
      .then(r => r.json())
      .then(d => { setData(d); setLoading(false) })
  }, [])

  if (loading) return <div className="p-8">⏳ Analyzing layers...</div>

  const colors: Record<string, string> = {
    blue: 'border-blue-500 bg-blue-50',
    green: 'border-green-500 bg-green-50',
    yellow: 'border-yellow-500 bg-yellow-50',
    red: 'border-red-500 bg-red-50',
    purple: 'border-purple-500 bg-purple-50',
    indigo: 'border-indigo-500 bg-indigo-50',
  }

  return (
    <div className="max-w-6xl mx-auto">
      <h1 className="text-3xl font-bold mb-2">🏗️ HIS Layers & Modules</h1>
      <p className="text-gray-500 mb-8">
        Your system architecture broken into buildable layers
      </p>

      {/* Global Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <StatsCard icon="📦" label="Total Modules" value={data.stats.totalModules} color="blue" />
        <StatsCard icon="📋" label="Total Tables" value={data.stats.totalTables} color="green" />
        <StatsCard icon="🌐" label="Total APIs" value={data.stats.totalAPIs} color="purple" />
        <StatsCard icon="📅" label="Estimated Days" value={data.stats.totalDays} color="orange" />
      </div>

      {/* Layers */}
      <div className="space-y-8">
        {data.layers.map((layer: any) => (
          <div
            key={layer.number}
            className={`border-l-4 rounded-xl p-6 ${colors[layer.color] || 'border-gray-500 bg-gray-50'}`}
          >
            <div className="flex justify-between items-start mb-4">
              <div>
                <h2 className="text-xl font-bold">{layer.title}</h2>
                <p className="text-gray-600 text-sm">{layer.description}</p>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold">{layer.coverage}%</div>
                <div className="text-xs text-gray-500">
                  {layer.totalFound}/{layer.totalTables} tables
                </div>
              </div>
            </div>

            {/* Progress bar */}
            <div className="w-full bg-gray-200 rounded-full h-3 mb-4">
              <div
                className={`h-3 rounded-full transition-all ${
                  layer.coverage >= 80 ? 'bg-green-500' :
                  layer.coverage >= 50 ? 'bg-yellow-500' :
                  layer.coverage > 0 ? 'bg-orange-500' : 'bg-red-500'
                }`}
                style={{ width: `${layer.coverage}%` }}
              />
            </div>

            {/* Modules Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {layer.modules.map((mod: any) => (
                <Link
                  key={mod.key}
                  href={`/modules/${mod.key}`}
                  className="bg-white rounded-lg border p-4 hover:shadow-md transition-shadow"
                >
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-semibold text-sm">{mod.name}</h3>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${
                      mod.priority === 'critical' ? 'bg-red-100 text-red-700' :
                      mod.priority === 'high' ? 'bg-orange-100 text-orange-700' :
                      'bg-blue-100 text-blue-700'
                    }`}>
                      {mod.priority}
                    </span>
                  </div>
                  <div className="flex items-center gap-4 text-xs text-gray-500 mb-2">
                    <span>📋 {mod.tables.length} tables</span>
                    <span>🌐 {mod.apiEndpoints.length} APIs</span>
                    <span>📅 {mod.estimatedDays}d</span>
                    {mod.revenue && <span>💰</span>}
                  </div>
                  <div className="w-full bg-gray-100 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full ${
                        mod.coverage >= 80 ? 'bg-green-500' :
                        mod.coverage > 0 ? 'bg-yellow-500' : 'bg-gray-300'
                      }`}
                      style={{ width: `${mod.coverage}%` }}
                    />
                  </div>
                  <div className="text-xs text-gray-400 mt-1">
                    {mod.coverage}% — {mod.found.length} found, {mod.missing.length} missing
                  </div>
                </Link>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
```

---

## 11. Module Detail Page (with Code Generation)

```tsx
// src/app/modules/[id]/page.tsx
'use client'

import { useState, useEffect } from 'react'
import { useParams } from 'next/navigation'
import CodeBlock from '@/components/CodeBlock'
import ExportButton from '@/components/ExportButton'

export default function ModuleDetailPage() {
  const { id } = useParams()
  const [mod, setMod] = useState<any>(null)
  const [code, setCode] = useState<any>(null)
  const [activeTab, setActiveTab] = useState('overview')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/generate-module', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ moduleKey: id }),
    })
      .then(r => r.json())
      .then(d => { setMod(d.module); setCode(d.code); setLoading(false) })
  }, [id])

  if (loading) return <div className="p-8">⏳ Loading module...</div>
  if (!mod) return <div className="p-8">Module not found</div>

  const tabs = [
    { key: 'overview', label: '📋 Overview', icon: '📋' },
    { key: 'prisma', label: '⚙️ Prisma Schema', icon: '⚙️' },
    { key: 'routes', label: '🛣️ API Routes', icon: '🛣️' },
    { key: 'controller', label: '🎮 Controller', icon: '🎮' },
    { key: 'service', label: '⚡ Service', icon: '⚡' },
    { key: 'validation', label: '✅ Validation', icon: '✅' },
    { key: 'types', label: '📝 Types', icon: '📝' },
    { key: 'frontend', label: '🖥️ Frontend Page', icon: '🖥️' },
    { key: 'form', label: '📄 Frontend Form', icon: '📄' },
  ]

  return (
    <div>
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center gap-3 mb-2">
          <span className={`px-3 py-1 rounded-full text-sm font-medium ${
            mod.priority === 'critical' ? 'bg-red-100 text-red-700' :
            mod.priority === 'high' ? 'bg-orange-100 text-orange-700' :
            'bg-blue-100 text-blue-700'
          }`}>
            {mod.priority.toUpperCase()}
          </span>
          {mod.revenue && <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm">💰 Revenue</span>}
        </div>
        <h1 className="text-3xl font-bold">{mod.name}</h1>
        <p className="text-gray-500">{mod.description}</p>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 text-center">
          <div className="text-xl font-bold text-blue-700">{mod.tables.length}</div>
          <div className="text-xs text-blue-500">Tables</div>
        </div>
        <div className="bg-green-50 border border-green-200 rounded-xl p-3 text-center">
          <div className="text-xl font-bold text-green-700">{mod.apiEndpoints.length}</div>
          <div className="text-xs text-green-500">API Endpoints</div>
        </div>
        <div className="bg-purple-50 border border-purple-200 rounded-xl p-3 text-center">
          <div className="text-xl font-bold text-purple-700">{mod.features.length}</div>
          <div className="text-xs text-purple-500">Features</div>
        </div>
        <div className="bg-orange-50 border border-orange-200 rounded-xl p-3 text-center">
          <div className="text-xl font-bold text-orange-700">{mod.estimatedDays}d</div>
          <div className="text-xs text-orange-500">Est. Days</div>
        </div>
        <div className="bg-gray-50 border border-gray-200 rounded-xl p-3 text-center">
          <div className="text-xl font-bold text-gray-700">{mod.userRoles.length}</div>
          <div className="text-xs text-gray-500">User Roles</div>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b mb-6 overflow-x-auto">
        <div className="flex gap-1 min-w-max">
          {tabs.map(tab => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`px-4 py-2.5 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
                activeTab === tab.key
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Tab Content */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white rounded-xl border p-5">
            <h3 className="font-semibold mb-3">📋 Required Tables</h3>
            <div className="space-y-1.5">
              {mod.tables.map((t: string) => (
                <div key={t} className="flex items-center gap-2 text-sm bg-gray-50 rounded px-3 py-1.5">
                  <span>📊</span> {t}
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-xl border p-5">
            <h3 className="font-semibold mb-3">🌐 API Endpoints</h3>
            <div className="space-y-1.5">
              {mod.apiEndpoints.map((e: string, i: number) => {
                const [method, ...path] = e.split(' ')
                return (
                  <div key={i} className="flex items-center gap-2 text-sm bg-gray-50 rounded px-3 py-1.5">
                    <span className={`text-xs font-bold px-1.5 py-0.5 rounded ${
                      method === 'GET' ? 'bg-green-200 text-green-800' :
                      method === 'POST' ? 'bg-blue-200 text-blue-800' :
                      method === 'PUT' ? 'bg-yellow-200 text-yellow-800' :
                      'bg-red-200 text-red-800'
                    }`}>{method}</span>
                    <code className="text-xs">{path.join(' ')}</code>
                  </div>
                )
              })}
            </div>
          </div>

          <div className="bg-white rounded-xl border p-5">
            <h3 className="font-semibold mb-3">✨ Features</h3>
            <div className="space-y-1.5">
              {mod.features.map((f: string, i: number) => (
                <div key={i} className="flex items-center gap-2 text-sm">
                  <span className="text-green-500">✓</span> {f}
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-xl border p-5">
            <h3 className="font-semibold mb-3">👥 User Roles</h3>
            <div className="flex flex-wrap gap-2">
              {mod.userRoles.map((r: string) => (
                <span key={r} className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm">{r}</span>
              ))}
            </div>
            <h3 className="font-semibold mt-4 mb-3">🔗 Dependencies</h3>
            <div className="flex flex-wrap gap-2">
              {mod.dependsOn.length > 0 ? mod.dependsOn.map((d: string) => (
                <span key={d} className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm">{d}</span>
              )) : <span className="text-gray-400 text-sm">No dependencies</span>}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'prisma' && code && (
        <div className="space-y-4">
          <ExportButton content={code.prismaSchema} filename={`${mod.key}-schema.prisma`} label="Download Prisma Schema" />
          <CodeBlock code={code.prismaSchema} title={`${mod.name} — Prisma Schema`} />
        </div>
      )}

      {activeTab === 'routes' && code && (
        <div className="space-y-4">
          <ExportButton content={code.apiRoutes} filename={`${mod.key}.routes.ts`} label="Download Routes" />
          <CodeBlock code={code.apiRoutes} title={`${mod.name} — API Routes`} />
        </div>
      )}

      {activeTab === 'controller' && code && (
        <div className="space-y-4">
          <ExportButton content={code.controller} filename={`${mod.key}.controller.ts`} label="Download Controller" />
          <CodeBlock code={code.controller} title={`${mod.name} — Controller`} />
        </div>
      )}

      {activeTab === 'service' && code && (
        <div className="space-y-4">
          <ExportButton content={code.service} filename={`${mod.key}.service.ts`} label="Download Service" />
          <CodeBlock code={code.service} title={`${mod.name} — Service`} />
        </div>
      )}

      {activeTab === 'validation' && code && (
        <div className="space-y-4">
          <ExportButton content={code.validation} filename={`${mod.key}.validation.ts`} label="Download Validation" />
          <CodeBlock code={code.validation} title={`${mod.name} — Validation (Zod)`} />
        </div>
      )}

      {activeTab === 'types' && code && (
        <div className="space-y-4">
          <ExportButton content={code.types} filename={`${mod.key}.types.ts`} label="Download Types" />
          <CodeBlock code={code.types} title={`${mod.name} — TypeScript Types`} />
        </div>
      )}

      {activeTab === 'frontend' && code && (
        <div className="space-y-4">
          <ExportButton content={code.frontendPage} filename={`${mod.key}-page.tsx`} label="Download Page" />
          <CodeBlock code={code.frontendPage} title={`${mod.name} — Frontend Page`} />
        </div>
      )}

      {activeTab === 'form' && code && (
        <div className="space-y-4">
          <ExportButton content={code.frontendForm} filename={`${mod.key}-form.tsx`} label="Download Form" />
          <CodeBlock code={code.frontendForm} title={`${mod.name} — Frontend Form`} />
        </div>
      )}
    </div>
  )
}
```

---

## 12. SaaS Checklist Page

```tsx
// src/app/saas-checklist/page.tsx
'use client'

import { useState } from 'react'
import { getSaaSChecklist, ChecklistItem } from '@/lib/saas-framework'
import ExportButton from '@/components/ExportButton'

export default function SaaSChecklistPage() {
  const allItems = getSaaSChecklist()
  const [items, setItems] = useState<(ChecklistItem & { done: boolean })[]>(
    allItems.map(i => ({ ...i, done: false }))
  )
  const [filterPhase, setFilterPhase] = useState<string>('all')
  const [filterCategory, setFilterCategory] = useState<string>('all')

  const toggle = (id: string) => {
    setItems(prev =>
      prev.map(i => (i.id === id ? { ...i, done: !i.done } : i))
    )
  }

  const phases = ['all', ...new Set(allItems.map(i => i.phase))]
  const categories = ['all', ...new Set(allItems.map(i => i.category))]

  const filtered = items.filter(i =>
    (filterPhase === 'all' || i.phase === filterPhase) &&
    (filterCategory === 'all' || i.category === filterCategory)
  )

  const completed = items.filter(i => i.done).length
  const total = items.length
  const percentage = Math.round((completed / total) * 100)

  const phaseEmoji: Record<string, string> = {
    design: '🎨', development: '💻', testing: '🧪',
    deployment: '🚀', 'post-launch': '📈'
  }

  const exportMarkdown = () => {
    let md = '# SaaS Product Checklist\n\n'
    md += `Progress: ${completed}/${total} (${percentage}%)\n\n`
    for (const phase of phases.filter(p => p !== 'all')) {
      md += `## ${phaseEmoji[phase] || ''} ${phase.charAt(0).toUpperCase() + phase.slice(1)}\n\n`
      items
        .filter(i => i.phase === phase)
        .forEach(i => {
          md += `- [${i.done ? 'x' : ' '}] **${i.item}** — ${i.description} [${i.priority}]\n`
        })
      md += '\n'
    }
    return md
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex justify-between items-start mb-6">
        <div>
          <h1 className="text-3xl font-bold">✅ SaaS Product Checklist</h1>
          <p className="text-gray-500">
            Everything you need before launching a healthcare SaaS product
          </p>
        </div>
        <ExportButton content={exportMarkdown()} filename="saas-checklist.md" label="Export" />
      </div>

      {/* Progress */}
      <div className="bg-white rounded-xl border p-6 mb-6">
        <div className="flex justify-between mb-2">
          <span className="font-semibold">Overall Progress</span>
          <span className="font-bold text-blue-600">{completed}/{total} ({percentage}%)</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-4">
          <div
            className="h-4 rounded-full bg-blue-600 transition-all"
            style={{ width: `${percentage}%` }}
          />
        </div>
      </div>

      {/* Filters */}
      <div className="flex gap-4 mb-6">
        <select
          value={filterPhase}
          onChange={e => setFilterPhase(e.target.value)}
          className="border rounded-lg px-3 py-2"
        >
          {phases.map(p => (
            <option key={p} value={p}>
              {p === 'all' ? 'All Phases' : `${phaseEmoji[p] || ''} ${p}`}
            </option>
          ))}
        </select>
        <select
          value={filterCategory}
          onChange={e => setFilterCategory(e.target.value)}
          className="border rounded-lg px-3 py-2"
        >
          {categories.map(c => (
            <option key={c} value={c}>
              {c === 'all' ? 'All Categories' : c}
            </option>
          ))}
        </select>
      </div>

      {/* Checklist */}
      <div className="space-y-3">
        {filtered.map(item => (
          <div
            key={item.id}
            onClick={() => toggle(item.id)}
            className={`bg-white rounded-xl border p-4 cursor-pointer transition-all
              hover:shadow-sm ${item.done ? 'border-green-300 bg-green-50/50' : ''}`}
          >
            <div className="flex items-start gap-3">
              <div className={`w-6 h-6 rounded-md border-2 flex items-center justify-center
                mt-0.5 transition-colors flex-shrink-0
                ${item.done
                  ? 'bg-green-500 border-green-500 text-white'
                  : 'border-gray-300'
                }`}>
                {item.done && <span className="text-xs">✓</span>}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className={`font-medium ${item.done ? 'line-through text-gray-400' : ''}`}>
                    {item.item}
                  </span>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${
                    item.priority === 'critical' ? 'bg-red-100 text-red-700' :
                    item.priority === 'high' ? 'bg-orange-100 text-orange-700' :
                    item.priority === 'medium' ? 'bg-yellow-100 text-yellow-700' :
                    'bg-gray-100 text-gray-600'
                  }`}>
                    {item.priority}
                  </span>
                  <span className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full">
                    {item.category}
                  </span>
                  <span className="text-xs bg-blue-50 text-blue-600 px-2 py-0.5 rounded-full">
                    {phaseEmoji[item.phase]} {item.phase}
                  </span>
                </div>
                <p className={`text-sm mt-1 ${item.done ? 'text-gray-400' : 'text-gray-500'}`}>
                  {item.description}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
```

---

## 13. Updated Sidebar (with new pages)

```tsx
// src/components/Sidebar.tsx
'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'

const NAV = [
  { section: 'Schema Tools' },
  { href: '/',              icon: '🏠', label: 'Home' },
  { href: '/upload',        icon: '📤', label: 'Upload SQL' },
  { href: '/erd',           icon: '🗂️', label: 'ERD Diagram' },
  { href: '/prisma-gen',    icon: '⚙️', label: 'Prisma Schema' },
  { href: '/documentation', icon: '📄', label: 'Documentation' },
  { href: '/uat',           icon: '✅', label: 'UAT Cases' },
  { href: '/flows',         icon: '🔀', label: 'Flows' },

  { section: 'AI Builder' },
  { href: '/ai-chat',          icon: '🤖', label: 'AI Assistant' },
  { href: '/layers',           icon: '🏗️', label: 'HIS Layers' },
  { href: '/modules',          icon: '📦', label: 'Module Map' },
  { href: '/architecture',     icon: '🏛️', label: 'Architecture' },

  { section: 'Product' },
  { href: '/saas-checklist',   icon: '☑️', label: 'SaaS Checklist' },
  { href: '/requirements',     icon: '📋', label: 'Requirements' },
  { href: '/roadmap',          icon: '🗺️', label: 'Roadmap' },
]

export default function Sidebar() {
  const pathname = usePathname()

  return (
    <aside className="w-64 bg-gray-900 text-white min-h-screen flex flex-col">
      <div className="text-xl font-bold p-4 text-center border-b border-gray-700">
        🛠️ Schema Toolkit
      </div>

      <nav className="flex-1 overflow-auto py-2">
        {NAV.map((item, i) => {
          if ('section' in item && !('href' in item)) {
            return (
              <div key={i} className="px-4 pt-4 pb-1 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                {item.section}
              </div>
            )
          }

          if ('href' in item) {
            const isActive = pathname === item.href ||
              (item.href !== '/' && pathname.startsWith(item.href))
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-3 px-4 py-2.5 mx-2 rounded-lg text-sm transition-colors
                  ${isActive
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-300 hover:bg-gray-800 hover:text-white'
                  }`}
              >
                <span>{item.icon}</span>
                <span>{item.label}</span>
              </Link>
            )
          }

          return null
        })}
      </nav>

      <div className="p-4 border-t border-gray-700">
        <div className="text-xs text-gray-500 text-center">
          v2.0 — AI-Powered
        </div>
      </div>
    </aside>
  )
}
```

---

## 14. Modules Overview Page

```tsx
// src/app/modules/page.tsx
'use client'

import { useState } from 'react'
import Link from 'next/link'
import { HIS_LAYERS, getAllModules, getDependencyChain } from '@/lib/layer-definitions'
import MermaidRenderer from '@/components/MermaidRenderer'

export default function ModulesPage() {
  const [view, setView] = useState<'grid' | 'graph'>('grid')

  const allModules = getAllModules()

  // Build dependency graph Mermaid
  const graphLines = ['flowchart TD']
  for (const layer of HIS_LAYERS) {
    graphLines.push(`  subgraph L${layer.number}["${layer.icon} Layer ${layer.number}"]`)
    for (const mod of layer.modules) {
      const icon = mod.revenue ? '💰' : mod.priority === 'critical' ? '🔴' : '🔵'
      graphLines.push(`    ${mod.key}["${icon} ${mod.name}"]`)
    }
    graphLines.push('  end')
  }
  for (const mod of allModules) {
    for (const dep of mod.dependsOn) {
      graphLines.push(`  ${dep} --> ${mod.key}`)
    }
  }
  const graph = graphLines.join('\n')

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold">📦 Module Dependency Map</h1>
          <p className="text-gray-500">
            {allModules.length} modules across {HIS_LAYERS.length} layers
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setView('grid')}
            className={`px-4 py-2 rounded-lg text-sm ${
              view === 'grid' ? 'bg-blue-600 text-white' : 'bg-gray-200'
            }`}
          >
            Grid View
          </button>
          <button
            onClick={() => setView('graph')}
            className={`px-4 py-2 rounded-lg text-sm ${
              view === 'graph' ? 'bg-blue-600 text-white' : 'bg-gray-200'
            }`}
          >
            Graph View
          </button>
        </div>
      </div>

      {view === 'graph' ? (
        <MermaidRenderer chart={graph} title="Module Dependency Graph" />
      ) : (
        <div className="space-y-6">
          {HIS_LAYERS.map(layer => (
            <div key={layer.number}>
              <h2 className="text-lg font-bold mb-3">{layer.title}</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {layer.modules.map(mod => (
                  <Link
                    key={mod.key}
                    href={`/modules/${mod.key}`}
                    className="bg-white rounded-xl border p-4 hover:shadow-lg transition-all
                               hover:-translate-y-0.5"
                  >
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-semibold">{mod.name}</h3>
                      <div className="flex gap-1">
                        {mod.revenue && <span title="Revenue">💰</span>}
                        <span className={`text-xs px-2 py-0.5 rounded-full ${
                          mod.priority === 'critical' ? 'bg-red-100 text-red-700' :
                          mod.priority === 'high' ? 'bg-orange-100 text-orange-700' :
                          'bg-blue-100 text-blue-700'
                        }`}>{mod.priority}</span>
                      </div>
                    </div>
                    <p className="text-gray-500 text-xs mb-3">{mod.description}</p>
                    <div className="flex gap-3 text-xs text-gray-400">
                      <span>📋 {mod.tables.length}</span>
                      <span>🌐 {mod.apiEndpoints.length}</span>
                      <span>📅 {mod.estimatedDays}d</span>
                      <span>👥 {mod.userRoles.length}</span>
                    </div>
                    {mod.dependsOn.length > 0 && (
                      <div className="mt-2 text-xs text-gray-400">
                        Depends on: {mod.dependsOn.join(', ')}
                      </div>
                    )}
                  </Link>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
```

---

## 15. Roadmap Page

```tsx
// src/app/roadmap/page.tsx
'use client'

import { HIS_LAYERS, getAllModules } from '@/lib/layer-definitions'

export default function RoadmapPage() {
  const allModules = getAllModules()

  const phases = [
    {
      name: 'Phase 1 — MVP Foundation',
      months: 'Month 1-3',
      color: 'blue',
      modules: allModules.filter(m => m.priority === 'critical'),
      goals: [
        'Complete master data setup',
        'Patient registration working',
        'OPD visit flow functional',
        'Basic billing operational',
        'User authentication & RBAC'
      ]
    },
    {
      name: 'Phase 2 — Revenue Modules',
      months: 'Month 4-6',
      color: 'green',
      modules: allModules.filter(m => m.priority === 'high' && m.revenue),
      goals: [
        'Pharmacy management live',
        'Laboratory system operational',
        'Insurance claims processing',
        'Complete billing with all payment methods'
      ]
    },
    {
      name: 'Phase 3 — Clinical Depth',
      months: 'Month 7-9',
      color: 'purple',
      modules: allModules.filter(m => m.priority === 'high' && !m.revenue),
      goals: [
        'EMR/clinical documentation',
        'E-Prescription system',
        'Radiology module',
        'IPD complete workflow'
      ]
    },
    {
      name: 'Phase 4 — Enterprise',
      months: 'Month 10-12',
      color: 'orange',
      modules: allModules.filter(m => m.priority === 'medium'),
      goals: [
        'Accounting & GL integration',
        'HR & payroll',
        'Inventory management',
        'Analytics dashboards',
        'Patient portal'
      ]
    },
  ]

  const colorMap: Record<string, string> = {
    blue: 'border-blue-500 bg-blue-50',
    green: 'border-green-500 bg-green-50',
    purple: 'border-purple-500 bg-purple-50',
    orange: 'border-orange-500 bg-orange-50',
  }

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-2">🗺️ Product Roadmap</h1>
      <p className="text-gray-500 mb-8">
        Recommended phased approach to building your HIS SaaS product
      </p>

      <div className="relative">
        {/* Timeline line */}
        <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gray-300" />

        {/* Phases */}
        <div className="space-y-12">
          {phases.map((phase, i) => (
            <div key={i} className="relative pl-20">
              {/* Timeline dot */}
              <div className={`absolute left-6 top-2 w-5 h-5 rounded-full border-4 bg-white
                border-${phase.color}-500`} />

              <div className={`border-l-4 rounded-xl p-6 ${colorMap[phase.color]}`}>
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h2 className="text-xl font-bold">{phase.name}</h2>
                    <p className="text-gray-500">{phase.months}</p>
                  </div>
                  <div className="text-right text-sm text-gray-500">
                    {phase.modules.length} modules<br />
                    {phase.modules.reduce((a, m) => a + m.estimatedDays, 0)} dev-days
                  </div>
                </div>

                {/* Goals */}
                <div className="mb-4">
                  <h3 className="font-semibold text-sm mb-2">🎯 Goals</h3>
                  <div className="space-y-1">
                    {phase.goals.map((g, j) => (
                      <div key={j} className="flex items-center gap-2 text-sm">
                        <span className="text-green-500">○</span> {g}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Modules */}
                <div>
                  <h3 className="font-semibold text-sm mb-2">📦 Modules</h3>
                  <div className="flex flex-wrap gap-2">
                    {phase.modules.map(m => (
                      <span
                        key={m.key}
                        className="bg-white border rounded-full px-3 py-1 text-xs"
                      >
                        {m.revenue ? '💰 ' : ''}{m.name} ({m.estimatedDays}d)
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Summary */}
      <div className="mt-12 bg-gray-900 text-white rounded-2xl p-8">
        <h2 className="text-xl font-bold mb-4">📊 Total Project Summary</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          <div>
            <div className="text-3xl font-bold text-blue-400">{allModules.length}</div>
            <div className="text-gray-400 text-sm">Total Modules</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-green-400">
              {allModules.reduce((a, m) => a + m.tables.length, 0)}
            </div>
            <div className="text-gray-400 text-sm">Database Tables</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-purple-400">
              {allModules.reduce((a, m) => a + m.apiEndpoints.length, 0)}
            </div>
            <div className="text-gray-400 text-sm">API Endpoints</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-orange-400">
              {allModules.reduce((a, m) => a + m.estimatedDays, 0)}
            </div>
            <div className="text-gray-400 text-sm">Total Dev-Days</div>
          </div>
        </div>
      </div>
    </div>
  )
}
```

---

## Running Everything

```bash
# Install dependencies
npm install prisma @prisma/client mermaid lucide-react zod

# Setup database with new models
npx prisma migrate dev --name add-ai-builder

# Generate Prisma client
npx prisma generate

# Run the app
npm run dev
```

---

## Complete Workflow Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                    SCHEMA TOOLKIT v2.0                      │
│                  AI-Powered SaaS Builder                    │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  📤 Upload SQL ──→ 🔍 Parse ──→ 💾 Store in DB            │
│       │                                                     │
│       ▼                                                     │
│  ┌─────────────────────────────────────────┐               │
│  │         AI Analysis Engine              │               │
│  │                                         │               │
│  │  • Schema analysis & gap detection      │               │
│  │  • Layer coverage mapping               │               │
│  │  • Dependency resolution                │               │
│  │  • Build order recommendation           │               │
│  │  • Timeline estimation                  │               │
│  │  • SaaS architecture advice             │               │
│  └─────────────┬───────────────────────────┘               │
│                │                                            │
│       ┌────────┴─────────┐                                 │
│       ▼                  ▼                                  │
│  ┌─────────┐      ┌──────────┐                             │
│  │Generate │      │ AI Chat  │                             │
│  │         │      │          │                             │
│  │• Prisma │      │ Ask any  │                             │
│  │• ERD    │      │ question │                             │
│  │• Docs   │      │ about    │                             │
│  │• UAT    │      │ your     │                             │
│  │• Flows  │      │ project  │                             │
│  │• APIs   │      │          │                             │
│  │• Code   │      │          │                             │
│  └─────────┘      └──────────┘                             │
│       │                                                     │
│       ▼                                                     │
│  ┌──────────────────────────────────┐                      │
│  │     Module-by-Module Builder     │                      │
│  │                                  │                      │
│  │  Layer 1 → Layer 2 → Layer 3    │                      │
│  │     ↓         ↓         ↓       │                      │
│  │  Foundation  Core    Revenue    │                      │
│  │     ↓         ↓         ↓       │                      │
│  │  Layer 4 → Layer 5 → Layer 6    │                      │
│  │     ↓         ↓         ↓       │                      │
│  │  Clinical  Enterprise Advanced  │                      │
│  └──────────────────────────────────┘                      │
│       │                                                     │
│       ▼                                                     │
│  ┌──────────────────────────────────┐                      │
│  │      For Each Module:            │                      │
│  │                                  │                      │
│  │  📊 Prisma Schema               │                      │
│  │  🛣️ API Routes                  │                      │
│  │  🎮 Controller Code             │                      │
│  │  ⚡ Service Layer               │                      │
│  │  ✅ Zod Validation              │                      │
│  │  📝 TypeScript Types            │                      │
│  │  🖥️ Frontend Page              │                      │
│  │  📄 Frontend Form               │                      │
│  │  ✅ UAT Test Cases              │                      │
│  └──────────────────────────────────┘                      │
│       │                                                     │
│       ▼                                                     │
│  ☑️ SaaS Checklist → 🗺️ Roadmap → 🚀 Launch             │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

This gives you a **complete AI-powered platform** that takes your SQL files and builds an entire SaaS HIS product systematically — layer by layer, module by module — with generated code, documentation, tests, and architecture guidance at every step.