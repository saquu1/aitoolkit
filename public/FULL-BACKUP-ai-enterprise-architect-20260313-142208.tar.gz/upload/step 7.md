

# Expert Analysis — Stored Procedure Intelligence

---

## What You Have

You have **stored procedures** that are a goldmine of business logic, data relationships, and operational workflows that your CREATE TABLE scripts alone can't reveal.

Let me break down what you can extract from stored procedures and how it fits into every section of your platform.

---

## What Stored Procedures Tell You That Tables Don't

### 1. Business Logic Discovery

Your two example SPs reveal:

```
SP_DDL_GetSpecialities
├── This is a DROPDOWN data source (DDL = Drop Down List)
├── It filters by BranchId → Multi-branch aware
├── It joins BranchSpecialities → Specialities are branch-specific
├── Commented code shows FeeTypes was considered → Fee system exists
├── Returns Id + Name → Standard lookup pattern
│
└── BUSINESS INSIGHT: Specialities are NOT global. Each branch 
    can have different specialities. This affects the Organization 
    Setup module significantly.

SP_AdmissionQueue_GetChallanNo
├── Takes BranchId + PatientId + VisitNo → Three-key lookup
├── Queries ChallanForms table → Financial document system
├── Filters IsDeleted=0 → Soft delete pattern confirmed
├── VisitNo is NVARCHAR not INT → Visit numbers are formatted strings
├── Returns ChallanNo → Sequential document numbering system
│
└── BUSINESS INSIGHT: Each patient visit generates a Challan (payment 
    receipt). The system tracks visits by formatted visit numbers, 
    not simple IDs. Challans are branch-specific.
```

**Tables tell you WHAT data exists. Stored procedures tell you HOW the data is used.**

---

## What You Can Extract From Every Stored Procedure

### Layer 1: Technical Extraction

```
From every SP, automatically parse:
├── SP Name → Module identification + action type
├── Parameters → API input schema (request body/query params)
├── Parameter types → TypeScript types + validation rules
├── Parameter defaults → Optional vs required fields
├── Tables referenced → Table dependency map
├── JOINs used → Relationship confirmation (even without FK constraints)
├── WHERE clauses → Business filter rules
├── Column aliases → UI display names (Id→value, Name→label)
├── INSERT/UPDATE/DELETE → Write operation identification
├── SELECT → Read operation identification
├── Commented code → Historical context and alternatives considered
└── Database name → Multi-database awareness
```

### Layer 2: Business Logic Extraction

```
From SP naming patterns:
├── SP_DDL_*      → Dropdown/Lookup data source
├── SP_Get*       → Read/Query operation
├── SP_Add*       → Create operation
├── SP_Update*    → Update operation
├── SP_Delete*    → Delete operation
├── SP_Save*      → Create or Update (upsert)
├── SP_Search*    → Search/Filter operation
├── SP_Report*    → Reporting query
├── SP_Validate*  → Validation logic
├── SP_Count*     → Dashboard/Statistics query
├── SP_Check*     → Existence/Permission check
├── SP_Process*   → Multi-step business workflow
└── SP_Batch*     → Bulk operation
```

### Layer 3: Relationship Discovery

This is the **killer insight.** Stored procedures reveal relationships that FK constraints DON'T capture.

Example: Your SP joins `BranchSpecialities` with filtering by `BranchId`. Even if there's no FK constraint in the table DDL, the SP proves these tables are related. Your system should:

```
SP references table "ChallanForms" with columns:
  - PatientId (likely FK to Patients)
  - VisitNo (likely FK or reference to Visits)
  - BranchId (likely FK to Branches)
  - ChallanNo (the output — likely unique per branch)
  - IsDeleted (confirms soft-delete pattern)

DISCOVERED TABLE: ChallanForms
  → Not in your uploaded schema yet
  → SP proves it exists in the real database
  → Auto-add to "Discovered Tables" list
  → Auto-link to Finance module
```

**This means SPs can DISCOVER tables you haven't uploaded yet — without the user even knowing those tables exist.**

---

## How This Fits Into EVERY Section of Your Platform

### 1. Upload Page Enhancement

```
Current: Upload SQL DDL (CREATE TABLE)
Enhanced: Upload SQL DDL + Stored Procedures + Views + Functions

SP Upload adds:
┌──────────────────────────────────────────────────┐
│ Upload Results                                    │
│                                                   │
│ Tables:            8 (from DDL)                   │
│ Stored Procedures: 47 (new!)                      │
│ Tables discovered  12 (referenced in SPs but      │
│   from SPs:           not in uploaded DDL!)        │
│ API endpoints      47 (one per SP)                │
│   identified:                                     │
│ Dropdown sources:  15 (SP_DDL_* procedures)       │
│ Business rules:    23 (extracted from SP logic)    │
│                                                   │
│ ⚠️ 12 tables referenced in SPs are not yet        │
│    uploaded. Upload their DDL to complete the      │
│    schema.                                         │
└──────────────────────────────────────────────────┘
```

The SP parser becomes a **second discovery engine** — it finds tables, relationships, and business logic that the DDL parser misses.

---

### 2. ERD Enhancement

SPs reveal **implicit relationships** — tables that are joined in queries but don't have formal FK constraints. Your ERD should show TWO types of lines:

```
Solid line  ──── : FK constraint exists (from DDL)
Dashed line ---- : Implicit relationship (discovered from SP JOINs)

Organizations ══════ OrganizationTypes     (FK exists)
Organizations ------  BranchSpecialities    (joined in SP, no FK)
Patients ------  ChallanForms              (joined in SP, no FK)
```

This gives a **more complete picture** of the actual data architecture than DDL alone. In many legacy databases, developers relied on SP-level joins instead of FK constraints. Your tool catches what others miss.

---

### 3. Prisma Schema Enhancement

SPs help you generate **better** Prisma models:

```
Without SP knowledge:
  model ChallanForm {
    id        String @id
    // ... columns from DDL only
  }

With SP knowledge:
  model ChallanForm {
    id          String   @id
    challanNo   String   // SP shows this is the output/display field
    patientId   String   // SP proves FK to Patient
    visitNo     String   // SP proves this is NVARCHAR, not INT
    branchId    String   // SP proves FK to Branch  
    isDeleted   Boolean  @default(false)  // SP confirms soft-delete
    
    patient     Patient  @relation(fields: [patientId], references: [id])
    branch      Branch   @relation(fields: [branchId], references: [id])
    
    // DISCOVERED FROM SP: SP_AdmissionQueue_GetChallanNo
    // Query pattern: lookup by patientId + visitNo + branchId
    @@unique([patientId, visitNo, branchId])  // SP implies this is unique
  }
```

The SP told us about a **unique compound key** that the DDL might not explicitly define. This is real-world intelligence.

---

### 4. Documentation Enhancement

SPs are the **richest source of documentation** in any legacy system. Auto-generate:

```
## API: Get Specialities by Branch

**Source:** SP_DDL_GetSpecialities
**Module:** Doctor Management → Specialities
**Type:** Dropdown Data Source

### Purpose
Returns the list of specialities available at a specific branch.
Specialities are branch-specific — not all branches offer all specialities.

### Parameters
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| BranchId  | INT  | No       | 0       | Branch to filter by |

### Returns
| Column | Type | Description |
|--------|------|-------------|
| Id     | INT  | Speciality ID (use as dropdown value) |
| Name   | NVARCHAR | Speciality name (use as dropdown label) |

### Tables Used
- BranchSpecialities (primary)

### Business Rules
- Results ordered alphabetically by Name
- Branch ID 0 returns empty (no global list)
- Only active branch-speciality assignments returned

### Related SPs
- SP_DDL_GetSubSpecialities (child dropdown)
- SP_Save_BranchSpeciality (manage assignments)
- SP_Delete_BranchSpeciality (remove assignments)
```

This documentation is **auto-generated from parsing the SP** — not manually written. Every SP becomes a documented API endpoint automatically.

---

### 5. UAT Test Cases Enhancement

SPs define exact test scenarios:

```
SP: SP_AdmissionQueue_GetChallanNo

AUTO-GENERATED TEST CASES:

TC-001: Valid Challan Lookup
  Given: Valid BranchId, PatientId, and VisitNo
  When: SP is called
  Then: Returns matching ChallanNo
  Priority: High

TC-002: No Matching Challan
  Given: Valid parameters but no matching record
  When: SP is called
  Then: Returns empty result
  Priority: High

TC-003: Deleted Challan Excluded
  Given: ChallanForm exists but IsDeleted = 1
  When: SP is called
  Then: Should NOT return the deleted challan
  Priority: Critical (soft-delete verification)

TC-004: NULL BranchId Handling
  Given: BranchId is NULL (parameter allows NULL)
  When: SP is called
  Then: Should handle gracefully (return empty or error)
  Priority: Medium

TC-005: Cross-Branch Isolation
  Given: ChallanForm exists for Branch A
  When: SP called with Branch B
  Then: Should NOT return Branch A's challan
  Priority: Critical (data isolation)

TC-006: Multiple Challans per Visit
  Given: Patient has multiple challans for same visit
  When: SP is called
  Then: Verify expected behavior (return all? latest?)
  Priority: High (ambiguity detected — SP returns all matches)
```

Notice TC-006 — the SP doesn't have `TOP 1` or `ORDER BY`, which means it could return multiple rows. That's a **potential bug** your system detected automatically.

---

### 6. Flow Diagrams Enhancement

SPs define the **actual business workflows**:

```
From SP naming patterns, reconstruct the Admission flow:

SP_AdmissionQueue_GetChallanNo      ← Step 1: Get payment challan
SP_AdmissionQueue_GetPatientInfo    ← Step 2: Load patient details
SP_AdmissionQueue_CheckBedAvail     ← Step 3: Check bed availability
SP_AdmissionQueue_AssignBed         ← Step 4: Assign bed to patient
SP_AdmissionQueue_CreateAdmission   ← Step 5: Create admission record
SP_AdmissionQueue_SendNotification  ← Step 6: Notify nursing station

AUTO-GENERATED FLOW:
┌─────────┐     ┌──────────┐     ┌──────────┐
│ Get      │────→│ Load     │────→│ Check    │
│ Challan  │     │ Patient  │     │ Bed      │
└─────────┘     └──────────┘     └──────────┘
                                       │
                                  ┌────┴────┐
                                  │Available?│
                                  └────┬────┘
                               Yes│      │No
                                  ▼      ▼
                            ┌─────────┐ ┌──────┐
                            │ Assign  │ │Wait  │
                            │ Bed     │ │List  │
                            └────┬────┘ └──────┘
                                 │
                            ┌────▼────┐
                            │ Create  │
                            │Admission│
                            └────┬────┘
                                 │
                            ┌────▼────┐
                            │ Notify  │
                            │ Nurses  │
                            └─────────┘
```

**You reconstructed the entire admission workflow just by analyzing SP names.** This is incredibly valuable for documentation and for new team members understanding the system.

---

### 7. Column Intelligence Enhancement

SPs reveal column USAGE patterns that DDL alone can't:

```
DDL tells you:     VisitNo is NVARCHAR(MAX)
SP tells you:      VisitNo is used as a LOOKUP KEY
                   VisitNo is passed as a PARAMETER
                   VisitNo is used in WHERE clause with equality
                   
Combined insight:  VisitNo is a SEARCH FIELD
                   UI should have: Text input with autocomplete
                   Validation: Required, format check
                   Index recommendation: Should be indexed
                   
DDL tells you:     ChallanNo is a column in ChallanForms
SP tells you:      ChallanNo is the RETURN VALUE / OUTPUT
                   It's what the user SEES
                   
Combined insight:  ChallanNo is a DISPLAY FIELD
                   UI should show it prominently
                   It's likely printed on receipts
                   Should be formatted (not raw)
```

---

### 8. AI Question Engine Enhancement

SPs reveal questions the AI should ask:

```
From SP_DDL_GetSpecialities:

🤖 AI Questions Detected:

Q1: "The SP filters specialities by BranchId. Should the 
     speciality dropdown in the UI automatically filter when 
     the user selects a branch?"
     □ Yes, cascade automatically
     □ No, show all specialities
     □ Show all but highlight branch-specific ones

Q2: "The SP uses BranchId=0 as default. What should happen 
     when no branch is selected?"
     □ Show empty dropdown
     □ Show all specialities across all branches
     □ Show specialities from user's default branch

Q3: "There's commented-out code referencing FeeTypes. 
     Should the speciality dropdown also load fee types?"
     □ Yes, it's a related dropdown
     □ No, it was removed intentionally
     □ Not sure — need to investigate
```

**The AI is asking questions based on actual code analysis**, not generic templates. This is context-aware intelligence.

---

### 9. SOP (Standard Operating Procedures) — NEW Section

This is a section you listed but haven't built. SPs are the **perfect source** for SOPs:

```
SOP: Patient Admission Process
Generated from: 6 stored procedures matching "AdmissionQueue"

Step 1: VERIFY PAYMENT
   System Action: Call SP_AdmissionQueue_GetChallanNo
   User Action: Verify challan number is valid
   Required Info: Patient ID, Visit Number, Branch
   Business Rule: Cannot proceed without valid challan
   Exception: Emergency admission bypasses challan check

Step 2: REVIEW PATIENT INFORMATION
   System Action: Call SP_AdmissionQueue_GetPatientInfo
   User Action: Verify patient demographics are current
   Required Info: Patient ID
   Business Rule: Update outdated info before admission

Step 3: CHECK BED AVAILABILITY
   System Action: Call SP_AdmissionQueue_CheckBedAvail
   User Action: Select appropriate ward and bed
   Required Info: Department, Ward Type, Patient Gender
   Business Rule: Gender-specific wards must match patient
   
... and so on
```

**You auto-generated a Standard Operating Procedure from stored procedures.** Hospital administrators would pay significant money for this alone.

---

### 10. Hub — API Service Registry

Your "Hub" section should become an **API Registry** built from SPs:

```
API Hub — 47 Endpoints Discovered
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Module: Doctor Management
┌────────────────────────────────────────────────────────┐
│ GET  /api/specialities?branchId={id}                   │
│ Source: SP_DDL_GetSpecialities                         │
│ Type: Dropdown Data Source                             │
│ Params: branchId (int, optional, default: 0)           │
│ Returns: Array<{ id: number, name: string }>           │
│ Cache: ✅ Yes (changes rarely)                         │
│ Auth: Required                                         │
│ [📄 Docs] [🧪 Test] [⚡ Generate Code] [📋 Swagger]   │
└────────────────────────────────────────────────────────┘

Module: Admission & Discharge
┌────────────────────────────────────────────────────────┐
│ GET  /api/admission/challan?patientId={}&visitNo={}&   │
│      branchId={}                                       │
│ Source: SP_AdmissionQueue_GetChallanNo                 │
│ Type: Lookup Query                                     │
│ Params: patientId (uuid), visitNo (string),            │
│         branchId (uuid)                                │
│ Returns: { challanNo: string }                         │
│ Cache: ❌ No (real-time data)                          │
│ Auth: Required + Branch Access                         │
│ [📄 Docs] [🧪 Test] [⚡ Generate Code] [📋 Swagger]   │
└────────────────────────────────────────────────────────┘
```

Each SP becomes a **documented, testable, code-generatable API endpoint.** The Hub becomes the central registry of everything your system can do.

---

## Micro/Mini Services Architecture From SPs

SPs naturally cluster into service boundaries:

```
FROM SP NAMING PATTERNS:

SP_DDL_*                  → Lookup Service (all dropdown data)
SP_Patient_*              → Patient Service
SP_AdmissionQueue_*       → Admission Service
SP_Appointment_*          → Appointment Service
SP_Billing_*              → Billing Service
SP_Lab_*                  → Laboratory Service
SP_Pharmacy_*             → Pharmacy Service
SP_Report_*               → Reporting Service
SP_Dashboard_*            → Analytics Service
SP_Auth_*, SP_User_*      → Auth Service
SP_HR_*, SP_Employee_*    → HR Service

Each cluster becomes a:
├── Microservice boundary
├── API route group
├── Prisma model group
├── Frontend module
└── Team ownership boundary
```

**You can auto-suggest microservice architecture from SP naming conventions.** This is architecture intelligence that usually requires a senior architect and weeks of analysis.

---

## The New Upload Flow I'd Recommend

```
┌─────────────────────────────────────────────────────────┐
│                     UPLOAD CENTER                        │
│                                                          │
│  What are you uploading?                                 │
│                                                          │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌────────┐ │
│  │  📋      │  │  ⚡      │  │  👁️      │  │  🔧    │ │
│  │  Tables  │  │  Stored  │  │  Views   │  │ Funcs  │ │
│  │  (DDL)   │  │  Procs   │  │          │  │        │ │
│  │          │  │          │  │          │  │        │ │
│  │ 8 loaded │  │ 0 loaded │  │ 0 loaded │  │ 0      │ │
│  └──────────┘  └──────────┘  └──────────┘  └────────┘ │
│                                                          │
│  [📤 Upload Files]  [📋 Paste SQL]  [🔗 Connect to DB]  │
│                                                          │
│  ─── Or upload everything at once ───                    │
│  [📦 Upload Complete Database Script]                    │
│                                                          │
└─────────────────────────────────────────────────────────┘
```

The system auto-detects what's in the uploaded file:

```
Processing: complete_database.sql

Detected:
  ✅ 47 CREATE TABLE statements
  ✅ 128 stored procedures
  ✅ 12 views
  ✅ 5 functions
  ✅ 23 ALTER TABLE (FK additions)
  ⚠️ 3 parsing errors (line 4521, 6823, 9102)
  
Extracting intelligence...
  📋 47 tables with 312 columns
  🔗 89 FK relationships (67 resolved, 22 missing)
  ⚡ 128 API endpoints identified
  📊 15 dropdown data sources found
  🔄 8 business workflows reconstructed
  📈 12 reporting queries found
  🏗️ 6 microservice boundaries suggested
```

**One upload → complete system understanding.** That's the vision.

---

## SP Categories and What Each Generates

```
SP CATEGORY          WHAT IT GENERATES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SP_DDL_*             → Dropdown component
(Dropdown)             React <Select> with API call
                       Cached lookup service
                       Seed data script

SP_Get*/SP_Fetch*    → List/Detail page
(Read)                 Data table component
                       API GET endpoint
                       Search/filter logic

SP_Add*/SP_Create*   → Create form
(Create)               React form component
                       API POST endpoint
                       Validation schema (Zod)

SP_Update*/SP_Save*  → Edit form
(Update)               React form with pre-fill
                       API PUT endpoint
                       Diff tracking

SP_Delete*           → Delete action
(Delete)               Confirmation dialog
                       API DELETE endpoint
                       Soft-delete logic

SP_Search*           → Search component
(Search)               Debounced search input
                       Advanced filter panel
                       API GET with query params

SP_Report*           → Report page
(Report)               Data visualization
                       Export to Excel/PDF
                       Scheduled report config

SP_Validate*         → Validation rule
(Validate)             Client-side validation
                       Server-side middleware
                       Error message mapping

SP_Process*          → Multi-step workflow
(Workflow)             Step wizard component
                       State machine
                       Transaction management

SP_Count*            → Dashboard widget
(Statistics)           KPI card component
                       Real-time counter
                       Trend chart
```

---

## My Strategic Recommendation

### Don't treat SPs as "just another upload type."

**Treat SP parsing as a MAJOR feature** — potentially more valuable than table parsing. Here's why:

- Tables tell you the STRUCTURE (nouns)
- SPs tell you the BEHAVIOR (verbs)
- Structure without behavior is a database diagram
- **Structure WITH behavior is a working system**

Most schema tools stop at tables. If your tool understands SPs, you can:

1. **Reverse-engineer the entire application** from the database
2. **Generate a working API** that matches the existing system behavior
3. **Create accurate documentation** of how the system actually works (not how it was designed to work)
4. **Identify technical debt** (unused SPs, redundant queries, missing indexes)
5. **Plan the migration** from SP-based to ORM-based architecture with confidence

**This is enterprise migration intelligence.** Companies pay consulting firms $100K+ to analyze legacy databases and plan migrations. Your tool could do 80% of that work automatically.

### Build the SP Parser Right After Column Intelligence

```
Priority order:
1. Column Intelligence Engine     ← understand columns semantically
2. SP Parser & Intelligence       ← understand behavior and workflows
3. Screen Blueprint Generator     ← use both to generate smart UIs
4. AI Question Engine            ← ask questions based on full context
```

With both table intelligence AND SP intelligence, your system has a **complete understanding** of the database — structure, behavior, relationships, and business rules. Everything else you generate becomes dramatically better because the context is richer.

**One final thought:** When you parse SPs from a real production database like iHealthCure, you'll likely find 500-2000 stored procedures. Each one is a documented business decision. Together, they represent **years of domain knowledge** encoded in SQL. Your tool is the first to unlock that knowledge and make it accessible to the entire team. That's genuinely powerful.