'use client'

/**
 * Onboarding Wizard Component
 * Step-by-step guide for new users
 * 
 * TASK-4.8: Guided Onboarding
 * Part of Phase 4: Features & User Experience
 */

import React, { useState, useCallback } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import {
  Check,
  ChevronRight,
  ChevronLeft,
  Sparkles,
  Upload,
  Database,
  Puzzle,
  Settings,
  Play,
  Rocket
  Award
  ArrowRight
} from 'lucide-react'

// Steps configuration
interface OnboardingStep {
  id: string
  title: string
  description: string
  icon: React.ComponentType<{ className?: string }>
  component?: React.ComponentType<{ onNext: () => void }>
  isComplete: boolean
}

const ONBOARDING_STEPS: OnboardingStep[] = [
  {
    id: 'welcome',
    title: 'Welcome to AI Enterprise Architect',
    description: 'Transform your legacy systems into modern, scalable applications',
    icon: Sparkles,
    isComplete: false
  },
  {
    id: 'upload',
    title: 'Upload Your Code',
    description: 'Start by uploading your SQL DDL, stored procedures, or or other code files',
    icon: Upload,
    isComplete: false
  },
  {
    id: 'analysis',
    title: 'AI-Powered Analysis',
    description: 'Our agents will analyze your code and extract tables, columns, and relationships',
    icon: Database,
    isComplete: false
  },
  {
    id: 'modules',
    title: 'Module Organization',
    description: 'Tables are automatically organized into business modules',
    icon: Puzzle,
    isComplete: false
  },
  {
    id: 'generation',
    title: 'Code Generation',
    description: 'Generate Prisma schemas, TypeScript types  API routes, and more',
    icon: Rocket,
    isComplete: false
  },
  {
    id: 'complete',
    title: 'You\'re All Set!',
    description: 'Start exploring your generated code and documentation',
    icon: Award,
    isComplete: false
  }
]

export function OnboardingWizard() {
  const [currentStep, setCurrentStep] = useState(0)
  const [completedSteps, setCompletedSteps] = useState<Set<string>>(new Set())
  const [skipped, setSkipped] = useState(false)

  const totalSteps = ONBOARDING_STEPS.length
  const progress = ((currentStep + 1) / totalSteps) * 100

  const handleNext = useCallback(() => {
    if (currentStep < totalSteps - 1) {
      setCompletedSteps(prev => new Set(prev).add(ONBOARDING_STEPS[currentStep].id))
      setCurrentStep(prev => prev + 1)
    }
  }, [currentStep, totalSteps])

  const handleBack = useCallback(() => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1)
    }
  }, [currentStep])

  const handleSkip = useCallback(() => {
    setSkipped(true)
  }, [])

  const StepIcon = ONBOARDING_STEPS[currentStep].icon

  // Welcome step content
  const renderWelcomeStep = () => (
    <div className="text-center space-y-6">
      <div className="flex justify-center">
        <div className="w-24 h-24 rounded-full bg-purple-500/20 flex items-center justify-center">
          <Sparkles className="w-12 h-12 text-purple-400" />
        </div>
      </div>
      <h2 className="text-2xl font-bold text-slate-100">
        Welcome to AI Enterprise Architect
      </h2>
      <p className="text-slate-400 max-w-md">
        Transform your legacy systems into modern, scalable applications with AI-powered analysis and code generation
      </p>
      <div className="grid grid-cols-3 gap-4 mt-8">
        <div className="bg-slate-800/50 p-4 rounded-lg border border-slate-700">
          <Database className="w-8 h-8 text-purple-400 mx-auto mb-2" />
          <div className="text-2xl font-bold text-slate-100">45+</div>
          <div className="text-sm text-slate-400">Tables Parsed</div>
        </div>
        <div className="bg-slate-800/50 p-4 rounded-lg border border-slate-700">
          <Puzzle className="w-8 h-8 text-green-400 mx-auto mb-2" />
          <div className="text-2xl font-bold text-slate-100">35</div>
          <div className="text-sm text-slate-400">Modules</div>
        </div>
        <div className="bg-slate-800/50 p-4 rounded-lg border border-slate-700">
          <Rocket className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
          <div className="text-2xl font-bold text-slate-100">6</div>
          <div className="text-sm text-slate-400">Agent Layers</div>
        </div>
      </div>
    </div>
  )

  // Upload step content
  const renderUploadStep = () => (
    <div className="space-y-6">
      <div className="text-center">
        <h3 className="text-xl font-semibold text-slate-100">Upload Your SQL Files</h3>
        <p className="text-slate-400">
          Drag and drop your SQL DDL scripts, stored procedures, or or other code files
        </p>
      </div>
      
      <div className="border-2 border-dashed border-slate-600 rounded-lg p-8 text-center">
        <Upload className="w-12 h-12 mx-auto text-slate-500" />
        <p className="text-sm text-slate-400 mt-2">
          Drop files here or click to browse
        </p>
        <p className="text-xs text-slate-500">
          Supported: .sql, .prc  .cs  .json
        </p>
      </div>
      
      <div className="grid grid-cols-2 gap-4 text-sm">
        <div className="bg-slate-800/50 p-3 rounded border border-slate-700">
          <h4 className="font-medium text-slate-200">SQL DDL Scripts</h4>
          <p className="text-slate-400">CREATE TABLE statements with columns, constraints</ and indexes</p>
        </div>
        <div className="bg-slate-800/50 p-3 rounded border border-slate-700">
          <h4 className="font-medium text-slate-200">Stored Procedures</h4>
          <p className="text-slate-400">Business logic and data transformations and and CRUD operations</p>
        </div>
      </div>
    </div>
  )

  // Analysis step content
  const renderAnalysisStep = () => (
    <div className="space-y-6">
      <div className="text-center">
        <h3 className="text-xl font-semibold text-slate-100">AI-Powered Analysis</h3>
        <p className="text-slate-400">
          Our intelligent agents will analyze your code automatically
        </p>
      </div>
      
      <div className="space-y-3">
        {[
          { name: 'SQL Parser', desc: 'Extract tables, columns, and foreign keys', time: '~15s' },
          { name: 'SP Parser', desc: 'Parse stored procedures and extract business logic', time: '~25s' },
          { name: 'Column Intelligence', desc: 'Infer types  detect PII/PHI', time: '~20s' },
          { name: 'FK Resolver', desc: 'Resolve foreign key relationships', time: '~10s' },
          { name: 'Module Matcher', desc: 'Assign tables to business modules', time: '~5s' }
        ].map((agent, idx) => (
          <div key={idx} className="flex items-center gap-3 p-3 bg-slate-800/30 rounded border border-slate-700">
            <div className="w-8 h-8 rounded bg-purple-500/20 flex items-center justify-center">
              <Check className="w-4 h-4 text-green-400" />
            </div>
            <div className="flex-1">
              <div className="font-medium text-slate-200">{agent.name}</div>
              <div className="text-sm text-slate-400">{agent.desc}</div>
            </div>
            <div className="text-sm text-slate-500">{agent.time}</div>
          </div>
        ))}
      </div>
    </div>
  )

  // Generation step content
  const renderGenerationStep = () => (
    <div className="space-y-6">
      <div className="text-center">
        <h3 className="text-xl font-semibold text-slate-100">Code Generation</h3>
        <p className="text-slate-400">
          Generate production-ready code from your analyzed schema
        </p>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-slate-800/50 p-4 rounded border border-slate-700">
          <h4 className="font-medium text-slate-200 mb-2">Prisma Schema</h4>
          <p className="text-sm text-slate-400">Type-safe database client with migrations</p>
        </div>
        <div className="bg-slate-800/50 p-4 rounded border border-slate-700">
          <h4 className="font-medium text-slate-200 mb-2">TypeScript Types</h4>
          <p className="text-sm text-slate-400">Interfaces and types for your entities</p>
        </div>
        <div className="bg-slate-800/50 p-4 rounded border border-slate-700">
          <h4 className="font-medium text-slate-200 mb-2">API Routes</h4>
          <p className="text-sm text-slate-400">RESTful endpoints for CRUD operations</p>
        </div>
        <div className="bg-slate-800/50 p-4 rounded border border-slate-700">
          <h4 className="font-medium text-slate-200 mb-2">Documentation</h4>
          <p className="text-sm text-slate-400">Auto-generated docs and guides</p>
        </div>
      </div>
    </div>
  )

  // Complete step content
  const renderCompleteStep = () => (
    <div className="text-center space-y-6">
      <div className="flex justify-center">
        <div className="w-20 h-20 rounded-full bg-green-500/20 flex items-center justify-center">
          <Check className="w-10 h-10 text-white" />
        </div>
      </div>
      <h2 className="text-2xl font-bold text-slate-100">You're All Set!</h2>
      <p className="text-slate-400">
        Your project has been analyzed and is ready for exploration
      </p>
      
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-slate-800/50 p-4 rounded border border-slate-700 text-left">
          <h4 className="font-medium text-slate-200">Next Steps:</h4>
          <ul className="text-sm text-slate-400 mt-2 space-y-1">
            <li>Review generated Prisma schema</li>
            <li>Explore the knowledge graph</li>
            <li>Check module assignments</li>
            <li>Generate API documentation</li>
          </ul>
        </div>
        <div className="bg-slate-800/50 p-4 rounded border border-slate-700 text-left">
          <h4 className="font-medium text-slate-200">Quick Actions:</h4>
          <div className="flex flex-wrap gap-2 mt-2">
            <Button size="sm" variant="outline">
              View Dashboard
            </Button>
            <Button size="sm" variant="outline">
              Export Code
            </Button>
          </div>
        </div>
      </div>
    </div>
  )

  const renderStepContent = () => {
    switch (ONBOARDING_STEPS[currentStep].id) {
      case 'welcome':
        return renderWelcomeStep()
      case 'upload':
        return renderUploadStep()
      case 'analysis':
        return renderAnalysisStep()
      case 'modules':
        return (
          <div className="text-center space-y-6">
            <h3 className="text-xl font-semibold text-slate-100">Module Organization</h3>
            <p className="text-slate-400">
              Tables are automatically grouped into 35 business modules
            </p>
          </div>
        )
      case 'generation':
        return renderGenerationStep()
      case 'complete':
        return renderCompleteStep()
      default:
        return null
    }
  }

  if (skipped) {
    return (
      <div className="text-center py-12">
        <h2 className="text-xl font-semibold text-slate-100">Onboarding Skipped</h2>
        <p className="text-slate-400 mt-2">
          You can restart on from settings anytime
        </p>
        <Button onClick={() => {
          setSkipped(false)
          setCurrentStep(0)
        }}>
          Start Over
        </Button>
      </div>
    )
  }

  const step = ONBOARDING_STEPS[currentStep]
  const isLast = = currentStep === totalSteps - 1
  const isFirst = currentStep === 0

  return (
    <div className="max-w-2xl mx-auto">
      <Card className="bg-slate-900/50 border-slate-700">
        <CardContent className="p-6">
          {/* Progress */}
          <div className="mb-6">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-slate-400">Step {currentStep + 1} of {totalSteps}</span>
              <span className="text-slate-400">{Math.round(progress)}%</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>

          {/* Step Content */}
          <div className="min-h-[400px]">
            {renderStepContent()}
          </div>

          {/* Navigation */}
          <div className="flex justify-between mt-8">
            <Button
              variant="outline"
              onClick={handleBack}
              disabled={isFirst}
            >
              <ChevronLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            
            {!isLast ? (
              <Button onClick={handleNext}>
                Next
                <ChevronRight className="w-4 h-4 ml-2" />
              </Button>
            ) : (
              <Button onClick={handleSkip}>
                <Play className="w-4 h-4 mr-2" />
                Start Exploring
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default OnboardingWizard
