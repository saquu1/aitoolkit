// =============================================================================
// Parser Intelligence API Route
// Handles File Classification, JS Parsing, SP Parsing, and Intelligence Storage
// =============================================================================

import { NextRequest, NextResponse } from 'next/server';
import { fileClassifier } from '@/lib/parsers/file-classifier';
import { jsParser } from '@/lib/parsers/js-parser';
import { createSPParser } from '@/lib/sp-parser';
import { parseSqlServer } from '@/lib/sql-parser';
import { parseCSHTMLFiles } from '@/lib/cshtml-parser';
import { db } from '@/lib/db';

// ═══════════════════════════════════════════════════════════════════════════
// MAIN ROUTER
// ═══════════════════════════════════════════════════════════════════════════

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { action } = body;

    switch (action) {
      case 'classify-files':
        return await classifyFiles(body);

      case 'parse-javascript':
        return await parseJavaScript(body);

      case 'parse-stored-procedures':
        return await parseStoredProcedures(body);

      case 'parse-all':
        return await parseAllFiles(body);

      case 'store-intelligence':
        return await storeIntelligence(body);

      default:
        return NextResponse.json({ error: 'Unknown action' }, { status: 400 });
    }
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('Parser API error:', error);
    return NextResponse.json({ error: errorMessage }, { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const action = searchParams.get('action');

    switch (action) {
      case 'get-js-intelligence':
        return await getJSIntelligence(searchParams);

      case 'get-sp-intelligence':
        return await getSPIntelligence(searchParams);

      case 'get-file-classifications':
        return await getFileClassifications(searchParams);

      default:
        return NextResponse.json({ error: 'Unknown action' }, { status: 400 });
    }
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return NextResponse.json({ error: errorMessage }, { status: 500 });
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// FILE CLASSIFICATION
// ═══════════════════════════════════════════════════════════════════════════

interface FileInput {
  name: string;
  content: string;
  path?: string;
}

async function classifyFiles(body: { files: FileInput[]; projectId?: string }) {
  const { files, projectId } = body;

  const classifications = fileClassifier.classifyBatch(files);

  // Store classifications if projectId provided
  if (projectId) {
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const classification = classifications[i];

      await db.fileClassificationCache.upsert({
        where: {
          projectId_filePath: {
            projectId,
            filePath: file.path || file.name
          }
        },
        create: {
          projectId,
          fileName: file.name,
          filePath: file.path || file.name,
          fileType: classification.fileType,
          language: classification.language,
          framework: classification.framework,
          confidence: classification.confidence,
          indicators: JSON.stringify(classification.indicators),
          suggestedParser: classification.suggestedParser,
          fileSize: classification.metadata.size,
          lineCount: classification.metadata.lineCount,
          estimatedComplexity: classification.metadata.estimatedComplexity,
        },
        update: {
          fileType: classification.fileType,
          language: classification.language,
          framework: classification.framework,
          confidence: classification.confidence,
          indicators: JSON.stringify(classification.indicators),
          suggestedParser: classification.suggestedParser,
          fileSize: classification.metadata.size,
          lineCount: classification.metadata.lineCount,
          estimatedComplexity: classification.metadata.estimatedComplexity,
        }
      });
    }
  }

  // Group by file type
  const grouped = classifications.reduce((acc, c) => {
    const type = c.fileType;
    if (!acc[type]) acc[type] = [];
    acc[type].push({
      fileName: c.fileName,
      confidence: c.confidence,
      suggestedParser: c.suggestedParser,
      indicators: c.indicators,
    });
    return acc;
  }, {} as Record<string, unknown[]>);

  return NextResponse.json({
    success: true,
    classifications,
    grouped,
    summary: {
      totalFiles: files.length,
      byType: Object.entries(grouped).map(([type, files]) => ({
        type,
        count: (files as unknown[]).length
      })),
      highConfidence: classifications.filter(c => c.confidence >= 80).length,
      needsReview: classifications.filter(c => c.confidence < 80).length,
    }
  });
}

// ═══════════════════════════════════════════════════════════════════════════
// JAVASCRIPT PARSING
// ═══════════════════════════════════════════════════════════════════════════

async function parseJavaScript(body: { files: FileInput[]; projectId?: string }) {
  const { files, projectId } = body;

  const results = [];

  for (const file of files) {
    const analysis = jsParser.analyze(file.content, file.name);

    results.push({
      fileName: file.name,
      analysis,
    });

    // Store intelligence if projectId provided
    if (projectId) {
      await db.jSIntelligenceCache.upsert({
        where: {
          projectId_fileName: {
            projectId,
            fileName: file.name
          }
        },
        create: {
          projectId,
          fileName: file.name,
          filePath: file.path,
          fileType: file.name.endsWith('.ts') || file.name.endsWith('.tsx') ? 'typescript' : 'javascript',
          framework: analysis.jqueryPlugins.length > 0 ? 'jquery' : 'vanilla',
          complexity: analysis.complexity,
          ajaxCalls: JSON.stringify(analysis.ajaxCalls),
          eventHandlers: JSON.stringify(analysis.eventHandlers),
          dependencies: JSON.stringify(analysis.dependencies),
          formValidations: JSON.stringify(analysis.formValidations),
          discoveredEndpoints: JSON.stringify(analysis.discoveredEndpoints),
          jqueryPlugins: JSON.stringify(analysis.jqueryPlugins),
          bootstrapComponents: JSON.stringify(analysis.bootstrapComponents),
          rawContent: file.content,
        },
        update: {
          framework: analysis.jqueryPlugins.length > 0 ? 'jquery' : 'vanilla',
          complexity: analysis.complexity,
          ajaxCalls: JSON.stringify(analysis.ajaxCalls),
          eventHandlers: JSON.stringify(analysis.eventHandlers),
          dependencies: JSON.stringify(analysis.dependencies),
          formValidations: JSON.stringify(analysis.formValidations),
          discoveredEndpoints: JSON.stringify(analysis.discoveredEndpoints),
          jqueryPlugins: JSON.stringify(analysis.jqueryPlugins),
          bootstrapComponents: JSON.stringify(analysis.bootstrapComponents),
          rawContent: file.content,
        }
      });
    }
  }

  // Aggregate statistics
  const totalAjaxCalls = results.reduce((sum, r) => sum + r.analysis.ajaxCalls.length, 0);
  const totalEventHandlers = results.reduce((sum, r) => sum + r.analysis.eventHandlers.length, 0);
  const totalEndpoints = results.reduce((sum, r) => sum + r.analysis.discoveredEndpoints.length, 0);
  const allJQueryPlugins = [...new Set(results.flatMap(r => r.analysis.jqueryPlugins))];

  return NextResponse.json({
    success: true,
    results,
    summary: {
      totalFiles: files.length,
      totalAjaxCalls,
      totalEventHandlers,
      totalEndpoints,
      jqueryPlugins: allJQueryPlugins,
      averageComplexity: Math.round(results.reduce((sum, r) => sum + r.analysis.complexity, 0) / results.length) || 0,
    }
  });
}

// ═══════════════════════════════════════════════════════════════════════════
// STORED PROCEDURE PARSING
// ═══════════════════════════════════════════════════════════════════════════

async function parseStoredProcedures(body: { sql: string; projectId?: string; existingTables?: unknown[] }) {
  const { sql, projectId, existingTables = [] } = body;

  // Parse SQL to get SPs and tables
  const parseResult = parseSqlServer(sql);
  const procedures = parseResult.procedures || [];
  const tables = parseResult.tables || [];

  // Create SP parser with known tables
  const spParser = createSPParser([...tables, ...existingTables as any[]]);

  const results = [];

  for (const sp of procedures) {
    const intelligence = spParser.analyzeProcedure(sp);
    results.push(intelligence);

    // Store intelligence if projectId provided
    if (projectId) {
      await db.storedProcedureCache.upsert({
        where: {
          projectId_procedureName: {
            projectId,
            procedureName: intelligence.procedureName
          }
        },
        create: {
          projectId,
          procedureName: intelligence.procedureName,
          schemaName: intelligence.schemaName || 'dbo',
          actionType: intelligence.actionType,
          moduleName: intelligence.moduleIdentification.moduleName,
          moduleConfidence: intelligence.moduleIdentification.confidence,
          tablesReferenced: JSON.stringify(intelligence.tablesReferenced),
          implicitJoins: JSON.stringify(intelligence.implicitJoins),
          discoveredTables: JSON.stringify(intelligence.discoveredTables),
          businessRules: JSON.stringify(intelligence.businessRules),
          writeOperations: JSON.stringify(intelligence.writeOperations),
          readOperations: JSON.stringify(intelligence.readOperations),
          parameters: JSON.stringify(intelligence.parameters),
          apiInputSchema: JSON.stringify(intelligence.apiInputSchema),
          complexity: intelligence.complexity,
          riskLevel: intelligence.riskLevel,
          suggestedEndpoint: intelligence.suggestedEndpoint,
          body: intelligence.body,
        },
        update: {
          actionType: intelligence.actionType,
          moduleName: intelligence.moduleIdentification.moduleName,
          moduleConfidence: intelligence.moduleIdentification.confidence,
          tablesReferenced: JSON.stringify(intelligence.tablesReferenced),
          implicitJoins: JSON.stringify(intelligence.implicitJoins),
          discoveredTables: JSON.stringify(intelligence.discoveredTables),
          businessRules: JSON.stringify(intelligence.businessRules),
          writeOperations: JSON.stringify(intelligence.writeOperations),
          readOperations: JSON.stringify(intelligence.readOperations),
          parameters: JSON.stringify(intelligence.parameters),
          apiInputSchema: JSON.stringify(intelligence.apiInputSchema),
          complexity: intelligence.complexity,
          riskLevel: intelligence.riskLevel,
          suggestedEndpoint: intelligence.suggestedEndpoint,
          body: intelligence.body,
        }
      });

      // Store discovered tables separately
      for (const discovered of intelligence.discoveredTables) {
        await db.discoveredTableCache.upsert({
          where: {
            projectId_tableName: {
              projectId,
              tableName: discovered.tableName
            }
          },
          create: {
            projectId,
            tableName: discovered.tableName,
            discoveredInSP: intelligence.procedureName,
            accessType: discovered.accessType,
            columns: JSON.stringify(discovered.columns),
            suggestedModule: discovered.suggestedModule,
            priority: discovered.priority,
          },
          update: {
            discoveredInSP: intelligence.procedureName,
            accessType: discovered.accessType,
            columns: JSON.stringify(discovered.columns),
            suggestedModule: discovered.suggestedModule,
            priority: discovered.priority,
          }
        });
      }
    }
  }

  // Aggregate statistics
  const actionTypes = results.reduce((acc, r) => {
    acc[r.actionType] = (acc[r.actionType] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const allDiscoveredTables = [...new Set(results.flatMap(r => r.discoveredTables.map(t => t.tableName)))];
  const highRiskSPs = results.filter(r => r.riskLevel === 'high' || r.riskLevel === 'critical');

  return NextResponse.json({
    success: true,
    results,
    summary: {
      totalProcedures: procedures.length,
      totalTables: tables.length,
      byActionType: actionTypes,
      discoveredTables: allDiscoveredTables,
      highRiskCount: highRiskSPs.length,
      averageComplexity: Math.round(results.reduce((sum, r) => sum + r.complexity, 0) / results.length) || 0,
    }
  });
}

// ═══════════════════════════════════════════════════════════════════════════
// PARSE ALL FILES
// ═══════════════════════════════════════════════════════════════════════════

async function parseAllFiles(body: { files: FileInput[]; projectId?: string }) {
  const { files, projectId } = body;

  // Step 1: Classify all files
  const classifications = fileClassifier.classifyBatch(files);

  // Step 2: Route files to appropriate parsers
  const jsFiles: FileInput[] = [];
  const sqlFiles: FileInput[] = [];
  const cshtmlFiles: FileInput[] = [];
  const otherFiles: FileInput[] = [];

  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    const classification = classifications[i];

    switch (classification.fileType) {
      case 'javascript':
      case 'typescript':
        jsFiles.push(file);
        break;
      case 'sql_ddl':
      case 'sql_sp':
      case 'sql_view':
      case 'sql_function':
      case 'sql_mixed':
        sqlFiles.push(file);
        break;
      case 'razor_view':
        cshtmlFiles.push(file);
        break;
      default:
        otherFiles.push(file);
    }
  }

  // Step 3: Parse each type
  const jsResult = jsFiles.length > 0 ?
    await parseJavaScript({ files: jsFiles, projectId }) :
    { success: true, results: [], summary: { totalFiles: 0 } };

  const sqlContent = sqlFiles.map(f => f.content).join('\n\n');
  const sqlResult = sqlFiles.length > 0 ?
    await parseStoredProcedures({ sql: sqlContent, projectId }) :
    { success: true, results: [], summary: { totalProcedures: 0, totalTables: 0 } };

  const cshtmlResults = cshtmlFiles.length > 0 ?
    parseCSHTMLFiles(cshtmlFiles) : [];

  // Step 4: Combine results
  return NextResponse.json({
    success: true,
    classification: {
      total: files.length,
      javascript: jsFiles.length,
      sql: sqlFiles.length,
      cshtml: cshtmlFiles.length,
      other: otherFiles.length,
    },
    javascript: jsResult,
    sql: sqlResult,
    cshtml: {
      results: cshtmlResults,
      summary: {
        totalFiles: cshtmlFiles.length,
      }
    },
    summary: {
      totalFiles: files.length,
      totalAjaxCalls: (jsResult as any).summary?.totalAjaxCalls || 0,
      totalSPs: (sqlResult as any).summary?.totalProcedures || 0,
      totalTables: (sqlResult as any).summary?.totalTables || 0,
      totalViews: cshtmlFiles.length,
    }
  });
}

// ═══════════════════════════════════════════════════════════════════════════
// STORE INTELLIGENCE (Batch storage)
// ═══════════════════════════════════════════════════════════════════════════

async function storeIntelligence(body: {
  projectId: string;
  jsIntelligence?: unknown[];
  spIntelligence?: unknown[];
  classifications?: unknown[];
}) {
  const { projectId, jsIntelligence = [], spIntelligence = [], classifications = [] } = body;

  // Store classifications
  for (const c of classifications as any[]) {
    await db.fileClassificationCache.create({
      data: {
        projectId,
        fileName: c.fileName,
        filePath: c.filePath || c.fileName,
        fileType: c.fileType,
        language: c.language,
        framework: c.framework,
        confidence: c.confidence,
        indicators: JSON.stringify(c.indicators || []),
        fileSize: c.fileSize || 0,
        lineCount: c.lineCount || 0,
        estimatedComplexity: c.estimatedComplexity || 'low',
      }
    });
  }

  return NextResponse.json({
    success: true,
    stored: {
      classifications: classifications.length,
      jsIntelligence: jsIntelligence.length,
      spIntelligence: spIntelligence.length,
    }
  });
}

// ═══════════════════════════════════════════════════════════════════════════
// GETTERS
// ═══════════════════════════════════════════════════════════════════════════

async function getJSIntelligence(searchParams: URLSearchParams) {
  const projectId = searchParams.get('projectId');

  if (!projectId) {
    return NextResponse.json({ error: 'projectId is required' }, { status: 400 });
  }

  const intelligence = await db.jSIntelligenceCache.findMany({
    where: { projectId },
  });

  return NextResponse.json({
    success: true,
    intelligence: intelligence.map(i => ({
      ...i,
      ajaxCalls: JSON.parse(i.ajaxCalls || '[]'),
      eventHandlers: JSON.parse(i.eventHandlers || '[]'),
      dependencies: JSON.parse(i.dependencies || '[]'),
      formValidations: JSON.parse(i.formValidations || '[]'),
      discoveredEndpoints: JSON.parse(i.discoveredEndpoints || '[]'),
      jqueryPlugins: JSON.parse(i.jqueryPlugins || '[]'),
      bootstrapComponents: JSON.parse(i.bootstrapComponents || '[]'),
    })),
  });
}

async function getSPIntelligence(searchParams: URLSearchParams) {
  const projectId = searchParams.get('projectId');

  if (!projectId) {
    return NextResponse.json({ error: 'projectId is required' }, { status: 400 });
  }

  const intelligence = await db.storedProcedureCache.findMany({
    where: { projectId },
  });

  return NextResponse.json({
    success: true,
    intelligence: intelligence.map(i => ({
      ...i,
      tablesReferenced: JSON.parse(i.tablesReferenced || '[]'),
      implicitJoins: JSON.parse(i.implicitJoins || '[]'),
      discoveredTables: JSON.parse(i.discoveredTables || '[]'),
      businessRules: JSON.parse(i.businessRules || '[]'),
      writeOperations: JSON.parse(i.writeOperations || '[]'),
      readOperations: JSON.parse(i.readOperations || '[]'),
      parameters: JSON.parse(i.parameters || '[]'),
      apiInputSchema: JSON.parse(i.apiInputSchema || '{}'),
    })),
  });
}

async function getFileClassifications(searchParams: URLSearchParams) {
  const projectId = searchParams.get('projectId');

  if (!projectId) {
    return NextResponse.json({ error: 'projectId is required' }, { status: 400 });
  }

  const classifications = await db.fileClassificationCache.findMany({
    where: { projectId },
  });

  return NextResponse.json({
    success: true,
    classifications: classifications.map(c => ({
      ...c,
      indicators: JSON.parse(c.indicators || '[]'),
    })),
  });
}
