'use client'

import { useState } from 'react'
import { ScrollArea } from '@/components/ui/scroll-area'
import { ThemeProvider, useTheme } from '@/hooks/useTheme'
import { SchemaProvider, useSchema } from '@/hooks/useSchema'
import { ColorSchemeSelector } from '@/components/ColorSchemeSelector'
import { WorkspacePanel } from '@/components/WorkspacePanel'
import { 
  LayoutDashboard, 
  Upload, 
  Puzzle, 
  GitBranch, 
  Settings,
  Brain,
  Database,
  FileCode,
  Shield,
  BarChart3,
  Zap,
  AlertTriangle,
  ArrowRightLeft,
  ClipboardList,
  Sparkles
} from 'lucide-react'
import { DashboardTab } from '@/components/tabs/DashboardTab'
import { UploadTab } from '@/components/tabs/UploadTab'
import { ModulesTab } from '@/components/tabs/ModulesTab'
import { PipelineTab } from '@/components/tabs/PipelineTab'
import { SettingsTab } from '@/components/tabs/SettingsTab'
import { FKResolutionTab } from '@/components/tabs/FKResolutionTab'
import { IntelligenceTab } from '@/components/tabs/IntelligenceTab'
import { MultiTenantTab } from '@/components/tabs/MultiTenantTab'
import { LegacyMigrationTab } from '@/components/tabs/LegacyMigrationTab'
import { ProjectIntelligenceTab } from '@/components/tabs/ProjectIntelligenceTab'
import { UniversalUploadTab } from '@/components/tabs/UniversalUploadTab'

function AppContent() {
  const [activeTab, setActiveTab] = useState('dashboard')
  const [workspaceOpen, setWorkspaceOpen] = useState(true)
  const { colors, colorScheme } = useTheme()
  const { totalTables, fkResolvedPercent, modulesLinked } = useSchema()

  // Navigation handler for dashboard tiles
  const handleNavigate = (tab: string) => {
    setActiveTab(tab)
  }

  return (
    <div 
      className="min-h-screen"
      style={{ 
        background: `linear-gradient(to bottom right, ${colors.bg}, ${colors.bgSecondary}, ${colors.bg})` 
      }}
    >
      {/* Header */}
      <header 
        className="border-b backdrop-blur-sm sticky top-0 z-50"
        style={{ 
          borderColor: `color-mix(in srgb, ${colors.border} 50%, transparent)`,
          backgroundColor: `color-mix(in srgb, ${colors.bg} 80%, transparent)`,
        }}
      >
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="relative w-10 h-10">
              <div 
                className="w-full h-full rounded-lg flex items-center justify-center"
                style={{ 
                  background: `linear-gradient(135deg, ${colors.primary}, ${colors.accent})` 
                }}
              >
                <Database className="w-6 h-6 text-white" />
              </div>
            </div>
            <div>
              <h1 className="text-xl font-bold" style={{ color: colors.text }}>
                AI Enterprise Architect
              </h1>
              <p className="text-xs" style={{ color: colors.textMuted }}>
                Multi-Agent Schema Intelligence Platform
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div 
              className="flex items-center gap-2 px-3 py-1.5 border rounded-full"
              style={{ 
                backgroundColor: `color-mix(in srgb, ${colors.success} 10%, transparent)`,
                borderColor: `color-mix(in srgb, ${colors.success} 20%, transparent)`,
              }}
            >
              <div 
                className="w-2 h-2 rounded-full animate-pulse" 
                style={{ backgroundColor: colors.success }} 
              />
              <span 
                className="text-xs font-medium"
                style={{ color: colors.success }}
              >
                System Ready
              </span>
            </div>
            <ColorSchemeSelector />
            <div 
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg"
              style={{ backgroundColor: `color-mix(in srgb, ${colors.primary} 10%, transparent)` }}
            >
              <Brain className="w-4 h-4" style={{ color: colors.primary }} />
              <span className="text-xs" style={{ color: colors.textMuted }}>Offline Mode</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex">
        {/* Sidebar */}
        <aside 
          className="w-64 border-r min-h-[calc(100vh-73px)] sticky top-[73px]"
          style={{ 
            borderColor: `color-mix(in srgb, ${colors.border} 50%, transparent)`,
            backgroundColor: `color-mix(in srgb, ${colors.bgSecondary} 30%, transparent)`,
          }}
        >
          <nav className="p-4 space-y-2">
            {[
              { id: 'dashboard', icon: LayoutDashboard, label: 'Dashboard' },
              { id: 'smart-upload', icon: Sparkles, label: 'Universal Upload', badge: 'AI', badgeColor: colors.primary },
              { id: 'upload', icon: Upload, label: 'Upload & Parse' },
              { id: 'modules', icon: Puzzle, label: 'Module Registry', badge: '35', badgeColor: colors.accent },
              { id: 'fk-resolution', icon: AlertTriangle, label: 'FK Resolution', badge: 'Queue', badgeColor: colors.warning },
              { id: 'intelligence', icon: Brain, label: 'Intelligence', badge: 'Step 4', badgeColor: colors.primary },
              { id: 'legacy-migration', icon: ArrowRightLeft, label: 'Legacy Migration', badge: 'Step 9', badgeColor: colors.success },
              { id: 'project-intel', icon: ClipboardList, label: 'Project Intelligence', badge: 'Phase 5', badgeColor: colors.primary },
              { id: 'pipeline', icon: GitBranch, label: 'Pipeline' },
              { id: 'multi-tenant', icon: Shield, label: 'Multi-Tenant', badge: 'Step 5', badgeColor: colors.warning },
              { id: 'settings', icon: Settings, label: 'Settings' },
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all"
                style={{
                  backgroundColor: activeTab === item.id 
                    ? `color-mix(in srgb, ${colors.primary} 15%, transparent)` 
                    : 'transparent',
                  color: activeTab === item.id 
                    ? colors.primaryLight 
                    : colors.textMuted,
                  border: activeTab === item.id 
                    ? `1px solid color-mix(in srgb, ${colors.primary} 30%, transparent)` 
                    : '1px solid transparent',
                }}
              >
                <item.icon className="w-5 h-5" />
                <span className="font-medium">{item.label}</span>
                {item.badge && (
                  <span 
                    className="ml-auto text-xs px-2 py-0.5 rounded-full"
                    style={{ 
                      backgroundColor: `color-mix(in srgb, ${item.badgeColor} 20%, transparent)`,
                      color: item.badgeColor,
                    }}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            ))}
          </nav>

          {/* Agent Status */}
          <div 
            className="p-4 border-t"
            style={{ borderColor: `color-mix(in srgb, ${colors.border} 50%, transparent)` }}
          >
            <h3 
              className="text-xs font-semibold uppercase tracking-wider mb-3"
              style={{ color: colors.textMuted }}
            >
              Agent Layers
            </h3>
            <div className="space-y-2">
              {[
                { name: 'Schema', icon: Database, count: 5, color: colors.accent },
                { name: 'Intelligence', icon: Brain, count: 5, color: colors.primary },
                { name: 'Module', icon: Puzzle, count: 5, color: colors.success },
                { name: 'Requirements', icon: FileCode, count: 5, color: colors.warning },
                { name: 'Generation', icon: Zap, count: 6, color: '#eab308' },
                { name: 'Migration', icon: GitBranch, count: 4, color: '#ec4899' },
                { name: 'Management', icon: BarChart3, count: 5, color: '#06b6d4' },
              ].map((layer) => (
                <div 
                  key={layer.name} 
                  className="flex items-center justify-between px-3 py-2 rounded-lg"
                  style={{ backgroundColor: `color-mix(in srgb, ${colors.card} 50%, transparent)` }}
                >
                  <div className="flex items-center gap-2">
                    <layer.icon className="w-4 h-4" style={{ color: layer.color }} />
                    <span className="text-sm" style={{ color: colors.text }}>{layer.name}</span>
                  </div>
                  <span className="text-xs" style={{ color: colors.textMuted }}>{layer.count}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Stats */}
          <div 
            className="p-4 border-t"
            style={{ borderColor: `color-mix(in srgb, ${colors.border} 50%, transparent)` }}
          >
            <h3 
              className="text-xs font-semibold uppercase tracking-wider mb-3"
              style={{ color: colors.textMuted }}
            >
              Quick Stats
            </h3>
            <div className="space-y-2 text-sm">
              {[
                { label: 'Tables Parsed', value: totalTables.toString() },
                { label: 'FK Resolved', value: `${fkResolvedPercent}%` },
                { label: 'Modules Covered', value: `${modulesLinked}/35` },
              ].map((stat) => (
                <div key={stat.label} className="flex justify-between" style={{ color: colors.textMuted }}>
                  <span>{stat.label}</span>
                  <span style={{ color: colors.text }} className="font-medium">{stat.value}</span>
                </div>
              ))}
            </div>
          </div>
        </aside>

        {/* Main Content Area */}
        <main className="flex-1 min-h-[calc(100vh-73px)]">
          <ScrollArea className="h-[calc(100vh-73px)]">
            <div className="p-6">
              {activeTab === 'dashboard' && <DashboardTab onNavigate={handleNavigate} />}
              {activeTab === 'smart-upload' && <UniversalUploadTab onNavigate={handleNavigate} />}
              {activeTab === 'upload' && <UploadTab onNavigate={handleNavigate} />}
              {activeTab === 'fk-resolution' && <FKResolutionTab />}
              {activeTab === 'modules' && <ModulesTab />}
              {activeTab === 'intelligence' && <IntelligenceTab onNavigate={handleNavigate} />}
              {activeTab === 'legacy-migration' && <LegacyMigrationTab onNavigate={handleNavigate} />}
              {activeTab === 'project-intel' && <ProjectIntelligenceTab />}
              {activeTab === 'multi-tenant' && <MultiTenantTab onNavigate={handleNavigate} />}
              {activeTab === 'pipeline' && <PipelineTab />}
              {activeTab === 'settings' && <SettingsTab />}
            </div>
          </ScrollArea>
        </main>

        {/* Workspace Panel - Right Side */}
        <WorkspacePanel isOpen={workspaceOpen} onToggle={() => setWorkspaceOpen(!workspaceOpen)} />
      </div>
    </div>
  )
}

export default function Home() {
  return (
    <ThemeProvider>
      <SchemaProvider>
        <AppContent />
      </SchemaProvider>
    </ThemeProvider>
  )
}
