// =============================================================================
// CSHTML Parser - ASP.NET Razor View to React Blueprint Converter
// =============================================================================
// Converts existing ASP.NET Razor views to React blueprints
// =============================================================================

/**
 * Parsed CSHTML View Model
 */
export interface CSHTMLModel {
  name: string;
  namespace?: string;
  properties: ModelProperty[];
  linkedTable?: string;
}

/**
 * Model Property
 */
export interface ModelProperty {
  name: string;
  type: string;
  isRequired: boolean;
  isNullable: boolean;
  validationAttributes: string[];
}

/**
 * Parsed Form Field
 */
export interface ParsedFormField {
  name: string;
  label: string;
  inputType: ReactInputType;
  aspFor: string;
  isRequired: boolean;
  isReadOnly: boolean;
  placeholder?: string;
  defaultValue?: string;
  cssClass?: string;
  layout: FieldLayout;
  validation: FieldValidation[];
  permission?: PermissionRequirement;
  dropdownSource?: string;
  colSpan: number;
}

/**
 * React Input Type Mapping
 */
export type ReactInputType =
  | 'text_input'
  | 'email_input'
  | 'password_input'
  | 'number_input'
  | 'currency_input'
  | 'date_picker'
  | 'time_picker'
  | 'datetime_picker'
  | 'textarea'
  | 'checkbox'
  | 'toggle'
  | 'dropdown'
  | 'multi_select'
  | 'file_upload'
  | 'hidden'
  | 'radio_group';

/**
 * Field Layout
 */
export interface FieldLayout {
  row: number;
  column: number;
  width: 'full' | 'half' | 'third' | 'quarter';
  cssClass: string;
}

/**
 * Field Validation
 */
export interface FieldValidation {
  type: 'required' | 'email' | 'min_length' | 'max_length' | 'pattern' | 'min_value' | 'max_value';
  value?: string | number;
  message?: string;
}

/**
 * Permission Requirement
 */
export interface PermissionRequirement {
  type: 'role' | 'claim' | 'policy';
  value: string;
  action: 'show' | 'hide' | 'disable';
}

/**
 * Parsed List/Table View
 */
export interface ParsedListView {
  columns: ListColumn[];
  dataSource: string;
  actions: ListAction[];
  hasPagination: boolean;
  hasSearch: boolean;
  hasSorting: boolean;
  emptyMessage?: string;
}

/**
 * List Column
 */
export interface ListColumn {
  fieldName: string;
  header: string;
  isSortable: boolean;
  isLink: boolean;
  linkTarget?: string;
  format?: string;
  cssClass?: string;
}

/**
 * List Action
 */
export interface ListAction {
  type: 'create' | 'edit' | 'delete' | 'details' | 'custom';
  label: string;
  controller?: string;
  action?: string;
  routeId?: string;
  cssClass?: string;
  icon?: string;
  permission?: PermissionRequirement;
}

/**
 * Parsed CSHTML View
 */
export interface ParsedCSHTMLView {
  viewName: string;
  viewType: ViewType;
  model?: CSHTMLModel;
  title?: string;
  layout?: string;
  fields: ParsedFormField[];
  list?: ParsedListView;
  sections: ViewSection[];
  scripts: string[];
  styles: string[];
  permissions: PermissionRequirement[];
  rawContent: string;
}

/**
 * View Type
 */
export type ViewType = 'form' | 'list' | 'details' | 'dashboard' | 'mixed' | 'unknown';

/**
 * View Section
 */
export interface ViewSection {
  id: string;
  title: string;
  fields: string[];
  isCollapsible: boolean;
  permission?: PermissionRequirement;
}

/**
 * React Component Blueprint (Final Output)
 */
export interface ReactBlueprint {
  componentName: string;
  viewType: ViewType;
  tableName?: string;
  fields: ReactFieldBlueprint[];
  list?: ReactListBlueprint;
  imports: string[];
  hooks: string[];
  permissions: PermissionRequirement[];
  layout: 'single_column' | 'two_column' | 'three_column' | 'tabs';
  suggestedPath: string;
}

/**
 * React Field Blueprint
 */
export interface ReactFieldBlueprint {
  name: string;
  label: string;
  type: ReactInputType;
  required: boolean;
  readOnly: boolean;
  placeholder?: string;
  defaultValue?: unknown;
  validation: FieldValidation[];
  colSpan: number;
  permission?: PermissionRequirement;
  options?: { label: string; value: string }[];
}

/**
 * React List Blueprint
 */
export interface ReactListBlueprint {
  columns: { field: string; header: string; sortable: boolean }[];
  actions: { type: string; label: string; path: string }[];
  hasPagination: boolean;
  hasSearch: boolean;
  hasSorting: boolean;
}

/**
 * CSHTML Parser Engine
 */
export class CSHTMLParser {
  private content: string;
  private currentLine: number = 0;

  constructor(content: string) {
    this.content = content;
  }

  /**
   * Parse CSHTML content
   */
  parse(): ParsedCSHTMLView {
    const viewName = this.extractViewName();
    const viewType = this.determineViewType();
    const model = this.extractModel();
    const title = this.extractTitle();
    const layout = this.extractLayout();
    const fields = this.extractFormFields();
    const list = this.extractListView();
    const sections = this.extractSections();
    const scripts = this.extractScripts();
    const styles = this.extractStyles();
    const permissions = this.extractPermissions();

    return {
      viewName,
      viewType,
      model,
      title,
      layout,
      fields,
      list,
      sections,
      scripts,
      styles,
      permissions,
      rawContent: this.content,
    };
  }

  /**
   * Extract view name from file path or content
   */
  private extractViewName(): string {
    const titleMatch = this.content.match(/ViewBag\.Title\s*=\s*"([^"]+)"/i);
    if (titleMatch) return titleMatch[1];

    const modelMatch = this.content.match(/@model\s+(\w+)/);
    if (modelMatch) return `${modelMatch[1]}View`;

    return 'UnknownView';
  }

  /**
   * Determine view type from content
   */
  private determineViewType(): ViewType {
    const hasForm = /<form|@using\s*\(\s*Html\.BeginForm/i.test(this.content);
    const hasTable = /<table[^>]*>[\s\S]*?@foreach/i.test(this.content);
    const hasList = /@foreach|@for\s*\(|@while\s*\(/i.test(this.content);
    const hasDetails = /<dl\s+class="dl-horizontal"|DisplayFor|DisplayNameFor/i.test(this.content);
    const hasDashboard = /chart|dashboard|statistics|metric|kpi/i.test(this.content);

    if (hasDashboard) return 'dashboard';
    if (hasForm && hasList) return 'mixed';
    if (hasTable || (hasList && !hasForm)) return 'list';
    if (hasDetails && !hasForm) return 'details';
    if (hasForm) return 'form';

    return 'unknown';
  }

  /**
   * Extract model declaration
   */
  private extractModel(): CSHTMLModel | undefined {
    const modelMatch = this.content.match(/@model\s+([\w.]+)/);
    if (!modelMatch) return undefined;

    const fullName = modelMatch[1];
    const parts = fullName.split('.');
    const name = parts[parts.length - 1];

    // Try to infer linked table from model name
    const linkedTable = this.inferTableFromModel(name);

    return {
      name,
      namespace: parts.length > 1 ? parts.slice(0, -1).join('.') : undefined,
      properties: [],
      linkedTable,
    };
  }

  /**
   * Infer table name from model name
   */
  private inferTableFromModel(modelName: string): string | undefined {
    // Common patterns: PatientViewModel → Patients, UserEditModel → Users
    const cleanName = modelName
      .replace(/ViewModel$/, '')
      .replace(/EditModel$/, '')
      .replace(/CreateModel$/, '')
      .replace(/DetailModel$/, '')
      .replace(/ListModel$/, '')
      .replace(/Model$/, '');

    // Pluralize simple names
    if (cleanName.endsWith('s')) return cleanName;
    if (cleanName.endsWith('y')) return cleanName.slice(0, -1) + 'ies';
    return cleanName + 's';
  }

  /**
   * Extract page title
   */
  private extractTitle(): string | undefined {
    const titleMatch = this.content.match(/ViewBag\.Title\s*=\s*"([^"]+)"/i);
    return titleMatch ? titleMatch[1] : undefined;
  }

  /**
   * Extract layout reference
   */
  private extractLayout(): string | undefined {
    const layoutMatch = this.content.match(/Layout\s*=\s*"([^"]+)"/i);
    return layoutMatch ? layoutMatch[1] : undefined;
  }

  /**
   * Extract form fields from CSHTML
   */
  private extractFormFields(): ParsedFormField[] {
    const fields: ParsedFormField[] = [];

    // Pattern 1: <input asp-for="Field" />
    const inputRegex = /<input[^>]*asp-for="([^"]+)"[^>]*\/?>/gi;
    let match;

    while ((match = inputRegex.exec(this.content)) !== null) {
      fields.push(this.parseInputTag(match[0], match[1]));
    }

    // Pattern 2: <textarea asp-for="Field">
    const textareaRegex = /<textarea[^>]*asp-for="([^"]+)"[^>]*>/gi;
    while ((match = textareaRegex.exec(this.content)) !== null) {
      fields.push(this.parseTextareaTag(match[0], match[1]));
    }

    // Pattern 3: <select asp-for="Field">
    const selectRegex = /<select[^>]*asp-for="([^"]+)"[^>]*>/gi;
    while ((match = selectRegex.exec(this.content)) !== null) {
      fields.push(this.parseSelectTag(match[0], match[1]));
    }

    // Pattern 4: @Html.EditorFor(m => m.Field)
    const editorForRegex = /@Html\.EditorFor\s*\(\s*\w+\s*=>\s*\w+\.(\w+)/gi;
    while ((match = editorForRegex.exec(this.content)) !== null) {
      fields.push(this.parseEditorFor(match[0], match[1]));
    }

    // Pattern 5: @Html.TextBoxFor(m => m.Field)
    const textBoxForRegex = /@Html\.TextBoxFor\s*\(\s*\w+\s*=>\s*\w+\.(\w+)/gi;
    while ((match = textBoxForRegex.exec(this.content)) !== null) {
      fields.push(this.parseTextBoxFor(match[0], match[1]));
    }

    // Pattern 6: @Html.DropDownListFor(m => m.Field, ...)
    const dropDownRegex = /@Html\.DropDownListFor\s*\(\s*\w+\s*=>\s*\w+\.(\w+)/gi;
    while ((match = dropDownRegex.exec(this.content)) !== null) {
      fields.push(this.parseDropDownFor(match[0], match[1]));
    }

    // Pattern 7: @Html.CheckBoxFor(m => m.Field)
    const checkBoxRegex = /@Html\.CheckBoxFor\s*\(\s*\w+\s*=>\s*\w+\.(\w+)/gi;
    while ((match = checkBoxRegex.exec(this.content)) !== null) {
      fields.push(this.parseCheckBoxFor(match[0], match[1]));
    }

    // Pattern 8: @Html.PasswordFor(m => m.Field)
    const passwordRegex = /@Html\.PasswordFor\s*\(\s*\w+\s*=>\s*\w+\.(\w+)/gi;
    while ((match = passwordRegex.exec(this.content)) !== null) {
      fields.push(this.parsePasswordFor(match[0], match[1]));
    }

    // Deduplicate by name
    const seen = new Set<string>();
    return fields.filter(field => {
      if (seen.has(field.name)) return false;
      seen.add(field.name);
      return true;
    });
  }

  /**
   * Parse input tag
   */
  private parseInputTag(tag: string, aspFor: string): ParsedFormField {
    const inputType = this.mapInputType(tag);
    const isRequired = /required|data-val-required/i.test(tag);
    const isReadOnly = /readonly|disabled/i.test(tag);
    const cssClass = this.extractClass(tag);
    const placeholder = this.extractAttribute(tag, 'placeholder');
    const defaultValue = this.extractAttribute(tag, 'value');
    const permission = this.extractPermission(tag);

    return {
      name: aspFor,
      label: this.formatLabel(aspFor),
      inputType,
      aspFor,
      isRequired,
      isReadOnly,
      placeholder,
      defaultValue,
      cssClass,
      layout: this.extractLayout(tag, cssClass),
      validation: this.extractValidations(tag),
      permission,
      colSpan: this.calculateColSpan(cssClass),
    };
  }

  /**
   * Parse textarea tag
   */
  private parseTextareaTag(tag: string, aspFor: string): ParsedFormField {
    const isRequired = /required|data-val-required/i.test(tag);
    const cssClass = this.extractClass(tag);
    const rows = this.extractAttribute(tag, 'rows');

    return {
      name: aspFor,
      label: this.formatLabel(aspFor),
      inputType: 'textarea',
      aspFor,
      isRequired,
      isReadOnly: /readonly|disabled/i.test(tag),
      cssClass,
      layout: this.extractLayout(tag, cssClass),
      validation: this.extractValidations(tag),
      colSpan: this.calculateColSpan(cssClass),
    };
  }

  /**
   * Parse select tag
   */
  private parseSelectTag(tag: string, aspFor: string): ParsedFormField {
    const isRequired = /required|data-val-required/i.test(tag);
    const cssClass = this.extractClass(tag);

    // Extract asp-items source
    const aspItemsMatch = tag.match(/asp-items="([^"]+)"/);
    const dropdownSource = aspItemsMatch ? aspItemsMatch[1] : undefined;

    return {
      name: aspFor,
      label: this.formatLabel(aspFor),
      inputType: 'dropdown',
      aspFor,
      isRequired,
      isReadOnly: /readonly|disabled/i.test(tag),
      cssClass,
      dropdownSource,
      layout: this.extractLayout(tag, cssClass),
      validation: this.extractValidations(tag),
      colSpan: this.calculateColSpan(cssClass),
    };
  }

  /**
   * Parse EditorFor helper
   */
  private parseEditorFor(tag: string, fieldName: string): ParsedFormField {
    return {
      name: fieldName,
      label: this.formatLabel(fieldName),
      inputType: 'text_input', // Default, could be enhanced
      aspFor: fieldName,
      isRequired: false,
      isReadOnly: false,
      layout: { row: 0, column: 0, width: 'full', cssClass: '' },
      validation: [],
      colSpan: 12,
    };
  }

  /**
   * Parse TextBoxFor helper
   */
  private parseTextBoxFor(tag: string, fieldName: string): ParsedFormField {
    const inputType = /type="email"/i.test(tag) ? 'email_input' :
                      /type="number"/i.test(tag) ? 'number_input' :
                      /type="date"/i.test(tag) ? 'date_picker' :
                      'text_input';

    return {
      name: fieldName,
      label: this.formatLabel(fieldName),
      inputType,
      aspFor: fieldName,
      isRequired: /required/i.test(tag),
      isReadOnly: false,
      layout: { row: 0, column: 0, width: 'full', cssClass: '' },
      validation: [],
      colSpan: 12,
    };
  }

  /**
   * Parse DropDownListFor helper
   */
  private parseDropDownFor(tag: string, fieldName: string): ParsedFormField {
    const sourceMatch = tag.match(/(?:SelectList|ViewBag)\.(\w+)/);
    return {
      name: fieldName,
      label: this.formatLabel(fieldName),
      inputType: 'dropdown',
      aspFor: fieldName,
      isRequired: false,
      isReadOnly: false,
      dropdownSource: sourceMatch ? sourceMatch[1] : undefined,
      layout: { row: 0, column: 0, width: 'full', cssClass: '' },
      validation: [],
      colSpan: 12,
    };
  }

  /**
   * Parse CheckBoxFor helper
   */
  private parseCheckBoxFor(tag: string, fieldName: string): ParsedFormField {
    return {
      name: fieldName,
      label: this.formatLabel(fieldName),
      inputType: 'checkbox',
      aspFor: fieldName,
      isRequired: false,
      isReadOnly: false,
      layout: { row: 0, column: 0, width: 'full', cssClass: '' },
      validation: [],
      colSpan: 12,
    };
  }

  /**
   * Parse PasswordFor helper
   */
  private parsePasswordFor(tag: string, fieldName: string): ParsedFormField {
    return {
      name: fieldName,
      label: this.formatLabel(fieldName),
      inputType: 'password_input',
      aspFor: fieldName,
      isRequired: false,
      isReadOnly: false,
      layout: { row: 0, column: 0, width: 'full', cssClass: '' },
      validation: [],
      colSpan: 12,
    };
  }

  /**
   * Map HTML input type to React component
   */
  private mapInputType(tag: string): ReactInputType {
    const typeMatch = tag.match(/type="([^"]+)"/i);
    const type = typeMatch ? typeMatch[1].toLowerCase() : 'text';

    const typeMap: Record<string, ReactInputType> = {
      'text': 'text_input',
      'email': 'email_input',
      'password': 'password_input',
      'number': 'number_input',
      'tel': 'text_input',
      'url': 'text_input',
      'date': 'date_picker',
      'time': 'time_picker',
      'datetime-local': 'datetime_picker',
      'checkbox': 'checkbox',
      'radio': 'radio_group',
      'file': 'file_upload',
      'hidden': 'hidden',
    };

    return typeMap[type] || 'text_input';
  }

  /**
   * Extract CSS class from tag
   */
  private extractClass(tag: string): string {
    const classMatch = tag.match(/class="([^"]+)"/i);
    return classMatch ? classMatch[1] : '';
  }

  /**
   * Extract attribute value from tag
   */
  private extractAttribute(tag: string, attr: string): string | undefined {
    const attrMatch = tag.match(new RegExp(`${attr}="([^"]+)"`, 'i'));
    return attrMatch ? attrMatch[1] : undefined;
  }

  /**
   * Extract layout from CSS class
   */
  private extractLayout(tag: string, cssClass: string | undefined): FieldLayout {
    // Handle undefined or empty cssClass
    const safeCssClass = cssClass || '';
    
    // Parse Bootstrap grid classes
    const colMatch = safeCssClass.match(/col-(?:md|lg|sm)-(\d+)/);
    const colWidth = colMatch ? parseInt(colMatch[1]) : 12;

    return {
      row: 0, // Would need line number tracking
      column: 0,
      width: colWidth <= 3 ? 'quarter' :
             colWidth <= 4 ? 'third' :
             colWidth <= 6 ? 'half' : 'full',
      cssClass: safeCssClass,
    };
  }

  /**
   * Calculate column span from CSS class
   */
  private calculateColSpan(cssClass: string | undefined): number {
    const safeCssClass = cssClass || '';
    const colMatch = safeCssClass.match(/col-(?:md|lg|sm)-(\d+)/);
    return colMatch ? parseInt(colMatch[1]) : 12;
  }

  /**
   * Extract validations from tag
   */
  private extractValidations(tag: string): FieldValidation[] {
    const validations: FieldValidation[] = [];

    if (/required|data-val-required/i.test(tag)) {
      const msgMatch = tag.match(/data-val-required="([^"]+)"/);
      validations.push({
        type: 'required',
        message: msgMatch ? msgMatch[1] : 'This field is required',
      });
    }

    if (/data-val-email/i.test(tag)) {
      validations.push({ type: 'email' });
    }

    const minLengthMatch = tag.match(/data-val-length-min="(\d+)"/);
    if (minLengthMatch) {
      validations.push({ type: 'min_length', value: parseInt(minLengthMatch[1]) });
    }

    const maxLengthMatch = tag.match(/data-val-length-max="(\d+)"/);
    if (maxLengthMatch) {
      validations.push({ type: 'max_length', value: parseInt(maxLengthMatch[1]) });
    }

    const patternMatch = tag.match(/data-val-regex-pattern="([^"]+)"/);
    if (patternMatch) {
      validations.push({ type: 'pattern', value: patternMatch[1] });
    }

    return validations;
  }

  /**
   * Extract permission from tag
   */
  private extractPermission(tag: string): PermissionRequirement | undefined {
    // Check for role-based visibility
    const surroundingContext = this.getSurroundingContext(tag);

    const roleMatch = surroundingContext.match(/User\.IsInRole\s*\(\s*"([^"]+)"\)/);
    if (roleMatch) {
      return {
        type: 'role',
        value: roleMatch[1],
        action: 'show',
      };
    }

    return undefined;
  }

  /**
   * Get surrounding context for a tag
   */
  private getSurroundingContext(tag: string): string {
    const index = this.content.indexOf(tag);
    if (index === -1) return '';

    const start = Math.max(0, index - 200);
    const end = Math.min(this.content.length, index + tag.length + 200);

    return this.content.substring(start, end);
  }

  /**
   * Extract list view configuration
   */
  private extractListView(): ParsedListView | undefined {
    if (!/<table[^>]*>[\s\S]*?@foreach/i.test(this.content)) return undefined;

    const columns = this.extractListColumns();
    const dataSource = this.extractDataSource();
    const actions = this.extractListActions();

    return {
      columns,
      dataSource,
      actions,
      hasPagination: /PagedList|pagination|page-size/i.test(this.content),
      hasSearch: /search|filter|SearchString/i.test(this.content),
      hasSorting: /sort|order-by|OrderBy/i.test(this.content),
      emptyMessage: this.extractEmptyMessage(),
    };
  }

  /**
   * Extract list columns from table
   */
  private extractListColumns(): ListColumn[] {
    const columns: ListColumn[] = [];

    // Extract <th> headers
    const thRegex = /<th[^>]*>([^<]+)<\/th>/gi;
    let match;

    while ((match = thRegex.exec(this.content)) !== null) {
      const header = match[1].trim();
      const isSortable = /data-sort|asp-sort/i.test(match[0]);

      columns.push({
        fieldName: this.inferFieldName(header),
        header,
        isSortable,
        isLink: false,
      });
    }

    // Extract <td> with DisplayFor
    const tdRegex = /<td[^>]*>([\s\S]*?)<\/td>/gi;
    let colIndex = 0;

    while ((match = tdRegex.exec(this.content)) !== null) {
      const cell = match[1];
      const displayMatch = cell.match(/DisplayFor\s*\(\s*\w+\s*=>\s*\w+\.(\w+)/);

      if (displayMatch && columns[colIndex]) {
        columns[colIndex].fieldName = displayMatch[1];
      }

      const linkMatch = cell.match(/<a[^>]*href/i);
      if (linkMatch && columns[colIndex]) {
        columns[colIndex].isLink = true;
      }

      colIndex = (colIndex + 1) % columns.length;
    }

    return columns;
  }

  /**
   * Infer field name from header
   */
  private inferFieldName(header: string): string {
    return header
      .replace(/\s+/g, '')
      .replace(/([A-Z])/g, '_$1')
      .toLowerCase()
      .replace(/^_/, '');
  }

  /**
   * Extract data source from foreach
   */
  private extractDataSource(): string {
    const foreachMatch = this.content.match(/@foreach\s*\(\s*var\s+(\w+)\s+in\s+Model\.?(\w*)/i);
    if (foreachMatch) {
      return foreachMatch[2] || 'Items';
    }

    const modelMatch = this.content.match(/@foreach\s*\(\s*var\s+\w+\s+in\s+Model/i);
    if (modelMatch) return 'Model';

    return 'Items';
  }

  /**
   * Extract list actions
   */
  private extractListActions(): ListAction[] {
    const actions: ListAction[] = [];

    // Look for action links
    const actionLinkRegex = /@Html\.ActionLink\s*\(\s*"([^"]+)"\s*,\s*"(\w+)"\s*,\s*"(\w+)"/gi;
    let match;

    while ((match = actionLinkRegex.exec(this.content)) !== null) {
      const [, label, action, controller] = match;

      actions.push({
        type: this.mapActionToType(action),
        label,
        controller,
        action,
        cssClass: this.extractClass(match[0]),
      });
    }

    // Look for anchor tags with asp-action
    const anchorRegex = /<a[^>]*asp-action="(\w+)"[^>]*asp-controller="(\w+)"[^>]*>([^<]+)<\/a>/gi;
    while ((match = anchorRegex.exec(this.content)) !== null) {
      const [, action, controller, label] = match;

      actions.push({
        type: this.mapActionToType(action),
        label: label.trim(),
        controller,
        action,
      });
    }

    return actions;
  }

  /**
   * Map action name to type
   */
  private mapActionToType(action: string): ListAction['type'] {
    const actionMap: Record<string, ListAction['type']> = {
      'Create': 'create',
      'Edit': 'edit',
      'Delete': 'delete',
      'Details': 'details',
      'Index': 'list',
    };

    return actionMap[action] || 'custom';
  }

  /**
   * Extract empty message
   */
  private extractEmptyMessage(): string | undefined {
    const emptyMatch = this.content.match(/No\s+(?:records|items|data)\s+found|empty[^.]*\./i);
    return emptyMatch ? emptyMatch[0] : undefined;
  }

  /**
   * Extract sections from CSHTML
   */
  private extractSections(): ViewSection[] {
    const sections: ViewSection[] = [];

    // Look for fieldset or div with role="group"
    const sectionRegex = /<(?:fieldset|div)[^>]*>([\s\S]*?)<\/(?:fieldset|div)>/gi;
    let match;
    let sectionId = 1;

    while ((match = sectionRegex.exec(this.content)) !== null) {
      const sectionContent = match[1];

      // Check if it has a legend or title
      const titleMatch = sectionContent.match(/<legend[^>]*>([^<]+)<\/legend>/);

      if (titleMatch) {
        sections.push({
          id: `section-${sectionId++}`,
          title: titleMatch[1],
          fields: this.extractFieldNames(sectionContent),
          isCollapsible: /collapse|accordion/i.test(match[0]),
        });
      }
    }

    return sections;
  }

  /**
   * Extract field names from content
   */
  private extractFieldNames(content: string): string[] {
    const names: string[] = [];
    const aspForRegex = /asp-for="([^"]+)"/gi;
    let match;

    while ((match = aspForRegex.exec(content)) !== null) {
      names.push(match[1]);
    }

    return [...new Set(names)];
  }

  /**
   * Extract scripts
   */
  private extractScripts(): string[] {
    const scripts: string[] = [];
    const scriptRegex = /<script[^>]*>([\s\S]*?)<\/script>/gi;
    let match;

    while ((match = scriptRegex.exec(this.content)) !== null) {
      scripts.push(match[1].trim());
    }

    return scripts;
  }

  /**
   * Extract styles
   */
  private extractStyles(): string[] {
    const styles: string[] = [];
    const styleRegex = /<style[^>]*>([\s\S]*?)<\/style>/gi;
    let match;

    while ((match = styleRegex.exec(this.content)) !== null) {
      styles.push(match[1].trim());
    }

    return styles;
  }

  /**
   * Extract permissions from content
   */
  private extractPermissions(): PermissionRequirement[] {
    const permissions: PermissionRequirement[] = [];

    // Look for role checks
    const roleRegex = /User\.IsInRole\s*\(\s*"([^"]+)"\)/gi;
    let match;

    while ((match = roleRegex.exec(this.content)) !== null) {
      permissions.push({
        type: 'role',
        value: match[1],
        action: 'show',
      });
    }

    // Look for authorization attributes
    const authRegex = /\[Authorize\s*\(\s*Roles\s*=\s*"([^"]+)"\s*\)\]/gi;
    while ((match = authRegex.exec(this.content)) !== null) {
      const roles = match[1].split(',').map(r => r.trim());
      roles.forEach(role => {
        permissions.push({
          type: 'role',
          value: role,
          action: 'show',
        });
      });
    }

    return [...new Map(permissions.map(p => [p.value, p])).values()];
  }

  /**
   * Format label from field name
   */
  private formatLabel(fieldName: string): string {
    return fieldName
      .replace(/([A-Z])/g, ' $1')
      .replace(/_/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()
      .split(' ')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join(' ');
  }

  /**
   * Generate React Blueprint
   */
  generateReactBlueprint(parsed: ParsedCSHTMLView): ReactBlueprint {
    const componentName = this.toPascalCase(parsed.viewName);
    const layout = this.determineLayout(parsed);

    const fields: ReactFieldBlueprint[] = parsed.fields.map(f => ({
      name: f.name,
      label: f.label,
      type: f.inputType,
      required: f.isRequired,
      readOnly: f.isReadOnly,
      placeholder: f.placeholder,
      validation: f.validation,
      colSpan: f.colSpan,
      permission: f.permission,
    }));

    const list: ReactListBlueprint | undefined = parsed.list ? {
      columns: parsed.list.columns.map(c => ({
        field: c.fieldName,
        header: c.header,
        sortable: c.isSortable,
      })),
      actions: parsed.list.actions.map(a => ({
        type: a.type,
        label: a.label,
        path: `/${a.controller}/${a.action}`,
      })),
      hasPagination: parsed.list.hasPagination,
      hasSearch: parsed.list.hasSearch,
      hasSorting: parsed.list.hasSorting,
    } : undefined;

    const imports = this.generateImports(parsed, list !== undefined);
    const hooks = this.generateHooks(parsed);
    const suggestedPath = this.suggestRoute(parsed);

    return {
      componentName,
      viewType: parsed.viewType,
      tableName: parsed.model?.linkedTable,
      fields,
      list,
      imports,
      hooks,
      permissions: parsed.permissions,
      layout,
      suggestedPath,
    };
  }

  /**
   * Determine layout from parsed content
   */
  private determineLayout(parsed: ParsedCSHTMLView): ReactBlueprint['layout'] {
    const hasTwoColumn = parsed.fields.some(f => f.colSpan <= 6);
    const hasThreeColumn = parsed.fields.some(f => f.colSpan <= 4);
    const hasSections = parsed.sections.length > 1;

    if (hasSections) return 'tabs';
    if (hasThreeColumn) return 'three_column';
    if (hasTwoColumn) return 'two_column';
    return 'single_column';
  }

  /**
   * Generate import statements
   */
  private generateImports(parsed: ParsedCSHTMLView, hasList: boolean): string[] {
    const imports: string[] = [
      'import React from \'react\'',
      'import { useForm } from \'react-hook-form\'',
    ];

    if (hasList) {
      imports.push('import { useTable, usePagination, useSortBy } from \'react-table\'');
    }

    if (parsed.permissions.length > 0) {
      imports.push('import { useAuth } from \'@/hooks/useAuth\'');
    }

    return imports;
  }

  /**
   * Generate hooks
   */
  private generateHooks(parsed: ParsedCSHTMLView): string[] {
    const hooks: string[] = ['const { register, handleSubmit, formState: { errors } } = useForm()'];

    if (parsed.permissions.length > 0) {
      hooks.push('const { hasRole } = useAuth()');
    }

    return hooks;
  }

  /**
   * Suggest route path
   */
  private suggestRoute(parsed: ParsedCSHTMLView): string {
    const tableName = parsed.model?.linkedTable || 'resource';
    const viewType = parsed.viewType;

    switch (viewType) {
      case 'list':
        return `/${tableName.toLowerCase()}`;
      case 'form':
        return `/${tableName.toLowerCase()}/new`;
      case 'details':
        return `/${tableName.toLowerCase()}/:id`;
      default:
        return `/${tableName.toLowerCase()}`;
    }
  }

  /**
   * Convert to PascalCase
   */
  private toPascalCase(str: string): string {
    return str
      .replace(/[-_\s]+(.)?/g, (_, c) => c ? c.toUpperCase() : '')
      .replace(/^(.)/, c => c.toUpperCase());
  }
}

/**
 * Parse multiple CSHTML files
 */
export function parseCSHTMLFiles(files: { name: string; content: string }[]): ParsedCSHTMLView[] {
  return files.map(file => {
    const parser = new CSHTMLParser(file.content);
    return parser.parse();
  });
}

/**
 * Generate React blueprints from CSHTML files
 */
export function generateReactBlueprints(files: { name: string; content: string }[]): ReactBlueprint[] {
  return files.map(file => {
    const parser = new CSHTMLParser(file.content);
    const parsed = parser.parse();
    return parser.generateReactBlueprint(parsed);
  });
}
